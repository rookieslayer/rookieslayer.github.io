package # Hide from PAUSE
  DBIx::Class::SQLAHacks::OracleJoins;

use base qw( DBIx::Class::SQLMaker::OracleJoins );

1;
