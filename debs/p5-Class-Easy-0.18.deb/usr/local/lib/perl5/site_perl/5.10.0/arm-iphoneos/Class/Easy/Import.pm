package Class::Easy::Import;

our $H = 0x800600;
our $WARN = "\x3c\x3f\x33\x00\x0f\xf0\x0f\xc0\xf0\xfc\x33\x00";

sub import {
	# use warnings
	${^WARNING_BITS} = $WARN;
	
	# use strict, use utf8;
	$^H |= $H;
	
	# use feature
	$^H{feature_switch} = $^H{feature_say} = $^H{feature_state} = 1;

}
1;