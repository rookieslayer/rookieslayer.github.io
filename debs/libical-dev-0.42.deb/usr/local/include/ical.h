/************************************************************************

 FILE:         ical.h
 CREATOR:      ajc 2008-sep-01

 (C) COPYRIGHT 2008 by Art Cancro
 http://freeassociation.sourceforge.net

 This program is free software; you can redistribute it and/or modify
 it under the terms of either: 

    The LGPL as published by the Free Software Foundation, version
    2.1, available at: http://www.fsf.org/copyleft/lesser.html

  Or:

    The Mozilla Public License Version 1.0. You may obtain a copy of
    the License at http://www.mozilla.org/MPL/

 ************************************************************************/

#warning "#include <ical.h> is deprecated.  Please #include <libical/ical.h> instead."
#include <libical/ical.h>
