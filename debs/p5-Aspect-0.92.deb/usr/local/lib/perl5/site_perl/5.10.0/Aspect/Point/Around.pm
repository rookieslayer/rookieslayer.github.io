package Aspect::Point::Around;

use strict;
use warnings;
use Aspect::Point ();

our $VERSION = '0.92';
our @ISA     = 'Aspect::Point';

1;
