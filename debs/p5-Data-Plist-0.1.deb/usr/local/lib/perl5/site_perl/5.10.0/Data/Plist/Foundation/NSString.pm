package Data::Plist::Foundation::NSString;

use strict;
use warnings;

use base qw/Data::Plist::Foundation::NSObject/;

1;
