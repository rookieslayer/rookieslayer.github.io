package Data::Maker::Field::Person;
use strict;
use Data::Maker::Field::Person::FirstName;
use Data::Maker::Field::Person::LastName;
use Data::Maker::Field::Person::MiddleName;
use Data::Maker::Field::Person::Gender;
use Data::Maker::Field::Person::SSN;
our $VERSION = '0.14';
1;
