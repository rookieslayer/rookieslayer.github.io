package DDP;
use Data::Printer;

BEGIN {
    push @ISA, 'Data::Printer';
    our $VERSION = $Data::Printer::VERSION;
}
1;
