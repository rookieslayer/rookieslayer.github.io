[
          {
            'number' => '1',
            'unicode' => 'E001',
            'sjis_auto' => 'F941',
            'name' => '男の子',
            'sjis' => '1b2447210f',
            'name_en' => 'Happy face',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image002.gif'
          },
          {
            'number' => '2',
            'unicode' => 'E002',
            'sjis_auto' => 'F942',
            'name' => '女の子',
            'sjis' => '1b2447220f',
            'name_en' => 'Happy face',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image004.gif'
          },
          {
            'number' => '3',
            'unicode' => 'E003',
            'sjis_auto' => 'F943',
            'name' => 'キスマーク',
            'sjis' => '1b2447230f',
            'name_en' => 'Kiss',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image006.gif'
          },
          {
            'number' => '4',
            'unicode' => 'E004',
            'sjis_auto' => 'F944',
            'name' => 'お父さん',
            'sjis' => '1b2447240f',
            'name_en' => 'Happy face',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image008.gif'
          },
          {
            'number' => '5',
            'unicode' => 'E005',
            'sjis_auto' => 'F945',
            'name' => 'お母さん',
            'sjis' => '1b2447250f',
            'name_en' => 'Happy face',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image010.gif'
          },
          {
            'number' => '6',
            'unicode' => 'E006',
            'sjis_auto' => 'F946',
            'name' => '洋服',
            'sjis' => '1b2447260f',
            'name_en' => 'T-shirt (border)',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image012.gif'
          },
          {
            'number' => '7',
            'unicode' => 'E007',
            'sjis_auto' => 'F947',
            'name' => 'ブーツ',
            'sjis' => '1b2447270f',
            'name_en' => 'Shoe',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image014.gif'
          },
          {
            'number' => '8',
            'unicode' => 'E008',
            'sjis_auto' => 'F948',
            'name' => 'カメラ',
            'sjis' => '1b2447280f',
            'name_en' => 'Camera',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image016.gif'
          },
          {
            'number' => '9',
            'unicode' => 'E009',
            'sjis_auto' => 'F949',
            'name' => '電話',
            'sjis' => '1b2447290f',
            'name_en' => 'Phone',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image018.gif'
          },
          {
            'number' => '10',
            'unicode' => 'E00A',
            'sjis_auto' => 'F94A',
            'name' => '携帯電話',
            'sjis' => '1b24472a0f',
            'name_en' => 'Mobile phone',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image020.gif'
          },
          {
            'number' => '11',
            'unicode' => 'E00B',
            'sjis_auto' => 'F94B',
            'name' => 'FAX',
            'sjis' => '1b24472b0f',
            'name_en' => 'fax to',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image022.gif'
          },
          {
            'number' => '12',
            'unicode' => 'E00C',
            'sjis_auto' => 'F94C',
            'name' => 'パソコン',
            'sjis' => '1b24472c0f',
            'name_en' => 'Computer',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image024.gif'
          },
          {
            'number' => '13',
            'unicode' => 'E00D',
            'sjis_auto' => 'F94D',
            'name' => 'パンチ',
            'sjis' => '1b24472d0f',
            'name_en' => 'Punch',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image026.gif'
          },
          {
            'number' => '14',
            'unicode' => 'E00E',
            'sjis_auto' => 'F94E',
            'name' => 'GOOD!',
            'sjis' => '1b24472e0f',
            'name_en' => 'Thumbs up',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image028.gif'
          },
          {
            'number' => '15',
            'unicode' => 'E00F',
            'sjis_auto' => 'F94F',
            'name' => 'No.1',
            'sjis' => '1b24472f0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image030.gif'
          },
          {
            'number' => '16',
            'unicode' => 'E010',
            'sjis_auto' => 'F950',
            'name' => 'グー',
            'sjis' => '1b2447300f',
            'name_en' => 'Hand (rock)',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image032.gif'
          },
          {
            'number' => '17',
            'unicode' => 'E011',
            'sjis_auto' => 'F951',
            'name' => 'チョキ',
            'sjis' => '1b2447310f',
            'name_en' => 'Hand (scissors)',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image034.gif'
          },
          {
            'number' => '18',
            'unicode' => 'E012',
            'sjis_auto' => 'F952',
            'name' => 'パー',
            'sjis' => '1b2447320f',
            'name_en' => 'Hand (paper)',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image036.gif'
          },
          {
            'number' => '19',
            'unicode' => 'E013',
            'sjis_auto' => 'F953',
            'name' => 'スキー',
            'sjis' => '1b2447330f',
            'name_en' => 'Ski',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image038.gif'
          },
          {
            'number' => '20',
            'unicode' => 'E014',
            'sjis_auto' => 'F954',
            'name' => 'ゴルフ',
            'sjis' => '1b2447340f',
            'name_en' => 'Golf',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image040.gif'
          },
          {
            'number' => '21',
            'unicode' => 'E015',
            'sjis_auto' => 'F955',
            'name' => 'テニス',
            'sjis' => '1b2447350f',
            'name_en' => 'Tennis',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image042.gif'
          },
          {
            'number' => '22',
            'unicode' => 'E016',
            'sjis_auto' => 'F956',
            'name' => '野球',
            'sjis' => '1b2447360f',
            'name_en' => 'Baseball',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image044.gif'
          },
          {
            'number' => '23',
            'unicode' => 'E017',
            'sjis_auto' => 'F957',
            'name' => 'サーフィン',
            'sjis' => '1b2447370f',
            'name_en' => 'Snowboarding',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image046.gif'
          },
          {
            'number' => '24',
            'unicode' => 'E018',
            'sjis_auto' => 'F958',
            'name' => 'サッカー',
            'sjis' => '1b2447380f',
            'name_en' => 'Soccer',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image048.gif'
          },
          {
            'number' => '25',
            'unicode' => 'E019',
            'sjis_auto' => 'F959',
            'name' => '魚',
            'sjis' => '1b2447390f',
            'name_en' => 'Fish',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image050.gif'
          },
          {
            'number' => '26',
            'unicode' => 'E01A',
            'sjis_auto' => 'F95A',
            'name' => 'うま',
            'sjis' => '1b24473a0f',
            'name_en' => 'Horse',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image052.gif'
          },
          {
            'number' => '27',
            'unicode' => 'E01B',
            'sjis_auto' => 'F95B',
            'name' => '車',
            'sjis' => '1b24473b0f',
            'name_en' => 'Car (sedan)',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image054.gif'
          },
          {
            'number' => '28',
            'unicode' => 'E01C',
            'sjis_auto' => 'F95C',
            'name' => 'ヨット',
            'sjis' => '1b24473c0f',
            'name_en' => 'Resort',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image056.gif'
          },
          {
            'number' => '29',
            'unicode' => 'E01D',
            'sjis_auto' => 'F95D',
            'name' => '飛行機',
            'sjis' => '1b24473d0f',
            'name_en' => 'Airplane',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image058.gif'
          },
          {
            'number' => '30',
            'unicode' => 'E01E',
            'sjis_auto' => 'F95E',
            'name' => '電車',
            'sjis' => '1b24473e0f',
            'name_en' => 'Train',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image060.gif'
          },
          {
            'number' => '31',
            'unicode' => 'E01F',
            'sjis_auto' => 'F95F',
            'name' => '新幹線',
            'sjis' => '1b24473f0f',
            'name_en' => 'Bullet train',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image062.gif'
          },
          {
            'number' => '32',
            'unicode' => 'E020',
            'sjis_auto' => 'F960',
            'name' => 'ハテナ',
            'sjis' => '1b2447400f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image064.gif'
          },
          {
            'number' => '33',
            'unicode' => 'E021',
            'sjis_auto' => 'F961',
            'name' => 'ビックリ',
            'sjis' => '1b2447410f',
            'name_en' => 'Exclamation mark',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image066.jpg'
          },
          {
            'number' => '34',
            'unicode' => 'E022',
            'sjis_auto' => 'F962',
            'name' => 'ハートマーク',
            'sjis' => '1b2447420f',
            'name_en' => 'Black heart',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image068.jpg'
          },
          {
            'number' => '35',
            'unicode' => 'E023',
            'sjis_auto' => 'F963',
            'name' => 'ハートブレイク',
            'sjis' => '1b2447430f',
            'name_en' => 'Heartbreak',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image070.jpg'
          },
          {
            'number' => '36',
            'unicode' => 'E024',
            'sjis_auto' => 'F964',
            'name' => '1時',
            'sjis' => '1b2447440f',
            'name_en' => 'Clock',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image072.gif'
          },
          {
            'number' => '37',
            'unicode' => 'E025',
            'sjis_auto' => 'F965',
            'name' => '2時',
            'sjis' => '1b2447450f',
            'name_en' => 'Clock',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image074.gif'
          },
          {
            'number' => '38',
            'unicode' => 'E026',
            'sjis_auto' => 'F966',
            'name' => '時計',
            'sjis' => '1b2447460f',
            'name_en' => 'Clock',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image076.gif'
          },
          {
            'number' => '39',
            'unicode' => 'E027',
            'sjis_auto' => 'F967',
            'name' => '4時',
            'sjis' => '1b2447470f',
            'name_en' => 'Clock',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image078.gif'
          },
          {
            'number' => '40',
            'unicode' => 'E028',
            'sjis_auto' => 'F968',
            'name' => '5時',
            'sjis' => '1b2447480f',
            'name_en' => 'Clock',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image080.gif'
          },
          {
            'number' => '41',
            'unicode' => 'E029',
            'sjis_auto' => 'F969',
            'name' => '6時',
            'sjis' => '1b2447490f',
            'name_en' => 'Clock',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image082.gif'
          },
          {
            'number' => '42',
            'unicode' => 'E02A',
            'sjis_auto' => 'F96A',
            'name' => '7時',
            'sjis' => '1b24474a0f',
            'name_en' => 'Clock',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image084.gif'
          },
          {
            'number' => '43',
            'unicode' => 'E02B',
            'sjis_auto' => 'F96B',
            'name' => '8時',
            'sjis' => '1b24474b0f',
            'name_en' => 'Clock',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image086.gif'
          },
          {
            'number' => '44',
            'unicode' => 'E02C',
            'sjis_auto' => 'F96C',
            'name' => '9時',
            'sjis' => '1b24474c0f',
            'name_en' => 'Clock',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image088.gif'
          },
          {
            'number' => '45',
            'unicode' => 'E02D',
            'sjis_auto' => 'F96D',
            'name' => '10時',
            'sjis' => '1b24474d0f',
            'name_en' => 'Clock',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image090.gif'
          },
          {
            'number' => '46',
            'unicode' => 'E02E',
            'sjis_auto' => 'F96E',
            'name' => '11時',
            'sjis' => '1b24474e0f',
            'name_en' => 'Clock',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image092.gif'
          },
          {
            'number' => '47',
            'unicode' => 'E02F',
            'sjis_auto' => 'F96F',
            'name' => '12時',
            'sjis' => '1b24474f0f',
            'name_en' => 'Clock',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image094.gif'
          },
          {
            'number' => '48',
            'unicode' => 'E030',
            'sjis_auto' => 'F970',
            'name' => 'お花見',
            'sjis' => '1b2447500f',
            'name_en' => 'Cherry blossom',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image096.jpg'
          },
          {
            'number' => '49',
            'unicode' => 'E031',
            'sjis_auto' => 'F971',
            'name' => 'エンブレム',
            'sjis' => '1b2447510f',
            'name_en' => 'Crown',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image098.jpg'
          },
          {
            'number' => '50',
            'unicode' => 'E032',
            'sjis_auto' => 'F972',
            'name' => 'バラ',
            'sjis' => '1b2447520f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image100.gif'
          },
          {
            'number' => '51',
            'unicode' => 'E033',
            'sjis_auto' => 'F973',
            'name' => 'クリスマス',
            'sjis' => '1b2447530f',
            'name_en' => 'Christmas',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image102.gif'
          },
          {
            'number' => '52',
            'unicode' => 'E034',
            'sjis_auto' => 'F974',
            'name' => '指輪',
            'sjis' => '1b2447540f',
            'name_en' => 'Ring',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image104.gif'
          },
          {
            'number' => '53',
            'unicode' => 'E035',
            'sjis_auto' => 'F975',
            'name' => '宝石',
            'sjis' => '1b2447550f',
            'name_en' => 'Ring',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image106.gif'
          },
          {
            'number' => '54',
            'unicode' => 'E036',
            'sjis_auto' => 'F976',
            'name' => '家',
            'sjis' => '1b2447560f',
            'name_en' => 'House',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image108.gif'
          },
          {
            'number' => '55',
            'unicode' => 'E037',
            'sjis_auto' => 'F977',
            'name' => '教会',
            'sjis' => '1b2447570f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image110.gif'
          },
          {
            'number' => '56',
            'unicode' => 'E038',
            'sjis_auto' => 'F978',
            'name' => 'ビル',
            'sjis' => '1b2447580f',
            'name_en' => 'Building',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image112.gif'
          },
          {
            'number' => '57',
            'unicode' => 'E039',
            'sjis_auto' => 'F979',
            'name' => '駅',
            'sjis' => '1b2447590f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image114.gif'
          },
          {
            'number' => '58',
            'unicode' => 'E03A',
            'sjis_auto' => 'F97A',
            'name' => 'ガソリンスタンド',
            'sjis' => '1b24475a0f',
            'name_en' => 'Gas station',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image116.gif'
          },
          {
            'number' => '59',
            'unicode' => 'E03B',
            'sjis_auto' => 'F97B',
            'name' => '山',
            'sjis' => '1b24475b0f',
            'name_en' => 'Mount Fuji',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image118.gif'
          },
          {
            'number' => '60',
            'unicode' => 'E03C',
            'sjis_auto' => 'F97C',
            'name' => 'マイク',
            'sjis' => '1b24475c0f',
            'name_en' => 'Karaoke',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image120.gif'
          },
          {
            'number' => '61',
            'unicode' => 'E03D',
            'sjis_auto' => 'F97D',
            'name' => '映画',
            'sjis' => '1b24475d0f',
            'name_en' => 'Movie',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image122.gif'
          },
          {
            'number' => '62',
            'unicode' => 'E03E',
            'sjis_auto' => 'F97E',
            'name' => '音楽',
            'sjis' => '1b24475e0f',
            'name_en' => 'Cheerful',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image124.gif'
          },
          {
            'number' => '63',
            'unicode' => 'E03F',
            'sjis_auto' => 'F980',
            'name' => 'カギ',
            'sjis' => '1b24475f0f',
            'name_en' => 'Password',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image126.gif'
          },
          {
            'number' => '64',
            'unicode' => 'E040',
            'sjis_auto' => 'F981',
            'name' => 'サックス',
            'sjis' => '1b2447600f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image128.gif'
          },
          {
            'number' => '65',
            'unicode' => 'E041',
            'sjis_auto' => 'F982',
            'name' => 'ギター',
            'sjis' => '1b2447610f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image130.jpg'
          },
          {
            'number' => '66',
            'unicode' => 'E042',
            'sjis_auto' => 'F983',
            'name' => 'トランペット',
            'sjis' => '1b2447620f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image132.gif'
          },
          {
            'number' => '67',
            'unicode' => 'E043',
            'sjis_auto' => 'F984',
            'name' => 'レストラン',
            'sjis' => '1b2447630f',
            'name_en' => 'Restaurant',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image134.gif'
          },
          {
            'number' => '68',
            'unicode' => 'E044',
            'sjis_auto' => 'F985',
            'name' => 'カクテル',
            'sjis' => '1b2447640f',
            'name_en' => 'Bar',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image136.gif'
          },
          {
            'number' => '69',
            'unicode' => 'E045',
            'sjis_auto' => 'F986',
            'name' => 'コーヒー',
            'sjis' => '1b2447650f',
            'name_en' => 'Café',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image138.gif'
          },
          {
            'number' => '70',
            'unicode' => 'E046',
            'sjis_auto' => 'F987',
            'name' => 'ケーキ',
            'sjis' => '1b2447660f',
            'name_en' => 'Short cake',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image140.gif'
          },
          {
            'number' => '71',
            'unicode' => 'E047',
            'sjis_auto' => 'F988',
            'name' => 'ビール',
            'sjis' => '1b2447670f',
            'name_en' => 'Beer',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image142.gif'
          },
          {
            'number' => '72',
            'unicode' => 'E048',
            'sjis_auto' => 'F989',
            'name' => '雪',
            'sjis' => '1b2447680f',
            'name_en' => 'Snow',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image144.gif'
          },
          {
            'number' => '73',
            'unicode' => 'E049',
            'sjis_auto' => 'F98A',
            'name' => '曇り',
            'sjis' => '1b2447690f',
            'name_en' => 'Cloudy',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image146.gif'
          },
          {
            'number' => '74',
            'unicode' => 'E04A',
            'sjis_auto' => 'F98B',
            'name' => '晴れ(昼)',
            'sjis' => '1b24476a0f',
            'name_en' => 'Fine',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image148.gif'
          },
          {
            'number' => '75',
            'unicode' => 'E04B',
            'sjis_auto' => 'F98C',
            'name' => '雨',
            'sjis' => '1b24476b0f',
            'name_en' => 'Rain',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image150.gif'
          },
          {
            'number' => '76',
            'unicode' => 'E04C',
            'sjis_auto' => 'F98D',
            'name' => '晴れ(夜)',
            'sjis' => '1b24476c0f',
            'name_en' => 'Crescent moon',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image152.gif'
          },
          {
            'number' => '77',
            'unicode' => 'E04D',
            'sjis_auto' => 'F98E',
            'name' => '朝',
            'sjis' => '1b24476d0f',
            'name_en' => 'Fine',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image154.gif'
          },
          {
            'number' => '78',
            'unicode' => 'E04E',
            'sjis_auto' => 'F98F',
            'name' => '天使',
            'sjis' => '1b24476e0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image156.gif'
          },
          {
            'number' => '79',
            'unicode' => 'E04F',
            'sjis_auto' => 'F990',
            'name' => 'ねこ',
            'sjis' => '1b24476f0f',
            'name_en' => 'Cat',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image158.gif'
          },
          {
            'number' => '80',
            'unicode' => 'E050',
            'sjis_auto' => 'F991',
            'name' => 'とら',
            'sjis' => '1b2447700f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image160.gif'
          },
          {
            'number' => '81',
            'unicode' => 'E051',
            'sjis_auto' => 'F992',
            'name' => 'くま',
            'sjis' => '1b2447710f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image162.gif'
          },
          {
            'number' => '82',
            'unicode' => 'E052',
            'sjis_auto' => 'F993',
            'name' => 'いぬ',
            'sjis' => '1b2447720f',
            'name_en' => 'Dog',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image164.gif'
          },
          {
            'number' => '83',
            'unicode' => 'E053',
            'sjis_auto' => 'F994',
            'name' => 'ねずみ',
            'sjis' => '1b2447730f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image166.gif'
          },
          {
            'number' => '84',
            'unicode' => 'E054',
            'sjis_auto' => 'F995',
            'name' => 'クジラ',
            'sjis' => '1b2447740f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image168.gif'
          },
          {
            'number' => '85',
            'unicode' => 'E055',
            'sjis_auto' => 'F996',
            'name' => 'ペンギン',
            'sjis' => '1b2447750f',
            'name_en' => 'Penguin',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image170.gif'
          },
          {
            'number' => '86',
            'unicode' => 'E056',
            'sjis_auto' => 'F997',
            'name' => '楽',
            'sjis' => '1b2447760f',
            'name_en' => 'Happy face',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image172.gif'
          },
          {
            'number' => '87',
            'unicode' => 'E057',
            'sjis_auto' => 'F998',
            'name' => '喜',
            'sjis' => '1b2447770f',
            'name_en' => 'Happy face',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image174.gif'
          },
          {
            'number' => '88',
            'unicode' => 'E058',
            'sjis_auto' => 'F999',
            'name' => '哀',
            'sjis' => '1b2447780f',
            'name_en' => 'Disappointed face',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image176.gif'
          },
          {
            'number' => '89',
            'unicode' => 'E059',
            'sjis_auto' => 'F99A',
            'name' => '怒',
            'sjis' => '1b2447790f',
            'name_en' => 'Angry face',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image178.gif'
          },
          {
            'number' => '90',
            'unicode' => 'E05A',
            'sjis_auto' => 'F99B',
            'name' => 'ウンチ',
            'sjis' => '1b24477a0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/emoji_8271_image180.gif'
          },
          {
            'number' => '91',
            'unicode' => 'E101',
            'sjis_auto' => 'F741',
            'name' => 'メール受信',
            'sjis' => '1b2445210f',
            'name_en' => 'Post office',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-E21.gif'
          },
          {
            'number' => '92',
            'unicode' => 'E102',
            'sjis_auto' => 'F742',
            'name' => 'メール送信',
            'sjis' => '1b2445220f',
            'name_en' => 'Post office',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-E22.gif'
          },
          {
            'number' => '93',
            'unicode' => 'E103',
            'sjis_auto' => 'F743',
            'name' => 'メール宛先',
            'sjis' => '1b2445230f',
            'name_en' => 'mail to',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-E23.gif'
          },
          {
            'number' => '94',
            'unicode' => 'E104',
            'sjis_auto' => 'F744',
            'name' => '電話番号',
            'sjis' => '1b2445240f',
            'name_en' => 'Phone to',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-E24.gif'
          },
          {
            'number' => '95',
            'unicode' => 'E105',
            'sjis_auto' => 'F745',
            'name' => 'あっかんベー',
            'sjis' => '1b2445250f',
            'name_en' => 'Sticking tongue out',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-E25.gif'
          },
          {
            'number' => '96',
            'unicode' => 'E106',
            'sjis_auto' => 'F746',
            'name' => 'ラブラブ',
            'sjis' => '1b2445260f',
            'name_en' => 'Heart shaped eyes',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-E26.gif'
          },
          {
            'number' => '97',
            'unicode' => 'E107',
            'sjis_auto' => 'F747',
            'name' => 'ガビーン',
            'sjis' => '1b2445270f',
            'name_en' => 'Very thin',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-E27.gif'
          },
          {
            'number' => '98',
            'unicode' => 'E108',
            'sjis_auto' => 'F748',
            'name' => 'タラー',
            'sjis' => '1b2445280f',
            'name_en' => 'Cold sweat 2',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-E28.gif'
          },
          {
            'number' => '99',
            'unicode' => 'E109',
            'sjis_auto' => 'F749',
            'name' => 'さる',
            'sjis' => '1b2445290f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image016.gif'
          },
          {
            'number' => '100',
            'unicode' => 'E10A',
            'sjis_auto' => 'F74A',
            'name' => 'たこ',
            'sjis' => '1b24452a0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image017.gif'
          },
          {
            'number' => '101',
            'unicode' => 'E10B',
            'sjis_auto' => 'F74B',
            'name' => 'ぶた',
            'sjis' => '1b24452b0f',
            'name_en' => 'Pig',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image018.gif'
          },
          {
            'number' => '102',
            'unicode' => 'E10C',
            'sjis_auto' => 'F74C',
            'name' => '宇宙人',
            'sjis' => '1b24452c0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image019.gif'
          },
          {
            'number' => '103',
            'unicode' => 'E10D',
            'sjis_auto' => 'F74D',
            'name' => 'ロケット',
            'sjis' => '1b24452d0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-E2D.gif'
          },
          {
            'number' => '104',
            'unicode' => 'E10E',
            'sjis_auto' => 'F74E',
            'name' => '王冠',
            'sjis' => '1b24452e0f',
            'name_en' => 'Crown',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image022.gif'
          },
          {
            'number' => '105',
            'unicode' => 'E10F',
            'sjis_auto' => 'F74F',
            'name' => '電球',
            'sjis' => '1b24452f0f',
            'name_en' => 'Good idea',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-E2F.gif'
          },
          {
            'number' => '106',
            'unicode' => 'E110',
            'sjis_auto' => 'F750',
            'name' => 'よつば',
            'sjis' => '1b2445300f',
            'name_en' => '4-leaf clover',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image025.gif'
          },
          {
            'number' => '107',
            'unicode' => 'E111',
            'sjis_auto' => 'F751',
            'name' => 'キス',
            'sjis' => '1b2445310f',
            'name_en' => 'Kiss',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-E31.gif'
          },
          {
            'number' => '108',
            'unicode' => 'E112',
            'sjis_auto' => 'F752',
            'name' => 'バースデー',
            'sjis' => '1b2445320f',
            'name_en' => 'Present',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image029.gif'
          },
          {
            'number' => '109',
            'unicode' => 'E113',
            'sjis_auto' => 'F753',
            'name' => 'ピストル',
            'sjis' => '1b2445330f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-E33.gif'
          },
          {
            'number' => '110',
            'unicode' => 'E114',
            'sjis_auto' => 'F754',
            'name' => '虫眼鏡',
            'sjis' => '1b2445340f',
            'name_en' => 'Search',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image033.gif'
          },
          {
            'number' => '111',
            'unicode' => 'E115',
            'sjis_auto' => 'F755',
            'name' => '陸上',
            'sjis' => '1b2445350f',
            'name_en' => 'Running man',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-E35.gif'
          },
          {
            'number' => '112',
            'unicode' => 'E116',
            'sjis_auto' => 'F756',
            'name' => 'オークション',
            'sjis' => '1b2445360f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image037.gif'
          },
          {
            'number' => '113',
            'unicode' => 'E117',
            'sjis_auto' => 'F757',
            'name' => '花火',
            'sjis' => '1b2445370f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-E37.gif'
          },
          {
            'number' => '114',
            'unicode' => 'E118',
            'sjis_auto' => 'F758',
            'name' => 'もみじ',
            'sjis' => '1b2445380f',
            'name_en' => 'Maple leaf',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image041.gif'
          },
          {
            'number' => '115',
            'unicode' => 'E119',
            'sjis_auto' => 'F759',
            'name' => '落ち葉',
            'sjis' => '1b2445390f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-E39.gif'
          },
          {
            'number' => '116',
            'unicode' => 'E11A',
            'sjis_auto' => 'F75A',
            'name' => '悪魔',
            'sjis' => '1b24453a0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image045.gif'
          },
          {
            'number' => '117',
            'unicode' => 'E11B',
            'sjis_auto' => 'F75B',
            'name' => 'おばけ',
            'sjis' => '1b24453b0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-E3B.gif'
          },
          {
            'number' => '118',
            'unicode' => 'E11C',
            'sjis_auto' => 'F75C',
            'name' => 'ドクロ',
            'sjis' => '1b24453c0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image049.gif'
          },
          {
            'number' => '119',
            'unicode' => 'E11D',
            'sjis_auto' => 'F75D',
            'name' => 'ファイヤー',
            'sjis' => '1b24453d0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-E3D.gif'
          },
          {
            'number' => '120',
            'unicode' => 'E11E',
            'sjis_auto' => 'F75E',
            'name' => 'かばん',
            'sjis' => '1b24453e0f',
            'name_en' => 'Bag',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image053.gif'
          },
          {
            'number' => '121',
            'unicode' => 'E11F',
            'sjis_auto' => 'F75F',
            'name' => '座席',
            'sjis' => '1b24453f0f',
            'name_en' => 'Chair',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image055.gif'
          },
          {
            'number' => '122',
            'unicode' => 'E120',
            'sjis_auto' => 'F760',
            'name' => 'ハンバーガ',
            'sjis' => '1b2445400f',
            'name_en' => 'Fast food',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image056.gif'
          },
          {
            'number' => '123',
            'unicode' => 'E121',
            'sjis_auto' => 'F761',
            'name' => '公園',
            'sjis' => '1b2445410f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image057.gif'
          },
          {
            'number' => '124',
            'unicode' => 'E122',
            'sjis_auto' => 'F762',
            'name' => 'キャンプ場',
            'sjis' => '1b2445420f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image058.gif'
          },
          {
            'number' => '125',
            'unicode' => 'E123',
            'sjis_auto' => 'F763',
            'name' => '温泉',
            'sjis' => '1b2445430f',
            'name_en' => 'Comfort (hot spring)',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image059.gif'
          },
          {
            'number' => '126',
            'unicode' => 'E124',
            'sjis_auto' => 'F764',
            'name' => '遊園地',
            'sjis' => '1b2445440f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image060.gif'
          },
          {
            'number' => '127',
            'unicode' => 'E125',
            'sjis_auto' => 'F765',
            'name' => 'チケット',
            'sjis' => '1b2445450f',
            'name_en' => 'Ticket',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image061.gif'
          },
          {
            'number' => '128',
            'unicode' => 'E126',
            'sjis_auto' => 'F766',
            'name' => 'CD',
            'sjis' => '1b2445460f',
            'name_en' => 'CD',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image062.gif'
          },
          {
            'number' => '129',
            'unicode' => 'E127',
            'sjis_auto' => 'F767',
            'name' => 'DVD',
            'sjis' => '1b2445470f',
            'name_en' => 'CD',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image063.gif'
          },
          {
            'number' => '130',
            'unicode' => 'E128',
            'sjis_auto' => 'F768',
            'name' => 'ラジオ',
            'sjis' => '1b2445480f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image064.gif'
          },
          {
            'number' => '131',
            'unicode' => 'E129',
            'sjis_auto' => 'F769',
            'name' => 'ビデオ',
            'sjis' => '1b2445490f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image065.gif'
          },
          {
            'number' => '132',
            'unicode' => 'E12A',
            'sjis_auto' => 'F76A',
            'name' => 'テレビ',
            'sjis' => '1b24454a0f',
            'name_en' => 'TV',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image066.gif'
          },
          {
            'number' => '133',
            'unicode' => 'E12B',
            'sjis_auto' => 'F76B',
            'name' => 'ゲーム',
            'sjis' => '1b24454b0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-E4B.gif'
          },
          {
            'number' => '134',
            'unicode' => 'E12C',
            'sjis_auto' => 'F76C',
            'name' => '歌い出し',
            'sjis' => '1b24454c0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image068.gif'
          },
          {
            'number' => '135',
            'unicode' => 'E12D',
            'sjis_auto' => 'F76D',
            'name' => 'マージャン',
            'sjis' => '1b24454d0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image069.gif'
          },
          {
            'number' => '136',
            'unicode' => 'E12E',
            'sjis_auto' => 'F76E',
            'name' => '対決',
            'sjis' => '1b24454e0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-E4E.gif'
          },
          {
            'number' => '137',
            'unicode' => 'E12F',
            'sjis_auto' => 'F76F',
            'name' => '賞金',
            'sjis' => '1b24454f0f',
            'name_en' => 'Money bag',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image071.gif'
          },
          {
            'number' => '138',
            'unicode' => 'E130',
            'sjis_auto' => 'F770',
            'name' => '当り',
            'sjis' => '1b2445500f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-E50.gif'
          },
          {
            'number' => '139',
            'unicode' => 'E131',
            'sjis_auto' => 'F771',
            'name' => 'トロフィー',
            'sjis' => '1b2445510f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image074.gif'
          },
          {
            'number' => '140',
            'unicode' => 'E132',
            'sjis_auto' => 'F772',
            'name' => 'ゴール',
            'sjis' => '1b2445520f',
            'name_en' => 'Motor sports',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image075.gif'
          },
          {
            'number' => '141',
            'unicode' => 'E133',
            'sjis_auto' => 'F773',
            'name' => 'スロット',
            'sjis' => '1b2445530f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image076.gif'
          },
          {
            'number' => '142',
            'unicode' => 'E134',
            'sjis_auto' => 'F774',
            'name' => '競馬',
            'sjis' => '1b2445540f',
            'name_en' => 'Horse',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image077.gif'
          },
          {
            'number' => '143',
            'unicode' => 'E135',
            'sjis_auto' => 'F775',
            'name' => '競艇',
            'sjis' => '1b2445550f',
            'name_en' => 'Resort',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image078.gif'
          },
          {
            'number' => '144',
            'unicode' => 'E136',
            'sjis_auto' => 'F776',
            'name' => '競輪',
            'sjis' => '1b2445560f',
            'name_en' => 'Bicycle',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image079.gif'
          },
          {
            'number' => '145',
            'unicode' => 'E137',
            'sjis_auto' => 'F777',
            'name' => '工事中',
            'sjis' => '1b2445570f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image080.gif'
          },
          {
            'number' => '146',
            'unicode' => 'E138',
            'sjis_auto' => 'F778',
            'name' => '男性',
            'sjis' => '1b2445580f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image081.gif'
          },
          {
            'number' => '147',
            'unicode' => 'E139',
            'sjis_auto' => 'F779',
            'name' => '女性',
            'sjis' => '1b2445590f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image082.gif'
          },
          {
            'number' => '148',
            'unicode' => 'E13A',
            'sjis_auto' => 'F77A',
            'name' => '乳幼児',
            'sjis' => '1b24455a0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image083.gif'
          },
          {
            'number' => '149',
            'unicode' => 'E13B',
            'sjis_auto' => 'F77B',
            'name' => '注射器',
            'sjis' => '1b24455b0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image084.gif'
          },
          {
            'number' => '150',
            'unicode' => 'E13C',
            'sjis_auto' => 'F77C',
            'name' => '睡眠',
            'sjis' => '1b24455c0f',
            'name_en' => 'Sleepy (sleep)',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image085.gif'
          },
          {
            'number' => '151',
            'unicode' => 'E13D',
            'sjis_auto' => 'F77D',
            'name' => '雷',
            'sjis' => '1b24455d0f',
            'name_en' => 'Thunder',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image086.gif'
          },
          {
            'number' => '152',
            'unicode' => 'E13E',
            'sjis_auto' => 'F77E',
            'name' => 'ハイヒール',
            'sjis' => '1b24455e0f',
            'name_en' => 'Boutique',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image087.gif'
          },
          {
            'number' => '153',
            'unicode' => 'E13F',
            'sjis_auto' => 'F780',
            'name' => '入浴',
            'sjis' => '1b24455f0f',
            'name_en' => 'Comfort (hot spring)',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image088.gif'
          },
          {
            'number' => '154',
            'unicode' => 'E140',
            'sjis_auto' => 'F781',
            'name' => 'トイレ',
            'sjis' => '1b2445600f',
            'name_en' => 'Toilet',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image089.gif'
          },
          {
            'number' => '155',
            'unicode' => 'E141',
            'sjis_auto' => 'F782',
            'name' => '音声',
            'sjis' => '1b2445610f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image090.gif'
          },
          {
            'number' => '156',
            'unicode' => 'E142',
            'sjis_auto' => 'F783',
            'name' => 'お知らせ',
            'sjis' => '1b2445620f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image091.gif'
          },
          {
            'number' => '157',
            'unicode' => 'E143',
            'sjis_auto' => 'F784',
            'name' => '祝日',
            'sjis' => '1b2445630f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image092.gif'
          },
          {
            'number' => '158',
            'unicode' => 'E144',
            'sjis_auto' => 'F785',
            'name' => 'ロックON',
            'sjis' => '1b2445640f',
            'name_en' => 'Password',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image093.gif'
          },
          {
            'number' => '159',
            'unicode' => 'E145',
            'sjis_auto' => 'F786',
            'name' => 'ロックOFF',
            'sjis' => '1b2445650f',
            'name_en' => 'Password',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image094.gif'
          },
          {
            'number' => '160',
            'unicode' => 'E146',
            'sjis_auto' => 'F787',
            'name' => '街',
            'sjis' => '1b2445660f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image095.gif'
          },
          {
            'number' => '161',
            'unicode' => 'E147',
            'sjis_auto' => 'F788',
            'name' => '料理',
            'sjis' => '1b2445670f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image096.gif'
          },
          {
            'number' => '162',
            'unicode' => 'E148',
            'sjis_auto' => 'F789',
            'name' => '本',
            'sjis' => '1b2445680f',
            'name_en' => 'Book',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image097.gif'
          },
          {
            'number' => '163',
            'unicode' => 'E149',
            'sjis_auto' => 'F78A',
            'name' => '為替相場',
            'sjis' => '1b2445690f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image098.gif'
          },
          {
            'number' => '164',
            'unicode' => 'E14A',
            'sjis_auto' => 'F78B',
            'name' => '株価',
            'sjis' => '1b24456a0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image099.gif'
          },
          {
            'number' => '165',
            'unicode' => 'E14B',
            'sjis_auto' => 'F78C',
            'name' => 'ニュース',
            'sjis' => '1b24456b0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image100.gif'
          },
          {
            'number' => '166',
            'unicode' => 'E14C',
            'sjis_auto' => 'F78D',
            'name' => '元気',
            'sjis' => '1b24456c0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image101.gif'
          },
          {
            'number' => '167',
            'unicode' => 'E14D',
            'sjis_auto' => 'F78E',
            'name' => '銀行',
            'sjis' => '1b24456d0f',
            'name_en' => 'Bank',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image102.gif'
          },
          {
            'number' => '168',
            'unicode' => 'E14E',
            'sjis_auto' => 'F78F',
            'name' => '信号',
            'sjis' => '1b24456e0f',
            'name_en' => 'Traffic signal',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image103.gif'
          },
          {
            'number' => '169',
            'unicode' => 'E14F',
            'sjis_auto' => 'F790',
            'name' => '駐車場',
            'sjis' => '1b24456f0f',
            'name_en' => 'Parking',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image104.gif'
          },
          {
            'number' => '170',
            'unicode' => 'E150',
            'sjis_auto' => 'F791',
            'name' => 'バス停',
            'sjis' => '1b2445700f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image105.gif'
          },
          {
            'number' => '171',
            'unicode' => 'E151',
            'sjis_auto' => 'F792',
            'name' => '公衆トイレ',
            'sjis' => '1b2445710f',
            'name_en' => 'Toilet',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image106.gif'
          },
          {
            'number' => '172',
            'unicode' => 'E152',
            'sjis_auto' => 'F793',
            'name' => '交番',
            'sjis' => '1b2445720f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image107.gif'
          },
          {
            'number' => '173',
            'unicode' => 'E153',
            'sjis_auto' => 'F794',
            'name' => '郵便局',
            'sjis' => '1b2445730f',
            'name_en' => 'Post office',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image108.gif'
          },
          {
            'number' => '174',
            'unicode' => 'E154',
            'sjis_auto' => 'F795',
            'name' => 'ATM',
            'sjis' => '1b2445740f',
            'name_en' => 'ATM',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image109.gif'
          },
          {
            'number' => '175',
            'unicode' => 'E155',
            'sjis_auto' => 'F796',
            'name' => '病院',
            'sjis' => '1b2445750f',
            'name_en' => 'Hospital',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image110.gif'
          },
          {
            'number' => '176',
            'unicode' => 'E156',
            'sjis_auto' => 'F797',
            'name' => 'コンビニ',
            'sjis' => '1b2445760f',
            'name_en' => 'Convenience store',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image111.gif'
          },
          {
            'number' => '177',
            'unicode' => 'E157',
            'sjis_auto' => 'F798',
            'name' => '学校',
            'sjis' => '1b2445770f',
            'name_en' => 'School',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image112.gif'
          },
          {
            'number' => '178',
            'unicode' => 'E158',
            'sjis_auto' => 'F799',
            'name' => 'ホテル',
            'sjis' => '1b2445780f',
            'name_en' => 'Hotel',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image113.gif'
          },
          {
            'number' => '179',
            'unicode' => 'E159',
            'sjis_auto' => 'F79A',
            'name' => 'バス',
            'sjis' => '1b2445790f',
            'name_en' => 'Bus',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image114.gif'
          },
          {
            'number' => '180',
            'unicode' => 'E15A',
            'sjis_auto' => 'F79B',
            'name' => 'タクシー',
            'sjis' => '1b24457a0f',
            'name_en' => 'Car (sedan)',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_8285_image116.gif'
          },
          {
            'number' => '181',
            'unicode' => 'E201',
            'sjis_auto' => 'F7A1',
            'name' => '徒歩',
            'sjis' => '1b2446210f',
            'name_en' => 'Running man',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-F21.gif'
          },
          {
            'number' => '182',
            'unicode' => 'E202',
            'sjis_auto' => 'F7A2',
            'name' => '船',
            'sjis' => '1b2446220f',
            'name_en' => 'Ship',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image002.gif'
          },
          {
            'number' => '183',
            'unicode' => 'E203',
            'sjis_auto' => 'F7A3',
            'name' => '目的地',
            'sjis' => '1b2446230f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-F23.gif'
          },
          {
            'number' => '184',
            'unicode' => 'E204',
            'sjis_auto' => 'F7A4',
            'name' => '飾罫1',
            'sjis' => '1b2446240f',
            'name_en' => 'Cute',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image004.gif'
          },
          {
            'number' => '185',
            'unicode' => 'E205',
            'sjis_auto' => 'F7A5',
            'name' => '飾罫2',
            'sjis' => '1b2446250f',
            'name_en' => 'Cute',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image005.gif'
          },
          {
            'number' => '186',
            'unicode' => 'E206',
            'sjis_auto' => 'F7A6',
            'name' => '飾罫3',
            'sjis' => '1b2446260f',
            'name_en' => 'Cute',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-F26.gif'
          },
          {
            'number' => '187',
            'unicode' => 'E207',
            'sjis_auto' => 'F7A7',
            'name' => '18禁',
            'sjis' => '1b2446270f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image007.gif'
          },
          {
            'number' => '188',
            'unicode' => 'E208',
            'sjis_auto' => 'F7A8',
            'name' => '禁煙',
            'sjis' => '1b2446280f',
            'name_en' => 'Non-smoking',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image008.gif'
          },
          {
            'number' => '189',
            'unicode' => 'E209',
            'sjis_auto' => 'F7A9',
            'name' => '初心者',
            'sjis' => '1b2446290f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image009.gif'
          },
          {
            'number' => '190',
            'unicode' => 'E20A',
            'sjis_auto' => 'F7AA',
            'name' => 'バリアフリー',
            'sjis' => '1b24462a0f',
            'name_en' => 'Wheelchair',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image010.gif'
          },
          {
            'number' => '191',
            'unicode' => 'E20B',
            'sjis_auto' => 'F7AB',
            'name' => 'アンテナマーク',
            'sjis' => '1b24462b0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image011.gif'
          },
          {
            'number' => '192',
            'unicode' => 'E20C',
            'sjis_auto' => 'F7AC',
            'name' => 'ハート',
            'sjis' => '1b24462c0f',
            'name_en' => 'Heart',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image012.gif'
          },
          {
            'number' => '193',
            'unicode' => 'E20D',
            'sjis_auto' => 'F7AD',
            'name' => 'ダイヤ',
            'sjis' => '1b24462d0f',
            'name_en' => 'Diamond',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image013.gif'
          },
          {
            'number' => '194',
            'unicode' => 'E20E',
            'sjis_auto' => 'F7AE',
            'name' => 'スペード',
            'sjis' => '1b24462e0f',
            'name_en' => 'Spade',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image014.gif'
          },
          {
            'number' => '195',
            'unicode' => 'E20F',
            'sjis_auto' => 'F7AF',
            'name' => 'クラブ',
            'sjis' => '1b24462f0f',
            'name_en' => 'Club',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image015.gif'
          },
          {
            'number' => '196',
            'unicode' => 'E210',
            'sjis_auto' => 'F7B0',
            'name' => 'シャープダイヤル',
            'sjis' => '1b2446300f',
            'name_en' => 'Sharp dial',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image016.gif'
          },
          {
            'number' => '197',
            'unicode' => 'E211',
            'sjis_auto' => 'F7B1',
            'name' => 'フリーダイヤル',
            'sjis' => '1b2446310f',
            'name_en' => 'Free dial',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image017.gif'
          },
          {
            'number' => '198',
            'unicode' => 'E212',
            'sjis_auto' => 'F7B2',
            'name' => '新着',
            'sjis' => '1b2446320f',
            'name_en' => 'New',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image018.gif'
          },
          {
            'number' => '199',
            'unicode' => 'E213',
            'sjis_auto' => 'F7B3',
            'name' => '更新',
            'sjis' => '1b2446330f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image019.gif'
          },
          {
            'number' => '200',
            'unicode' => 'E214',
            'sjis_auto' => 'F7B4',
            'name' => 'おすすめ',
            'sjis' => '1b2446340f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image020.gif'
          },
          {
            'number' => '201',
            'unicode' => 'E215',
            'sjis_auto' => 'F7B5',
            'name' => '有料',
            'sjis' => '1b2446350f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image021.gif'
          },
          {
            'number' => '202',
            'unicode' => 'E216',
            'sjis_auto' => 'F7B6',
            'name' => '無料',
            'sjis' => '1b2446360f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image022.gif'
          },
          {
            'number' => '203',
            'unicode' => 'E217',
            'sjis_auto' => 'F7B7',
            'name' => '月額',
            'sjis' => '1b2446370f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image023.gif'
          },
          {
            'number' => '204',
            'unicode' => 'E218',
            'sjis_auto' => 'F7B8',
            'name' => '申し込み',
            'sjis' => '1b2446380f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image024.gif'
          },
          {
            'number' => '205',
            'unicode' => 'E219',
            'sjis_auto' => 'F7B9',
            'name' => '見出しボタン1',
            'sjis' => '1b2446390f',
            'name_en' => 'New moon',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-F39.gif'
          },
          {
            'number' => '206',
            'unicode' => 'E21A',
            'sjis_auto' => 'F7BA',
            'name' => '見出しボタン2',
            'sjis' => '1b24463a0f',
            'name_en' => 'New moon',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image027.gif'
          },
          {
            'number' => '207',
            'unicode' => 'E21B',
            'sjis_auto' => 'F7BB',
            'name' => '見出しボタン3',
            'sjis' => '1b24463b0f',
            'name_en' => 'New moon',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image028.gif'
          },
          {
            'number' => '208',
            'unicode' => 'E21C',
            'sjis_auto' => 'F7BC',
            'name' => '1ボタン',
            'sjis' => '1b24463c0f',
            'name_en' => '1',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image029.gif'
          },
          {
            'number' => '209',
            'unicode' => 'E21D',
            'sjis_auto' => 'F7BD',
            'name' => '2ボタン',
            'sjis' => '1b24463d0f',
            'name_en' => '2',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image030.gif'
          },
          {
            'number' => '210',
            'unicode' => 'E21E',
            'sjis_auto' => 'F7BE',
            'name' => '3ボタン',
            'sjis' => '1b24463e0f',
            'name_en' => '3',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image031.gif'
          },
          {
            'number' => '211',
            'unicode' => 'E21F',
            'sjis_auto' => 'F7BF',
            'name' => '4ボタン',
            'sjis' => '1b24463f0f',
            'name_en' => '4',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image032.gif'
          },
          {
            'number' => '212',
            'unicode' => 'E220',
            'sjis_auto' => 'F7C0',
            'name' => '5ボタン',
            'sjis' => '1b2446400f',
            'name_en' => '5',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image033.gif'
          },
          {
            'number' => '213',
            'unicode' => 'E221',
            'sjis_auto' => 'F7C1',
            'name' => '6ボタン',
            'sjis' => '1b2446410f',
            'name_en' => '6',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image034.gif'
          },
          {
            'number' => '214',
            'unicode' => 'E222',
            'sjis_auto' => 'F7C2',
            'name' => '7ボタン',
            'sjis' => '1b2446420f',
            'name_en' => '7',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image035.gif'
          },
          {
            'number' => '215',
            'unicode' => 'E223',
            'sjis_auto' => 'F7C3',
            'name' => '8ボタン',
            'sjis' => '1b2446430f',
            'name_en' => '8',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image036.gif'
          },
          {
            'number' => '216',
            'unicode' => 'E224',
            'sjis_auto' => 'F7C4',
            'name' => '9ボタン',
            'sjis' => '1b2446440f',
            'name_en' => '9',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image037.gif'
          },
          {
            'number' => '217',
            'unicode' => 'E225',
            'sjis_auto' => 'F7C5',
            'name' => '0ボタン',
            'sjis' => '1b2446450f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image038.gif'
          },
          {
            'number' => '218',
            'unicode' => 'E226',
            'sjis_auto' => 'F7C6',
            'name' => 'お得',
            'sjis' => '1b2446460f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image039.gif'
          },
          {
            'number' => '219',
            'unicode' => 'E227',
            'sjis_auto' => 'F7C7',
            'name' => '割引',
            'sjis' => '1b2446470f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image040.gif'
          },
          {
            'number' => '220',
            'unicode' => 'E228',
            'sjis_auto' => 'F7C8',
            'name' => 'サービス料',
            'sjis' => '1b2446480f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image041.gif'
          },
          {
            'number' => '221',
            'unicode' => 'E229',
            'sjis_auto' => 'F7C9',
            'name' => 'ID',
            'sjis' => '1b2446490f',
            'name_en' => 'ID',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image042.gif'
          },
          {
            'number' => '222',
            'unicode' => 'E22A',
            'sjis_auto' => 'F7CA',
            'name' => '満席',
            'sjis' => '1b24464a0f',
            'name_en' => 'Full',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image043.gif'
          },
          {
            'number' => '223',
            'unicode' => 'E22B',
            'sjis_auto' => 'F7CB',
            'name' => '空席',
            'sjis' => '1b24464b0f',
            'name_en' => 'Vacant',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image044.gif'
          },
          {
            'number' => '224',
            'unicode' => 'E22C',
            'sjis_auto' => 'F7CC',
            'name' => '指定席',
            'sjis' => '1b24464c0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image045.gif'
          },
          {
            'number' => '225',
            'unicode' => 'E22D',
            'sjis_auto' => 'F7CD',
            'name' => '営業時間',
            'sjis' => '1b24464d0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image046.gif'
          },
          {
            'number' => '226',
            'unicode' => 'E22E',
            'sjis_auto' => 'F7CE',
            'name' => '上へ',
            'sjis' => '1b24464e0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image047.gif'
          },
          {
            'number' => '227',
            'unicode' => 'E22F',
            'sjis_auto' => 'F7CF',
            'name' => '下へ',
            'sjis' => '1b24464f0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image048.gif'
          },
          {
            'number' => '228',
            'unicode' => 'E230',
            'sjis_auto' => 'F7D0',
            'name' => '左へ',
            'sjis' => '1b2446500f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image049.gif'
          },
          {
            'number' => '229',
            'unicode' => 'E231',
            'sjis_auto' => 'F7D1',
            'name' => '右へ',
            'sjis' => '1b2446510f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image050.gif'
          },
          {
            'number' => '230',
            'unicode' => 'E232',
            'sjis_auto' => 'F7D2',
            'name' => '上',
            'sjis' => '1b2446520f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image051.gif'
          },
          {
            'number' => '231',
            'unicode' => 'E233',
            'sjis_auto' => 'F7D3',
            'name' => '下',
            'sjis' => '1b2446530f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image052.gif'
          },
          {
            'number' => '232',
            'unicode' => 'E234',
            'sjis_auto' => 'F7D4',
            'name' => '右',
            'sjis' => '1b2446540f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image053.gif'
          },
          {
            'number' => '233',
            'unicode' => 'E235',
            'sjis_auto' => 'F7D5',
            'name' => '左',
            'sjis' => '1b2446550f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image054.gif'
          },
          {
            'number' => '234',
            'unicode' => 'E236',
            'sjis_auto' => 'F7D6',
            'name' => '右上',
            'sjis' => '1b2446560f',
            'name_en' => 'Diagonally upward toward right',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image055.gif'
          },
          {
            'number' => '235',
            'unicode' => 'E237',
            'sjis_auto' => 'F7D7',
            'name' => '左上',
            'sjis' => '1b2446570f',
            'name_en' => 'Diagonally upward toward left',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image056.gif'
          },
          {
            'number' => '236',
            'unicode' => 'E238',
            'sjis_auto' => 'F7D8',
            'name' => '右下',
            'sjis' => '1b2446580f',
            'name_en' => 'Diagonally downward toward right',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image057.gif'
          },
          {
            'number' => '237',
            'unicode' => 'E239',
            'sjis_auto' => 'F7D9',
            'name' => '左下',
            'sjis' => '1b2446590f',
            'name_en' => 'Diagonally downward toward left',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image058.gif'
          },
          {
            'number' => '238',
            'unicode' => 'E23A',
            'sjis_auto' => 'F7DA',
            'name' => '次へ',
            'sjis' => '1b24465a0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image059.gif'
          },
          {
            'number' => '239',
            'unicode' => 'E23B',
            'sjis_auto' => 'F7DB',
            'name' => '前へ',
            'sjis' => '1b24465b0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image060.gif'
          },
          {
            'number' => '240',
            'unicode' => 'E23C',
            'sjis_auto' => 'F7DC',
            'name' => '早送り',
            'sjis' => '1b24465c0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image061.gif'
          },
          {
            'number' => '241',
            'unicode' => 'E23D',
            'sjis_auto' => 'F7DD',
            'name' => '巻戻し',
            'sjis' => '1b24465d0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image062.gif'
          },
          {
            'number' => '242',
            'unicode' => 'E23E',
            'sjis_auto' => 'F7DE',
            'name' => '星座',
            'sjis' => '1b24465e0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image063.gif'
          },
          {
            'number' => '243',
            'unicode' => 'E23F',
            'sjis_auto' => 'F7DF',
            'name' => 'おひつじ座',
            'sjis' => '1b24465f0f',
            'name_en' => 'Aries',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image064.gif'
          },
          {
            'number' => '244',
            'unicode' => 'E240',
            'sjis_auto' => 'F7E0',
            'name' => 'おうし座',
            'sjis' => '1b2446600f',
            'name_en' => 'Taurus',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image065.gif'
          },
          {
            'number' => '245',
            'unicode' => 'E241',
            'sjis_auto' => 'F7E1',
            'name' => 'ふたご座',
            'sjis' => '1b2446610f',
            'name_en' => 'Gemini',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image066.gif'
          },
          {
            'number' => '246',
            'unicode' => 'E242',
            'sjis_auto' => 'F7E2',
            'name' => 'かに座',
            'sjis' => '1b2446620f',
            'name_en' => 'Cancer',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image067.gif'
          },
          {
            'number' => '247',
            'unicode' => 'E243',
            'sjis_auto' => 'F7E3',
            'name' => 'しし座',
            'sjis' => '1b2446630f',
            'name_en' => 'Leo',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image068.gif'
          },
          {
            'number' => '248',
            'unicode' => 'E244',
            'sjis_auto' => 'F7E4',
            'name' => 'おとめ座',
            'sjis' => '1b2446640f',
            'name_en' => 'Virgo',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image069.gif'
          },
          {
            'number' => '249',
            'unicode' => 'E245',
            'sjis_auto' => 'F7E5',
            'name' => 'てんびん座',
            'sjis' => '1b2446650f',
            'name_en' => 'Libra',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image070.gif'
          },
          {
            'number' => '250',
            'unicode' => 'E246',
            'sjis_auto' => 'F7E6',
            'name' => 'さそり座',
            'sjis' => '1b2446660f',
            'name_en' => 'Scorpio',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image071.gif'
          },
          {
            'number' => '251',
            'unicode' => 'E247',
            'sjis_auto' => 'F7E7',
            'name' => 'いて座',
            'sjis' => '1b2446670f',
            'name_en' => 'Sagittarius',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image072.gif'
          },
          {
            'number' => '252',
            'unicode' => 'E248',
            'sjis_auto' => 'F7E8',
            'name' => 'やぎ座',
            'sjis' => '1b2446680f',
            'name_en' => 'Capricorn',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image073.gif'
          },
          {
            'number' => '253',
            'unicode' => 'E249',
            'sjis_auto' => 'F7E9',
            'name' => 'みずがめ座',
            'sjis' => '1b2446690f',
            'name_en' => 'Aquarius',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image074.gif'
          },
          {
            'number' => '254',
            'unicode' => 'E24A',
            'sjis_auto' => 'F7EA',
            'name' => 'うお座',
            'sjis' => '1b24466a0f',
            'name_en' => 'Pisces',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image075.gif'
          },
          {
            'number' => '255',
            'unicode' => 'E24B',
            'sjis_auto' => 'F7EB',
            'name' => 'へびつかい座',
            'sjis' => '1b24466b0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image076.gif'
          },
          {
            'number' => '256',
            'unicode' => 'E24C',
            'sjis_auto' => 'F7EC',
            'name' => 'TOPページ',
            'sjis' => '1b24466c0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image077.gif'
          },
          {
            'number' => '257',
            'unicode' => 'E24D',
            'sjis_auto' => 'F7ED',
            'name' => 'OKボタン',
            'sjis' => '1b24466d0f',
            'name_en' => 'Accept',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image078.gif'
          },
          {
            'number' => '258',
            'unicode' => 'E24E',
            'sjis_auto' => 'F7EE',
            'name' => '著作権',
            'sjis' => '1b24466e0f',
            'name_en' => 'Copyright',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image079.gif'
          },
          {
            'number' => '259',
            'unicode' => 'E24F',
            'sjis_auto' => 'F7EF',
            'name' => '登録商標',
            'sjis' => '1b24466f0f',
            'name_en' => 'Registered trademark',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image080.gif'
          },
          {
            'number' => '260',
            'unicode' => 'E250',
            'sjis_auto' => 'F7F0',
            'name' => 'マナーモード',
            'sjis' => '1b2446700f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image081.gif'
          },
          {
            'number' => '261',
            'unicode' => 'E251',
            'sjis_auto' => 'F7F1',
            'name' => '電源切',
            'sjis' => '1b2446710f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image082.gif'
          },
          {
            'number' => '262',
            'unicode' => 'E252',
            'sjis_auto' => 'F7F2',
            'name' => 'ご注意',
            'sjis' => '1b2446720f',
            'name_en' => 'Danger / Caution',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image083.gif'
          },
          {
            'number' => '263',
            'unicode' => 'E253',
            'sjis_auto' => 'F7F3',
            'name' => 'ご案内',
            'sjis' => '1b2446730f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_20251_image084.gif'
          },
          {
            'number' => '264',
            'unicode' => 'E255',
            'sjis_auto' => undef,
            'name' => 'スカイウェイブ',
            'sjis' => '1b2446750f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-F75.gif'
          },
          {
            'number' => '265',
            'unicode' => 'E256',
            'sjis_auto' => undef,
            'name' => 'スカイウォーカー',
            'sjis' => '1b2446760f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-F76.gif'
          },
          {
            'number' => '266',
            'unicode' => 'E257',
            'sjis_auto' => undef,
            'name' => 'スカイメロディ',
            'sjis' => '1b2446770f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c15-F77.gif'
          },
          {
            'number' => '271',
            'unicode' => 'E301',
            'sjis_auto' => 'F9A1',
            'name' => 'メモ',
            'sjis' => '1b244f210f',
            'name_en' => 'Memo',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image002.gif'
          },
          {
            'number' => '272',
            'unicode' => 'E302',
            'sjis_auto' => 'F9A2',
            'name' => 'ネクタイ',
            'sjis' => '1b244f220f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image004.gif'
          },
          {
            'number' => '273',
            'unicode' => 'E303',
            'sjis_auto' => 'F9A3',
            'name' => 'ハイビスカス',
            'sjis' => '1b244f230f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image006.gif'
          },
          {
            'number' => '274',
            'unicode' => 'E304',
            'sjis_auto' => 'F9A4',
            'name' => 'チューリップ',
            'sjis' => '1b244f240f',
            'name_en' => 'Tulip',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image008.gif'
          },
          {
            'number' => '275',
            'unicode' => 'E305',
            'sjis_auto' => 'F9A5',
            'name' => 'ひまわり',
            'sjis' => '1b244f250f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image010.gif'
          },
          {
            'number' => '276',
            'unicode' => 'E306',
            'sjis_auto' => 'F9A6',
            'name' => '花束',
            'sjis' => '1b244f260f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image012.gif'
          },
          {
            'number' => '277',
            'unicode' => 'E307',
            'sjis_auto' => 'F9A7',
            'name' => 'やしの木',
            'sjis' => '1b244f270f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image014.gif'
          },
          {
            'number' => '278',
            'unicode' => 'E308',
            'sjis_auto' => 'F9A8',
            'name' => 'サボテン',
            'sjis' => '1b244f280f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image016.gif'
          },
          {
            'number' => '279',
            'unicode' => 'E309',
            'sjis_auto' => 'F9A9',
            'name' => 'トイレ',
            'sjis' => '1b244f290f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image018.gif'
          },
          {
            'number' => '280',
            'unicode' => 'E30A',
            'sjis_auto' => 'F9AA',
            'name' => 'ヘッドフォン',
            'sjis' => '1b244f2a0f',
            'name_en' => 'Music',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image020.gif'
          },
          {
            'number' => '281',
            'unicode' => 'E30B',
            'sjis_auto' => 'F9AB',
            'name' => '晩酌',
            'sjis' => '1b244f2b0f',
            'name_en' => 'Sake bottle (sake cup)',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image022.gif'
          },
          {
            'number' => '282',
            'unicode' => 'E30C',
            'sjis_auto' => 'F9AC',
            'name' => '乾杯',
            'sjis' => '1b244f2c0f',
            'name_en' => 'Beer',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/a12.gif'
          },
          {
            'number' => '283',
            'unicode' => 'E30D',
            'sjis_auto' => 'F9AD',
            'name' => '祝',
            'sjis' => '1b244f2d0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image026.gif'
          },
          {
            'number' => '284',
            'unicode' => 'E30E',
            'sjis_auto' => 'F9AE',
            'name' => '喫煙',
            'sjis' => '1b244f2e0f',
            'name_en' => 'Smoking',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image028.gif'
          },
          {
            'number' => '285',
            'unicode' => 'E30F',
            'sjis_auto' => 'F9AF',
            'name' => 'カプセル薬',
            'sjis' => '1b244f2f0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image030.gif'
          },
          {
            'number' => '286',
            'unicode' => 'E310',
            'sjis_auto' => 'F9B0',
            'name' => '風船',
            'sjis' => '1b244f300f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/a16.gif'
          },
          {
            'number' => '287',
            'unicode' => 'E311',
            'sjis_auto' => 'F9B1',
            'name' => '爆弾',
            'sjis' => '1b244f310f',
            'name_en' => 'Bomb',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/a17.gif'
          },
          {
            'number' => '288',
            'unicode' => 'E312',
            'sjis_auto' => 'F9B2',
            'name' => 'クラッカー',
            'sjis' => '1b244f320f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/a18.gif'
          },
          {
            'number' => '289',
            'unicode' => 'E313',
            'sjis_auto' => 'F9B3',
            'name' => 'ハサミ',
            'sjis' => '1b244f330f',
            'name_en' => 'Hairdresser',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/a19.gif'
          },
          {
            'number' => '290',
            'unicode' => 'E314',
            'sjis_auto' => 'F9B4',
            'name' => 'リボン',
            'sjis' => '1b244f340f',
            'name_en' => 'Ribbon',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image040.gif'
          },
          {
            'number' => '291',
            'unicode' => 'E315',
            'sjis_auto' => 'F9B5',
            'name' => 'マル秘',
            'sjis' => '1b244f350f',
            'name_en' => 'Top secret',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image042.gif'
          },
          {
            'number' => '292',
            'unicode' => 'E316',
            'sjis_auto' => 'F9B6',
            'name' => 'MD',
            'sjis' => '1b244f360f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image044.gif'
          },
          {
            'number' => '293',
            'unicode' => 'E317',
            'sjis_auto' => 'F9B7',
            'name' => 'メガフォン',
            'sjis' => '1b244f370f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/a23.gif'
          },
          {
            'number' => '294',
            'unicode' => 'E318',
            'sjis_auto' => 'F9B8',
            'name' => '帽子',
            'sjis' => '1b244f380f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image048.gif'
          },
          {
            'number' => '295',
            'unicode' => 'E319',
            'sjis_auto' => 'F9B9',
            'name' => '可愛いワンピース',
            'sjis' => '1b244f390f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image050.gif'
          },
          {
            'number' => '296',
            'unicode' => 'E31A',
            'sjis_auto' => 'F9BA',
            'name' => 'ミュール',
            'sjis' => '1b244f3a0f',
            'name_en' => 'Boutique',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image052.gif'
          },
          {
            'number' => '297',
            'unicode' => 'E31B',
            'sjis_auto' => 'F9BB',
            'name' => 'ロングブーツ',
            'sjis' => '1b244f3b0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image054.gif'
          },
          {
            'number' => '298',
            'unicode' => 'E31C',
            'sjis_auto' => 'F9BC',
            'name' => '口紅',
            'sjis' => '1b244f3c0f',
            'name_en' => 'Make-up',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image056.gif'
          },
          {
            'number' => '299',
            'unicode' => 'E31D',
            'sjis_auto' => 'F9BD',
            'name' => 'マニュキア',
            'sjis' => '1b244f3d0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image058.gif'
          },
          {
            'number' => '300',
            'unicode' => 'E31E',
            'sjis_auto' => 'F9BE',
            'name' => 'エステ',
            'sjis' => '1b244f3e0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/a30.gif'
          },
          {
            'number' => '301',
            'unicode' => 'E31F',
            'sjis_auto' => 'F9BF',
            'name' => '美容院',
            'sjis' => '1b244f3f0f',
            'name_en' => 'Hairdresser',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/a31.gif'
          },
          {
            'number' => '302',
            'unicode' => 'E320',
            'sjis_auto' => 'F9C0',
            'name' => '理容院',
            'sjis' => '1b244f400f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/a32.gif'
          },
          {
            'number' => '303',
            'unicode' => 'E321',
            'sjis_auto' => 'F9C1',
            'name' => '着物',
            'sjis' => '1b244f410f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image066.gif'
          },
          {
            'number' => '304',
            'unicode' => 'E322',
            'sjis_auto' => 'F9C2',
            'name' => 'ビキニ',
            'sjis' => '1b244f420f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image068.gif'
          },
          {
            'number' => '305',
            'unicode' => 'E323',
            'sjis_auto' => 'F9C3',
            'name' => 'ブランドバック',
            'sjis' => '1b244f430f',
            'name_en' => 'Bag',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image070.gif'
          },
          {
            'number' => '306',
            'unicode' => 'E324',
            'sjis_auto' => 'F9C4',
            'name' => 'カチンコ',
            'sjis' => '1b244f440f',
            'name_en' => 'Clapboard',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image072.gif'
          },
          {
            'number' => '307',
            'unicode' => 'E325',
            'sjis_auto' => 'F9C5',
            'name' => 'すず',
            'sjis' => '1b244f450f',
            'name_en' => 'Chapel',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/a37.gif'
          },
          {
            'number' => '308',
            'unicode' => 'E326',
            'sjis_auto' => 'F9C6',
            'name' => '踊る音符',
            'sjis' => '1b244f460f',
            'name_en' => 'Mood',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/a38.gif'
          },
          {
            'number' => '309',
            'unicode' => 'E327',
            'sjis_auto' => 'F9C7',
            'name' => 'ぴかぴかハート',
            'sjis' => '1b244f470f',
            'name_en' => 'Black heart',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/a39.gif'
          },
          {
            'number' => '310',
            'unicode' => 'E328',
            'sjis_auto' => 'F9C8',
            'name' => 'どきどきハート',
            'sjis' => '1b244f480f',
            'name_en' => 'Fluttering heart',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/a40.gif'
          },
          {
            'number' => '311',
            'unicode' => 'E329',
            'sjis_auto' => 'F9C9',
            'name' => 'ハートを射とめて',
            'sjis' => '1b244f490f',
            'name_en' => 'Black heart',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/a41.gif'
          },
          {
            'number' => '312',
            'unicode' => 'E32A',
            'sjis_auto' => 'F9CA',
            'name' => 'ハート:青',
            'sjis' => '1b244f4a0f',
            'name_en' => 'Black heart',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image084.gif'
          },
          {
            'number' => '313',
            'unicode' => 'E32B',
            'sjis_auto' => 'F9CB',
            'name' => 'ハート:緑',
            'sjis' => '1b244f4b0f',
            'name_en' => 'Black heart',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image086.gif'
          },
          {
            'number' => '314',
            'unicode' => 'E32C',
            'sjis_auto' => 'F9CC',
            'name' => 'ハート:黄',
            'sjis' => '1b244f4c0f',
            'name_en' => 'Black heart',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image088.gif'
          },
          {
            'number' => '315',
            'unicode' => 'E32D',
            'sjis_auto' => 'F9CD',
            'name' => 'ハート:紫',
            'sjis' => '1b244f4d0f',
            'name_en' => 'Black heart',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image090.gif'
          },
          {
            'number' => '316',
            'unicode' => 'E32E',
            'sjis_auto' => 'F9CE',
            'name' => 'NEW',
            'sjis' => '1b244f4e0f',
            'name_en' => 'Shining new',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/a46.gif'
          },
          {
            'number' => '317',
            'unicode' => 'E32F',
            'sjis_auto' => 'F9CF',
            'name' => '☆',
            'sjis' => '1b244f4f0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image094.gif'
          },
          {
            'number' => '318',
            'unicode' => 'E330',
            'sjis_auto' => 'F9D0',
            'name' => 'ダッシュ',
            'sjis' => '1b244f500f',
            'name_en' => 'Dash (running dash)',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image096.gif'
          },
          {
            'number' => '319',
            'unicode' => 'E331',
            'sjis_auto' => 'F9D1',
            'name' => '飛び散る汗',
            'sjis' => '1b244f510f',
            'name_en' => 'Sweat',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image098.gif'
          },
          {
            'number' => '320',
            'unicode' => 'E332',
            'sjis_auto' => 'F9D2',
            'name' => '○',
            'sjis' => '1b244f520f',
            'name_en' => 'Full moon',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image100.gif'
          },
          {
            'number' => '321',
            'unicode' => 'E333',
            'sjis_auto' => 'F9D3',
            'name' => '×',
            'sjis' => '1b244f530f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image102.gif'
          },
          {
            'number' => '322',
            'unicode' => 'E334',
            'sjis_auto' => 'F9D4',
            'name' => '怒り',
            'sjis' => '1b244f540f',
            'name_en' => 'Angry',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image104.gif'
          },
          {
            'number' => '323',
            'unicode' => 'E335',
            'sjis_auto' => 'F9D5',
            'name' => '☆(点滅)',
            'sjis' => '1b244f550f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/a53.gif'
          },
          {
            'number' => '324',
            'unicode' => 'E336',
            'sjis_auto' => 'F9D6',
            'name' => '動く"?"',
            'sjis' => '1b244f560f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/a54.gif'
          },
          {
            'number' => '325',
            'unicode' => 'E337',
            'sjis_auto' => 'F9D7',
            'name' => '動く"!"',
            'sjis' => '1b244f570f',
            'name_en' => 'Exclamation mark',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/a55.gif'
          },
          {
            'number' => '326',
            'unicode' => 'E338',
            'sjis_auto' => 'F9D8',
            'name' => 'お茶',
            'sjis' => '1b244f580f',
            'name_en' => 'Tea cup',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image112.gif'
          },
          {
            'number' => '327',
            'unicode' => 'E339',
            'sjis_auto' => 'F9D9',
            'name' => 'パン',
            'sjis' => '1b244f590f',
            'name_en' => 'Bread',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image114.gif'
          },
          {
            'number' => '328',
            'unicode' => 'E33A',
            'sjis_auto' => 'F9DA',
            'name' => 'ソフトクリーム',
            'sjis' => '1b244f5a0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image116.gif'
          },
          {
            'number' => '329',
            'unicode' => 'E33B',
            'sjis_auto' => 'F9DB',
            'name' => 'フライドポテト',
            'sjis' => '1b244f5b0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image118.gif'
          },
          {
            'number' => '330',
            'unicode' => 'E33C',
            'sjis_auto' => 'F9DC',
            'name' => '串団子',
            'sjis' => '1b244f5c0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image120.gif'
          },
          {
            'number' => '331',
            'unicode' => 'E33D',
            'sjis_auto' => 'F9DD',
            'name' => 'せんべい',
            'sjis' => '1b244f5d0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image122.gif'
          },
          {
            'number' => '332',
            'unicode' => 'E33E',
            'sjis_auto' => 'F9DE',
            'name' => 'ご飯',
            'sjis' => '1b244f5e0f',
            'name_en' => 'Bowl',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image124.gif'
          },
          {
            'number' => '333',
            'unicode' => 'E33F',
            'sjis_auto' => 'F9DF',
            'name' => 'スパゲッティ',
            'sjis' => '1b244f5f0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image126.gif'
          },
          {
            'number' => '334',
            'unicode' => 'E340',
            'sjis_auto' => 'F9E0',
            'name' => 'ラーメン',
            'sjis' => '1b244f600f',
            'name_en' => 'Bowl',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image128.gif'
          },
          {
            'number' => '335',
            'unicode' => 'E341',
            'sjis_auto' => 'F9E1',
            'name' => 'カレーライス',
            'sjis' => '1b244f610f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image130.gif'
          },
          {
            'number' => '336',
            'unicode' => 'E342',
            'sjis_auto' => 'F9E2',
            'name' => 'おにぎり',
            'sjis' => '1b244f620f',
            'name_en' => 'Rice ball',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image132.gif'
          },
          {
            'number' => '337',
            'unicode' => 'E343',
            'sjis_auto' => 'F9E3',
            'name' => 'おでん',
            'sjis' => '1b244f630f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image134.gif'
          },
          {
            'number' => '338',
            'unicode' => 'E344',
            'sjis_auto' => 'F9E4',
            'name' => '寿司',
            'sjis' => '1b244f640f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image136.gif'
          },
          {
            'number' => '339',
            'unicode' => 'E345',
            'sjis_auto' => 'F9E5',
            'name' => 'りんご',
            'sjis' => '1b244f650f',
            'name_en' => 'Apple',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image138.gif'
          },
          {
            'number' => '340',
            'unicode' => 'E346',
            'sjis_auto' => 'F9E6',
            'name' => 'みかん',
            'sjis' => '1b244f660f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image140.gif'
          },
          {
            'number' => '341',
            'unicode' => 'E347',
            'sjis_auto' => 'F9E7',
            'name' => 'いちご',
            'sjis' => '1b244f670f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image142.gif'
          },
          {
            'number' => '342',
            'unicode' => 'E348',
            'sjis_auto' => 'F9E8',
            'name' => 'すいか',
            'sjis' => '1b244f680f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image144.gif'
          },
          {
            'number' => '343',
            'unicode' => 'E349',
            'sjis_auto' => 'F9E9',
            'name' => 'トマト',
            'sjis' => '1b244f690f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image146.gif'
          },
          {
            'number' => '344',
            'unicode' => 'E34A',
            'sjis_auto' => 'F9EA',
            'name' => 'なす',
            'sjis' => '1b244f6a0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image148.gif'
          },
          {
            'number' => '345',
            'unicode' => 'E34B',
            'sjis_auto' => 'F9EB',
            'name' => 'バースデーケーキ',
            'sjis' => '1b244f6b0f',
            'name_en' => 'Birthday',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/b20.gif'
          },
          {
            'number' => '346',
            'unicode' => 'E34C',
            'sjis_auto' => 'F9EC',
            'name' => '駅弁',
            'sjis' => '1b244f6c0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image152.gif'
          },
          {
            'number' => '347',
            'unicode' => 'E34D',
            'sjis_auto' => 'F9ED',
            'name' => 'ナベ',
            'sjis' => '1b244f6d0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/Emoji_25G_Ver02_02_7799_image154.gif'
          },
          {
            'number' => '348',
            'unicode' => 'E401',
            'sjis_auto' => 'FB41',
            'name' => 'あせり',
            'sjis' => '1b2450210f',
            'name_en' => 'Cold sweat 2',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image016.gif'
          },
          {
            'number' => '349',
            'unicode' => 'E402',
            'sjis_auto' => 'FB42',
            'name' => 'ほくそえんでいる',
            'sjis' => '1b2450220f',
            'name_en' => 'Cat 2',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image017.gif'
          },
          {
            'number' => '350',
            'unicode' => 'E403',
            'sjis_auto' => 'FB43',
            'name' => 'ひたすらごめんなさい',
            'sjis' => '1b2450230f',
            'name_en' => 'Thinking face',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image018.gif'
          },
          {
            'number' => '351',
            'unicode' => 'E404',
            'sjis_auto' => 'FB44',
            'name' => 'えっへん',
            'sjis' => '1b2450240f',
            'name_en' => 'He he he',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image019.gif'
          },
          {
            'number' => '352',
            'unicode' => 'E405',
            'sjis_auto' => 'FB45',
            'name' => 'ウィンク',
            'sjis' => '1b2450250f',
            'name_en' => 'Wink',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image020.gif'
          },
          {
            'number' => '353',
            'unicode' => 'E406',
            'sjis_auto' => 'FB46',
            'name' => 'わさびがきいた',
            'sjis' => '1b2450260f',
            'name_en' => 'Enduring face',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image021.gif'
          },
          {
            'number' => '354',
            'unicode' => 'E407',
            'sjis_auto' => 'FB47',
            'name' => '目がぐるぐる',
            'sjis' => '1b2450270f',
            'name_en' => 'Sad face',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image022.gif'
          },
          {
            'number' => '355',
            'unicode' => 'E408',
            'sjis_auto' => 'FB48',
            'name' => '鼻ちょうちん',
            'sjis' => '1b2450280f',
            'name_en' => 'Sleepy (sleep)',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image023.gif'
          },
          {
            'number' => '356',
            'unicode' => 'E409',
            'sjis_auto' => 'FB49',
            'name' => 'あっかんべー',
            'sjis' => '1b2450290f',
            'name_en' => 'Sticking tongue out',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c09.gif'
          },
          {
            'number' => '357',
            'unicode' => 'E40A',
            'sjis_auto' => 'FB4A',
            'name' => '酔っぱらい',
            'sjis' => '1b24502a0f',
            'name_en' => 'Relief face',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image025.gif'
          },
          {
            'number' => '358',
            'unicode' => 'E40B',
            'sjis_auto' => 'FB4B',
            'name' => 'ゲロゲロ',
            'sjis' => '1b24502b0f',
            'name_en' => 'Very thin',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image026.gif'
          },
          {
            'number' => '359',
            'unicode' => 'E40C',
            'sjis_auto' => 'FB4C',
            'name' => 'マスクをつけた顔',
            'sjis' => '1b24502c0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image027.gif'
          },
          {
            'number' => '360',
            'unicode' => 'E40D',
            'sjis_auto' => 'FB4D',
            'name' => '顔があかくなる',
            'sjis' => '1b24502d0f',
            'name_en' => 'Happy face',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c13.gif'
          },
          {
            'number' => '361',
            'unicode' => 'E40E',
            'sjis_auto' => 'FB4E',
            'name' => 'しらけ顔',
            'sjis' => '1b24502e0f',
            'name_en' => 'Expressionless face',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image029.gif'
          },
          {
            'number' => '362',
            'unicode' => 'E40F',
            'sjis_auto' => 'FB4F',
            'name' => '冷や汗',
            'sjis' => '1b24502f0f',
            'name_en' => 'Cold sweat 2',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image030.gif'
          },
          {
            'number' => '363',
            'unicode' => 'E410',
            'sjis_auto' => 'FB50',
            'name' => 'びっくり',
            'sjis' => '1b2450300f',
            'name_en' => 'Dizzy',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image034.gif'
          },
          {
            'number' => '364',
            'unicode' => 'E411',
            'sjis_auto' => 'FB51',
            'name' => '泣き',
            'sjis' => '1b2450310f',
            'name_en' => 'Crying',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image035.gif'
          },
          {
            'number' => '365',
            'unicode' => 'E412',
            'sjis_auto' => 'FB52',
            'name' => '泣いたり笑ったり',
            'sjis' => '1b2450320f',
            'name_en' => 'Happy face',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c18.gif'
          },
          {
            'number' => '366',
            'unicode' => 'E413',
            'sjis_auto' => 'FB53',
            'name' => '可愛く泣いている人',
            'sjis' => '1b2450330f',
            'name_en' => 'Tear',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image050.gif'
          },
          {
            'number' => '367',
            'unicode' => 'E414',
            'sjis_auto' => 'FB54',
            'name' => 'にこにこ',
            'sjis' => '1b2450340f',
            'name_en' => 'Happy face',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image051.gif'
          },
          {
            'number' => '368',
            'unicode' => 'E415',
            'sjis_auto' => 'FB55',
            'name' => 'あははと笑う',
            'sjis' => '1b2450350f',
            'name_en' => 'Happy face',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image052.gif'
          },
          {
            'number' => '369',
            'unicode' => 'E416',
            'sjis_auto' => 'FB56',
            'name' => 'めちゃめちゃ怒っている',
            'sjis' => '1b2450360f',
            'name_en' => 'Pouting face',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image053.gif'
          },
          {
            'number' => '370',
            'unicode' => 'E417',
            'sjis_auto' => 'FB57',
            'name' => 'KISS:動く口',
            'sjis' => '1b2450370f',
            'name_en' => 'Heart shaped eyes',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c23.gif'
          },
          {
            'number' => '371',
            'unicode' => 'E418',
            'sjis_auto' => 'FB58',
            'name' => '投げKISS',
            'sjis' => '1b2450380f',
            'name_en' => 'Heart shaped eyes',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image055.gif'
          },
          {
            'number' => '372',
            'unicode' => 'E419',
            'sjis_auto' => 'FB59',
            'name' => '目',
            'sjis' => '1b2450390f',
            'name_en' => 'Eyes',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image056.gif'
          },
          {
            'number' => '373',
            'unicode' => 'E41A',
            'sjis_auto' => 'FB5A',
            'name' => '鼻',
            'sjis' => '1b24503a0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image057.gif'
          },
          {
            'number' => '374',
            'unicode' => 'E41B',
            'sjis_auto' => 'FB5B',
            'name' => '耳',
            'sjis' => '1b24503b0f',
            'name_en' => 'Ear',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image058.gif'
          },
          {
            'number' => '375',
            'unicode' => 'E41C',
            'sjis_auto' => 'FB5C',
            'name' => '口',
            'sjis' => '1b24503c0f',
            'name_en' => 'Kiss',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/c28.gif'
          },
          {
            'number' => '376',
            'unicode' => 'E41D',
            'sjis_auto' => 'FB5D',
            'name' => 'ごめんなさい',
            'sjis' => '1b24503d0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image060.gif'
          },
          {
            'number' => '377',
            'unicode' => 'E41E',
            'sjis_auto' => 'FB5E',
            'name' => 'バイバイ',
            'sjis' => '1b24503e0f',
            'name_en' => 'Hand (paper)',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/d02.gif'
          },
          {
            'number' => '378',
            'unicode' => 'E41F',
            'sjis_auto' => 'FB5F',
            'name' => '拍手',
            'sjis' => '1b24503f0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/d03.gif'
          },
          {
            'number' => '379',
            'unicode' => 'E420',
            'sjis_auto' => 'FB60',
            'name' => 'OK',
            'sjis' => '1b2450400f',
            'name_en' => 'Accept',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image079.gif'
          },
          {
            'number' => '380',
            'unicode' => 'E421',
            'sjis_auto' => 'FB61',
            'name' => 'Booing',
            'sjis' => '1b2450410f',
            'name_en' => 'Bad (downward arrow)',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image080.gif'
          },
          {
            'number' => '381',
            'unicode' => 'E422',
            'sjis_auto' => 'FB62',
            'name' => 'おっは〜',
            'sjis' => '1b2450420f',
            'name_en' => 'Hand (paper)',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/d06.gif'
          },
          {
            'number' => '382',
            'unicode' => 'E423',
            'sjis_auto' => 'FB63',
            'name' => '×',
            'sjis' => '1b2450430f',
            'name_en' => 'NG (No good)',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/d07.gif'
          },
          {
            'number' => '383',
            'unicode' => 'E424',
            'sjis_auto' => 'FB64',
            'name' => '○',
            'sjis' => '1b2450440f',
            'name_en' => 'Accept',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/d08.gif'
          },
          {
            'number' => '384',
            'unicode' => 'E425',
            'sjis_auto' => 'FB65',
            'name' => '手をつないでいる',
            'sjis' => '1b2450450f',
            'name_en' => 'Fluttering heart',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image084.gif'
          },
          {
            'number' => '385',
            'unicode' => 'E426',
            'sjis_auto' => 'FB66',
            'name' => '土下座',
            'sjis' => '1b2450460f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/d10.gif'
          },
          {
            'number' => '386',
            'unicode' => 'E427',
            'sjis_auto' => 'FB67',
            'name' => 'バンザイ',
            'sjis' => '1b2450470f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/d11.gif'
          },
          {
            'number' => '387',
            'unicode' => 'E428',
            'sjis_auto' => 'FB68',
            'name' => '人と人が歩いている',
            'sjis' => '1b2450480f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/d12.gif'
          },
          {
            'number' => '388',
            'unicode' => 'E429',
            'sjis_auto' => 'FB69',
            'name' => 'ラインダンス',
            'sjis' => '1b2450490f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/d13.gif'
          },
          {
            'number' => '389',
            'unicode' => 'E42A',
            'sjis_auto' => 'FB6A',
            'name' => 'バスケットボール',
            'sjis' => '1b24504a0f',
            'name_en' => 'Basketball',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image089.gif'
          },
          {
            'number' => '390',
            'unicode' => 'E42B',
            'sjis_auto' => 'FB6B',
            'name' => 'フットボール',
            'sjis' => '1b24504b0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image090.gif'
          },
          {
            'number' => '391',
            'unicode' => 'E42C',
            'sjis_auto' => 'FB6C',
            'name' => 'ビリヤード',
            'sjis' => '1b24504c0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image091.gif'
          },
          {
            'number' => '392',
            'unicode' => 'E42D',
            'sjis_auto' => 'FB6D',
            'name' => '水泳',
            'sjis' => '1b24504d0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/e04.gif'
          },
          {
            'number' => '393',
            'unicode' => 'E42E',
            'sjis_auto' => 'FB6E',
            'name' => 'RV',
            'sjis' => '1b24504e0f',
            'name_en' => 'Car (RV)',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image093.gif'
          },
          {
            'number' => '394',
            'unicode' => 'E42F',
            'sjis_auto' => 'FB6F',
            'name' => 'トラック',
            'sjis' => '1b24504f0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image094.gif'
          },
          {
            'number' => '395',
            'unicode' => 'E430',
            'sjis_auto' => 'FB70',
            'name' => '消防車',
            'sjis' => '1b2450500f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image111.gif'
          },
          {
            'number' => '396',
            'unicode' => 'E431',
            'sjis_auto' => 'FB71',
            'name' => '救急車',
            'sjis' => '1b2450510f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image112.gif'
          },
          {
            'number' => '397',
            'unicode' => 'E432',
            'sjis_auto' => 'FB72',
            'name' => 'パトカー',
            'sjis' => '1b2450520f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image113.gif'
          },
          {
            'number' => '398',
            'unicode' => 'E433',
            'sjis_auto' => 'FB73',
            'name' => 'ジェットコースター',
            'sjis' => '1b2450530f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/f06.gif'
          },
          {
            'number' => '399',
            'unicode' => 'E434',
            'sjis_auto' => 'FB74',
            'name' => '地下鉄',
            'sjis' => '1b2450540f',
            'name_en' => 'Subway',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image115.gif'
          },
          {
            'number' => '400',
            'unicode' => 'E435',
            'sjis_auto' => 'FB75',
            'name' => '新幹線(700系)',
            'sjis' => '1b2450550f',
            'name_en' => 'Bullet train',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image116.gif'
          },
          {
            'number' => '401',
            'unicode' => 'E436',
            'sjis_auto' => 'FB76',
            'name' => '門松',
            'sjis' => '1b2450560f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image117.gif'
          },
          {
            'number' => '402',
            'unicode' => 'E437',
            'sjis_auto' => 'FB77',
            'name' => 'チョコ',
            'sjis' => '1b2450570f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/g02.gif'
          },
          {
            'number' => '403',
            'unicode' => 'E438',
            'sjis_auto' => 'FB78',
            'name' => 'お雛様',
            'sjis' => '1b2450580f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image119.gif'
          },
          {
            'number' => '404',
            'unicode' => 'E439',
            'sjis_auto' => 'FB79',
            'name' => '卒業式',
            'sjis' => '1b2450590f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image120.gif'
          },
          {
            'number' => '405',
            'unicode' => 'E43A',
            'sjis_auto' => 'FB7A',
            'name' => 'ランドセル',
            'sjis' => '1b24505a0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image121.gif'
          },
          {
            'number' => '406',
            'unicode' => 'E43B',
            'sjis_auto' => 'FB7B',
            'name' => '鯉のぼり',
            'sjis' => '1b24505b0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image122.gif'
          },
          {
            'number' => '407',
            'unicode' => 'E43C',
            'sjis_auto' => 'FB7C',
            'name' => 'とじかさ',
            'sjis' => '1b24505c0f',
            'name_en' => 'Drizzle',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image123.gif'
          },
          {
            'number' => '408',
            'unicode' => 'E43D',
            'sjis_auto' => 'FB7D',
            'name' => '結婚式',
            'sjis' => '1b24505d0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image124.gif'
          },
          {
            'number' => '409',
            'unicode' => 'E43E',
            'sjis_auto' => 'FB7E',
            'name' => '波がザーン',
            'sjis' => '1b24505e0f',
            'name_en' => 'Wave',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/g09.gif'
          },
          {
            'number' => '410',
            'unicode' => 'E43F',
            'sjis_auto' => 'FB80',
            'name' => 'かき氷',
            'sjis' => '1b24505f0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image126.gif'
          },
          {
            'number' => '411',
            'unicode' => 'E440',
            'sjis_auto' => 'FB81',
            'name' => '線香花火',
            'sjis' => '1b2450600f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/g11.gif'
          },
          {
            'number' => '412',
            'unicode' => 'E441',
            'sjis_auto' => 'FB82',
            'name' => '貝',
            'sjis' => '1b2450610f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image140.gif'
          },
          {
            'number' => '413',
            'unicode' => 'E442',
            'sjis_auto' => 'FB83',
            'name' => '風鈴',
            'sjis' => '1b2450620f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/g13.gif'
          },
          {
            'number' => '414',
            'unicode' => 'E443',
            'sjis_auto' => 'FB84',
            'name' => '台風',
            'sjis' => '1b2450630f',
            'name_en' => 'Typhoon',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image142.gif'
          },
          {
            'number' => '415',
            'unicode' => 'E444',
            'sjis_auto' => 'FB85',
            'name' => '稲穂',
            'sjis' => '1b2450640f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image143.gif'
          },
          {
            'number' => '416',
            'unicode' => 'E445',
            'sjis_auto' => 'FB86',
            'name' => 'ハロウィン',
            'sjis' => '1b2450650f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image144.gif'
          },
          {
            'number' => '417',
            'unicode' => 'E446',
            'sjis_auto' => 'FB87',
            'name' => 'お月見',
            'sjis' => '1b2450660f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image145.gif'
          },
          {
            'number' => '418',
            'unicode' => 'E447',
            'sjis_auto' => 'FB88',
            'name' => '風がビュー',
            'sjis' => '1b2450670f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/g18.gif'
          },
          {
            'number' => '419',
            'unicode' => 'E448',
            'sjis_auto' => 'FB89',
            'name' => 'サンタクロース',
            'sjis' => '1b2450680f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image147.gif'
          },
          {
            'number' => '420',
            'unicode' => 'E449',
            'sjis_auto' => 'FB8A',
            'name' => '朝日',
            'sjis' => '1b2450690f',
            'name_en' => 'Fine',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image148.gif'
          },
          {
            'number' => '421',
            'unicode' => 'E44A',
            'sjis_auto' => 'FB8B',
            'name' => '夕日',
            'sjis' => '1b24506a0f',
            'name_en' => 'Fine',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image149.gif'
          },
          {
            'number' => '422',
            'unicode' => 'E44B',
            'sjis_auto' => 'FB8C',
            'name' => '流れ星',
            'sjis' => '1b24506b0f',
            'name_en' => 'Night',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/g22.gif'
          },
          {
            'number' => '423',
            'unicode' => 'E44C',
            'sjis_auto' => 'FB8D',
            'name' => '虹',
            'sjis' => '1b24506c0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/image152.gif'
          },
          {
            'number' => '424',
            'unicode' => 'E501',
            'sjis_auto' => 'FBA1',
            'name' => 'ラブホテル',
            'sjis' => '1b2451210f',
            'name_en' => 'Hotel',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image016.gif'
          },
          {
            'number' => '425',
            'unicode' => 'E502',
            'sjis_auto' => 'FBA2',
            'name' => 'アート',
            'sjis' => '1b2451220f',
            'name_en' => 'Art',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image017.gif'
          },
          {
            'number' => '426',
            'unicode' => 'E503',
            'sjis_auto' => 'FBA3',
            'name' => '演劇',
            'sjis' => '1b2451230f',
            'name_en' => 'Drama',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image018.gif'
          },
          {
            'number' => '427',
            'unicode' => 'E504',
            'sjis_auto' => 'FBA4',
            'name' => 'デパート',
            'sjis' => '1b2451240f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image019.gif'
          },
          {
            'number' => '428',
            'unicode' => 'E505',
            'sjis_auto' => 'FBA5',
            'name' => 'お城(和)',
            'sjis' => '1b2451250f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image020.gif'
          },
          {
            'number' => '429',
            'unicode' => 'E506',
            'sjis_auto' => 'FBA6',
            'name' => 'お城(洋)',
            'sjis' => '1b2451260f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image021.gif'
          },
          {
            'number' => '430',
            'unicode' => 'E507',
            'sjis_auto' => 'FBA7',
            'name' => '映画館',
            'sjis' => '1b2451270f',
            'name_en' => 'Movie',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image022.gif'
          },
          {
            'number' => '431',
            'unicode' => 'E508',
            'sjis_auto' => 'FBA8',
            'name' => '工場',
            'sjis' => '1b2451280f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image023.gif'
          },
          {
            'number' => '432',
            'unicode' => 'E509',
            'sjis_auto' => 'FBA9',
            'name' => '東京タワー',
            'sjis' => '1b2451290f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image024.gif'
          },
          {
            'number' => '433',
            'unicode' => 'E50A',
            'sjis_auto' => 'FBAA',
            'name' => '109',
            'sjis' => '1b24512a0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image025.gif'
          },
          {
            'number' => '434',
            'unicode' => 'E50B',
            'sjis_auto' => 'FBAB',
            'name' => '日本',
            'sjis' => '1b24512b0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image026.gif'
          },
          {
            'number' => '435',
            'unicode' => 'E50C',
            'sjis_auto' => 'FBAC',
            'name' => 'アメリカ',
            'sjis' => '1b24512c0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image027.gif'
          },
          {
            'number' => '436',
            'unicode' => 'E50D',
            'sjis_auto' => 'FBAD',
            'name' => 'フランス',
            'sjis' => '1b24512d0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image028.gif'
          },
          {
            'number' => '437',
            'unicode' => 'E50E',
            'sjis_auto' => 'FBAE',
            'name' => 'ドイツ',
            'sjis' => '1b24512e0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image029.gif'
          },
          {
            'number' => '438',
            'unicode' => 'E50F',
            'sjis_auto' => 'FBAF',
            'name' => 'イタリア',
            'sjis' => '1b24512f0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image030.gif'
          },
          {
            'number' => '439',
            'unicode' => 'E510',
            'sjis_auto' => 'FBB0',
            'name' => 'イギリス',
            'sjis' => '1b2451300f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image047.gif'
          },
          {
            'number' => '440',
            'unicode' => 'E511',
            'sjis_auto' => 'FBB1',
            'name' => 'スペイン',
            'sjis' => '1b2451310f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image048.gif'
          },
          {
            'number' => '441',
            'unicode' => 'E512',
            'sjis_auto' => 'FBB2',
            'name' => 'ロシア',
            'sjis' => '1b2451320f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image049.gif'
          },
          {
            'number' => '442',
            'unicode' => 'E513',
            'sjis_auto' => 'FBB3',
            'name' => '中国',
            'sjis' => '1b2451330f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image050.gif'
          },
          {
            'number' => '443',
            'unicode' => 'E514',
            'sjis_auto' => 'FBB4',
            'name' => '韓国',
            'sjis' => '1b2451340f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image051.gif'
          },
          {
            'number' => '444',
            'unicode' => 'E515',
            'sjis_auto' => 'FBB5',
            'name' => '白人',
            'sjis' => '1b2451350f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image052.gif'
          },
          {
            'number' => '445',
            'unicode' => 'E516',
            'sjis_auto' => 'FBB6',
            'name' => '中国人',
            'sjis' => '1b2451360f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image053.gif'
          },
          {
            'number' => '446',
            'unicode' => 'E517',
            'sjis_auto' => 'FBB7',
            'name' => 'インド人',
            'sjis' => '1b2451370f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image054.gif'
          },
          {
            'number' => '447',
            'unicode' => 'E518',
            'sjis_auto' => 'FBB8',
            'name' => 'おじいちゃん',
            'sjis' => '1b2451380f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image055.gif'
          },
          {
            'number' => '448',
            'unicode' => 'E519',
            'sjis_auto' => 'FBB9',
            'name' => 'おばあちゃん',
            'sjis' => '1b2451390f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image056.gif'
          },
          {
            'number' => '449',
            'unicode' => 'E51A',
            'sjis_auto' => 'FBBA',
            'name' => 'あかちゃん',
            'sjis' => '1b24513a0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image057.gif'
          },
          {
            'number' => '450',
            'unicode' => 'E51B',
            'sjis_auto' => 'FBBB',
            'name' => '安全第一',
            'sjis' => '1b24513b0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image058.gif'
          },
          {
            'number' => '451',
            'unicode' => 'E51C',
            'sjis_auto' => 'FBBC',
            'name' => 'お姫さま',
            'sjis' => '1b24513c0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image059.gif'
          },
          {
            'number' => '452',
            'unicode' => 'E51D',
            'sjis_auto' => 'FBBD',
            'name' => '自由の女神',
            'sjis' => '1b24513d0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image060.gif'
          },
          {
            'number' => '453',
            'unicode' => 'E51E',
            'sjis_auto' => 'FBBE',
            'name' => '衛兵',
            'sjis' => '1b24513e0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image061.gif'
          },
          {
            'number' => '454',
            'unicode' => 'E51F',
            'sjis_auto' => 'FBBF',
            'name' => 'フラメンコ',
            'sjis' => '1b24513f0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/i21.gif'
          },
          {
            'number' => '455',
            'unicode' => 'E520',
            'sjis_auto' => 'FBC0',
            'name' => 'イルカ',
            'sjis' => '1b2451400f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image074.gif'
          },
          {
            'number' => '456',
            'unicode' => 'E521',
            'sjis_auto' => 'FBC1',
            'name' => 'とり',
            'sjis' => '1b2451410f',
            'name_en' => 'Baby chick',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image075.gif'
          },
          {
            'number' => '457',
            'unicode' => 'E522',
            'sjis_auto' => 'FBC2',
            'name' => '熱帯魚',
            'sjis' => '1b2451420f',
            'name_en' => 'Fish',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image076.gif'
          },
          {
            'number' => '458',
            'unicode' => 'E523',
            'sjis_auto' => 'FBC3',
            'name' => 'ひよこ',
            'sjis' => '1b2451430f',
            'name_en' => 'Baby chick',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image077.gif'
          },
          {
            'number' => '459',
            'unicode' => 'E524',
            'sjis_auto' => 'FBC4',
            'name' => 'ハムスター',
            'sjis' => '1b2451440f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image078.gif'
          },
          {
            'number' => '460',
            'unicode' => 'E525',
            'sjis_auto' => 'FBC5',
            'name' => 'けむし',
            'sjis' => '1b2451450f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image079.gif'
          },
          {
            'number' => '461',
            'unicode' => 'E526',
            'sjis_auto' => 'FBC6',
            'name' => 'ぞう',
            'sjis' => '1b2451460f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image080.gif'
          },
          {
            'number' => '462',
            'unicode' => 'E527',
            'sjis_auto' => 'FBC7',
            'name' => 'こあら',
            'sjis' => '1b2451470f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image081.gif'
          },
          {
            'number' => '463',
            'unicode' => 'E528',
            'sjis_auto' => 'FBC8',
            'name' => 'チンパジー',
            'sjis' => '1b2451480f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image082.gif'
          },
          {
            'number' => '464',
            'unicode' => 'E529',
            'sjis_auto' => 'FBC9',
            'name' => 'ひつじ',
            'sjis' => '1b2451490f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image083.gif'
          },
          {
            'number' => '465',
            'unicode' => 'E52A',
            'sjis_auto' => 'FBCA',
            'name' => 'おおかみ',
            'sjis' => '1b24514a0f',
            'name_en' => 'Dog',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image084.gif'
          },
          {
            'number' => '466',
            'unicode' => 'E52B',
            'sjis_auto' => 'FBCB',
            'name' => 'うし',
            'sjis' => '1b24514b0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image100.gif'
          },
          {
            'number' => '467',
            'unicode' => 'E52C',
            'sjis_auto' => 'FBCC',
            'name' => 'うさぎ',
            'sjis' => '1b24514c0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image101.gif'
          },
          {
            'number' => '468',
            'unicode' => 'E52D',
            'sjis_auto' => 'FBCD',
            'name' => 'へび',
            'sjis' => '1b24514d0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image102.gif'
          },
          {
            'number' => '469',
            'unicode' => 'E52E',
            'sjis_auto' => 'FBCE',
            'name' => 'にわとり',
            'sjis' => '1b24514e0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image103.gif'
          },
          {
            'number' => '470',
            'unicode' => 'E52F',
            'sjis_auto' => 'FBCF',
            'name' => 'いのしし',
            'sjis' => '1b24514f0f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image104.gif'
          },
          {
            'number' => '471',
            'unicode' => 'E530',
            'sjis_auto' => 'FBD0',
            'name' => 'らくだ',
            'sjis' => '1b2451500f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image105.gif'
          },
          {
            'number' => '472',
            'unicode' => 'E531',
            'sjis_auto' => 'FBD1',
            'name' => 'かえる',
            'sjis' => '1b2451510f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image106.gif'
          },
          {
            'number' => '473',
            'unicode' => 'E532',
            'sjis_auto' => 'FBD2',
            'name' => 'A型',
            'sjis' => '1b2451520f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image107.gif'
          },
          {
            'number' => '474',
            'unicode' => 'E533',
            'sjis_auto' => 'FBD3',
            'name' => 'B型',
            'sjis' => '1b2451530f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image108.gif'
          },
          {
            'number' => '475',
            'unicode' => 'E534',
            'sjis_auto' => 'FBD4',
            'name' => 'AB型',
            'sjis' => '1b2451540f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image109.gif'
          },
          {
            'number' => '476',
            'unicode' => 'E535',
            'sjis_auto' => 'FBD5',
            'name' => 'O型',
            'sjis' => '1b2451550f',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image110.gif'
          },
          {
            'number' => '477',
            'unicode' => 'E536',
            'sjis_auto' => 'FBD6',
            'name' => '足あと',
            'sjis' => '1b2451560f',
            'name_en' => 'Foot',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image111.gif'
          },
          {
            'number' => '478',
            'unicode' => 'E537',
            'sjis_auto' => 'FBD7',
            'name' => 'TM',
            'sjis' => '1b2451570f',
            'name_en' => 'Trademark',
            'image' => 'http://developers.softbankmobile.co.jp/dp/tool_dl/web/images/code5_31525_image112.gif'
          }
        ]
