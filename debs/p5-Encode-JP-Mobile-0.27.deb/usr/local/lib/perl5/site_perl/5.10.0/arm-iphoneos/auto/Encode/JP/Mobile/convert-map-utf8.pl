{
          'softbank' => {
                          'E532' => {
                                      'docomo' => {
                                                    'unicode' => '[A]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECE7',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E438' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECB8',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E21F' => {
                                      'docomo' => {
                                                    'unicode' => 'E6E5',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F041',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E525' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECDF',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E218' => {
                                      'docomo' => {
                                                    'unicode' => '[申]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '[申]',
                                                  'type' => 'name'
                                                }
                                    },
                          'E31C' => {
                                      'docomo' => {
                                                    'unicode' => 'E710',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFE2',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E242' => {
                                      'docomo' => {
                                                    'unicode' => 'E649',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF6A',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E342' => {
                                      'docomo' => {
                                                    'unicode' => 'E749',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFAE',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E43C' => {
                                      'docomo' => {
                                                    'unicode' => 'E645',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECBC',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E43A' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECBA',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E01F' => {
                                      'docomo' => {
                                                    'unicode' => 'E65D',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF89',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E417' => {
                                      'docomo' => {
                                                    'unicode' => 'E726',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECA2',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E20A' => {
                                      'docomo' => {
                                                    'unicode' => 'E69B',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF57',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E03D' => {
                                      'docomo' => {
                                                    'unicode' => 'E677',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFF0',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E320' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC75',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E407' => {
                                      'docomo' => {
                                                    'unicode' => 'E6F3',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC97',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E348' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFA6',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E00F' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFCF',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E53C' => {
                                      'docomo' => {
                                                    'unicode' => '[v',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '[v',
                                                  'type' => 'name'
                                                }
                                    },
                          'E443' => {
                                      'docomo' => {
                                                    'unicode' => 'E643',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF41',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E24A' => {
                                      'docomo' => {
                                                    'unicode' => 'E651',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF72',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E245' => {
                                      'docomo' => {
                                                    'unicode' => 'E64C',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF6D',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E052' => {
                                      'docomo' => {
                                                    'unicode' => 'E6A1',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFBA',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E228' => {
                                      'docomo' => {
                                                    'unicode' => '[サ]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC5A',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E12B' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFC5',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E325' => {
                                      'docomo' => {
                                                    'unicode' => 'E713',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFEB',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E239' => {
                                      'docomo' => {
                                                    'unicode' => 'E6A5',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F072',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E42C' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECB1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E040' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '〓',
                                                  'type' => 'name'
                                                }
                                    },
                          'E10D' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0F8',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E22E' => {
                                      'docomo' => {
                                                    'unicode' => '[↑]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC60',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E211' => {
                                      'docomo' => {
                                                    'unicode' => 'E6DF',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '〓',
                                                  'type' => 'name'
                                                }
                                    },
                          'E207' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC56',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E420' => {
                                      'docomo' => {
                                                    'unicode' => 'E70B',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECA8',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E11F' => {
                                      'docomo' => {
                                                    'unicode' => 'E6B2',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '〓',
                                                  'type' => 'name'
                                                }
                                    },
                          'E108' => {
                                      'docomo' => {
                                                    'unicode' => 'E723',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0F6',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E404' => {
                                      'docomo' => {
                                                    'unicode' => 'E753',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC95',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E330' => {
                                      'docomo' => {
                                                    'unicode' => 'E708',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFCD',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E419' => {
                                      'docomo' => {
                                                    'unicode' => 'E691',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0C1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E304' => {
                                      'docomo' => {
                                                    'unicode' => 'E743',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFBD',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E13D' => {
                                      'docomo' => {
                                                    'unicode' => 'E642',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF5F',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E013' => {
                                      'docomo' => {
                                                    'unicode' => 'E657',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC80',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E04D' => {
                                      'docomo' => {
                                                    'unicode' => 'E63E',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECC8',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E130' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF9E',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E127' => {
                                      'docomo' => {
                                                    'unicode' => 'E68C',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFE5',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E143' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC4C',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E435' => {
                                      'docomo' => {
                                                    'unicode' => 'E65D',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF89',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E02C' => {
                                      'docomo' => {
                                                    'unicode' => 'E6BA',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0B1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E508' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECCD',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E10C' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFC5',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E316' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F09F',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E514' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECD3',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E502' => {
                                      'docomo' => {
                                                    'unicode' => 'E67B',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0B9',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E250' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC63',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E446' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECC3',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E338' => {
                                      'docomo' => {
                                                    'unicode' => 'E71E',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC82',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E145' => {
                                      'docomo' => {
                                                    'unicode' => 'E6D9',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFF5',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E31D' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC73',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E311' => {
                                      'docomo' => {
                                                    'unicode' => 'E6FE',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF52',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E117' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0FC',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E437' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ED58',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E027' => {
                                      'docomo' => {
                                                    'unicode' => 'E6BA',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0B1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E151' => {
                                      'docomo' => {
                                                    'unicode' => 'E66E',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF7D',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E01A' => {
                                      'docomo' => {
                                                    'unicode' => 'E754',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFB1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E256' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '〓',
                                                  'type' => 'name'
                                                }
                                    },
                          'E518' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECD7',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E505' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECCB',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E00D' => {
                                      'docomo' => {
                                                    'unicode' => 'E6FD',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFCC',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E24D' => {
                                      'docomo' => {
                                                    'unicode' => 'E70B',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0CA',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E00E' => {
                                      'docomo' => {
                                                    'unicode' => 'E727',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFD2',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E21A' => {
                                      'docomo' => {
                                                    'unicode' => 'E69C',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F067',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E051' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0F1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E057' => {
                                      'docomo' => {
                                                    'unicode' => 'E6F0',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF49',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E229' => {
                                      'docomo' => {
                                                    'unicode' => 'E6D8',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC5B',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E025' => {
                                      'docomo' => {
                                                    'unicode' => 'E6BA',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0B1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E51D' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '〓',
                                                  'type' => 'name'
                                                }
                                    },
                          'E332' => {
                                      'docomo' => {
                                                    'unicode' => 'E6A0',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC81',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E122' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC43',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E044' => {
                                      'docomo' => {
                                                    'unicode' => 'E671',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF9B',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E22D' => {
                                      'docomo' => {
                                                    'unicode' => '[営]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC5F',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E32B' => {
                                      'docomo' => {
                                                    'unicode' => 'E6EC',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC7B',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E327' => {
                                      'docomo' => {
                                                    'unicode' => 'E6EC',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC79',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E34D' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC92',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E014' => {
                                      'docomo' => {
                                                    'unicode' => 'E654',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0B6',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E41E' => {
                                      'docomo' => {
                                                    'unicode' => 'E695',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECAA',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E021' => {
                                      'docomo' => {
                                                    'unicode' => 'E702',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF5A',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E30A' => {
                                      'docomo' => {
                                                    'unicode' => 'E67A',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFE1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E307' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFBB',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E411' => {
                                      'docomo' => {
                                                    'unicode' => 'E72D',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF4B',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E047' => {
                                      'docomo' => {
                                                    'unicode' => 'E672',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF9C',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E501' => {
                                      'docomo' => {
                                                    'unicode' => 'E669E6EF',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECC7',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E401' => {
                                      'docomo' => {
                                                    'unicode' => 'E723',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0F6',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E432' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECB5',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E010' => {
                                      'docomo' => {
                                                    'unicode' => 'E693',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ED88',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E44C' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECC6',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E510' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECD1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E50C' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F090',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E253' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '〓',
                                                  'type' => 'name'
                                                }
                                    },
                          'E055' => {
                                      'docomo' => {
                                                    'unicode' => 'E750',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFB5',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E018' => {
                                      'docomo' => {
                                                    'unicode' => 'E656',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF8F',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E03C' => {
                                      'docomo' => {
                                                    'unicode' => 'E676',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFDC',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E504' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECCA',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E534' => {
                                      'docomo' => {
                                                    'unicode' => '[AB]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECEA',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E107' => {
                                      'docomo' => {
                                                    'unicode' => 'E757',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0F5',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E04A' => {
                                      'docomo' => {
                                                    'unicode' => 'E63E',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF60',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E206' => {
                                      'docomo' => {
                                                    'unicode' => 'E6F8',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F05A',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E156' => {
                                      'docomo' => {
                                                    'unicode' => 'E66A',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF7C',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E037' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0EB',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E134' => {
                                      'docomo' => {
                                                    'unicode' => 'E754',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFB1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E235' => {
                                      'docomo' => {
                                                    'unicode' => '[←]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F06F',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E14C' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFC2',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E24F' => {
                                      'docomo' => {
                                                    'unicode' => 'E736',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F075',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E14D' => {
                                      'docomo' => {
                                                    'unicode' => 'E667',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF83',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E112' => {
                                      'docomo' => {
                                                    'unicode' => 'E685',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFA8',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E413' => {
                                      'docomo' => {
                                                    'unicode' => 'E72E',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ED6D',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E25A' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '〓',
                                                  'type' => 'name'
                                                }
                                    },
                          'E312' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC6F',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E212' => {
                                      'docomo' => {
                                                    'unicode' => 'E6DD',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0E5',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E041' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFDF',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E349' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC8F',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E12C' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '〓',
                                                  'type' => 'name'
                                                }
                                    },
                          'E124' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF45',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E539' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '〓',
                                                  'type' => 'name'
                                                }
                                    },
                          'E230' => {
                                      'docomo' => {
                                                    'unicode' => '[←]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFD8',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E324' => {
                                      'docomo' => {
                                                    'unicode' => 'E6AC',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF97',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E233' => {
                                      'docomo' => {
                                                    'unicode' => '[↓]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F05C',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E220' => {
                                      'docomo' => {
                                                    'unicode' => 'E6E6',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F042',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E11C' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFD1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E503' => {
                                      'docomo' => {
                                                    'unicode' => 'E67C',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECC9',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E321' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC76',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E049' => {
                                      'docomo' => {
                                                    'unicode' => 'E63F',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF65',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E303' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC67',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E243' => {
                                      'docomo' => {
                                                    'unicode' => 'E64A',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF6B',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E522' => {
                                      'docomo' => {
                                                    'unicode' => 'E751',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECDE',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E326' => {
                                      'docomo' => {
                                                    'unicode' => 'E6FF',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFDE',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E240' => {
                                      'docomo' => {
                                                    'unicode' => 'E647',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF68',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E221' => {
                                      'docomo' => {
                                                    'unicode' => 'E6E7',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F043',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E00B' => {
                                      'docomo' => {
                                                    'unicode' => 'E6D0',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFF9',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E24E' => {
                                      'docomo' => {
                                                    'unicode' => 'E731',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F074',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E23B' => {
                                      'docomo' => {
                                                    'unicode' => '[<]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F049',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E533' => {
                                      'docomo' => {
                                                    'unicode' => '[B]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECE8',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E224' => {
                                      'docomo' => {
                                                    'unicode' => 'E6EA',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F046',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E20D' => {
                                      'docomo' => {
                                                    'unicode' => 'E68F',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0BF',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E01E' => {
                                      'docomo' => {
                                                    'unicode' => 'E65B',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF8E',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E335' => {
                                      'docomo' => {
                                                    'unicode' => '[☆]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF63',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E13A' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECD9',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E01C' => {
                                      'docomo' => {
                                                    'unicode' => 'E6A3',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF8D',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E246' => {
                                      'docomo' => {
                                                    'unicode' => 'E64D',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF6E',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E120' => {
                                      'docomo' => {
                                                    'unicode' => 'E673',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFAF',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E333' => {
                                      'docomo' => {
                                                    'unicode' => '[×]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F06C',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E421' => {
                                      'docomo' => {
                                                    'unicode' => 'E700',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECA9',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E339' => {
                                      'docomo' => {
                                                    'unicode' => 'E74D',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC83',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E106' => {
                                      'docomo' => {
                                                    'unicode' => 'E726',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0F4',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E526' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECE0',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E227' => {
                                      'docomo' => {
                                                    'unicode' => '[割]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC59',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E517' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECD6',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E340' => {
                                      'docomo' => {
                                                    'unicode' => 'E74C',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0D1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E119' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC40',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E20F' => {
                                      'docomo' => {
                                                    'unicode' => 'E690',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0C0',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E203' => {
                                      'docomo' => {
                                                    'unicode' => '[ココ]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '[ココ]',
                                                  'type' => 'name'
                                                }
                                    },
                          'E507' => {
                                      'docomo' => {
                                                    'unicode' => 'E677',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFF0',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E10E' => {
                                      'docomo' => {
                                                    'unicode' => 'E71A',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0F9',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E406' => {
                                      'docomo' => {
                                                    'unicode' => 'E72B',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC96',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E140' => {
                                      'docomo' => {
                                                    'unicode' => 'E66E',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF7D',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E032' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0EA',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E528' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFB2',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E331' => {
                                      'docomo' => {
                                                    'unicode' => 'E706',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0CE',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E43D' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0EB',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E425' => {
                                      'docomo' => {
                                                    'unicode' => 'E6ED',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECAE',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E301' => {
                                      'docomo' => {
                                                    'unicode' => 'E689',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC65',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E440' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECBF',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E314' => {
                                      'docomo' => {
                                                    'unicode' => 'E684',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0BC',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E01B' => {
                                      'docomo' => {
                                                    'unicode' => 'E65E',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF8A',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E236' => {
                                      'docomo' => {
                                                    'unicode' => 'E678',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F071',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E006' => {
                                      'docomo' => {
                                                    'unicode' => 'E70E',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0E6',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E343' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC8B',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E12A' => {
                                      'docomo' => {
                                                    'unicode' => 'E68A',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFDB',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E527' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECE1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E52C' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFB0',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E427' => {
                                      'docomo' => {
                                                    'unicode' => '[＼(^o^)／]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ED8B',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E33F' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC89',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E11E' => {
                                      'docomo' => {
                                                    'unicode' => 'E682',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC41',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E41D' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECA6',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E33E' => {
                                      'docomo' => {
                                                    'unicode' => 'E74C',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC88',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E416' => {
                                      'docomo' => {
                                                    'unicode' => 'E724',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ED61',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E402' => {
                                      'docomo' => {
                                                    'unicode' => 'E72C',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC93',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E045' => {
                                      'docomo' => {
                                                    'unicode' => 'E670',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0B4',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E31B' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC72',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E317' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFEA',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E259' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '〓',
                                                  'type' => 'name'
                                                }
                                    },
                          'E21E' => {
                                      'docomo' => {
                                                    'unicode' => 'E6E4',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F040',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E109' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFB2',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E33D' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC87',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E155' => {
                                      'docomo' => {
                                                    'unicode' => 'E666',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC52',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E51F' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECDD',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E511' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC48',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E50E' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECCF',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E13F' => {
                                      'docomo' => {
                                                    'unicode' => 'E6F7',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC4B',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E40C' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC9B',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E123' => {
                                      'docomo' => {
                                                    'unicode' => 'E6F7',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF95',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E116' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0FB',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E22F' => {
                                      'docomo' => {
                                                    'unicode' => '[↓]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC61',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E138' => {
                                      'docomo' => {
                                                    'unicode' => '[♂]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '[♂]',
                                                  'type' => 'name'
                                                }
                                    },
                          'E53D' => {
                                      'docomo' => {
                                                    'unicode' => 'oda',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'oda',
                                                  'type' => 'name'
                                                }
                                    },
                          'E410' => {
                                      'docomo' => {
                                                    'unicode' => 'E6F4',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC9E',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E310' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC6E',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E428' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '〓',
                                                  'type' => 'name'
                                                }
                                    },
                          'E50B' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFA5',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E024' => {
                                      'docomo' => {
                                                    'unicode' => 'E6BA',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0B1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E341' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC8A',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E054' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF48',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E058' => {
                                      'docomo' => {
                                                    'unicode' => 'E6F2',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC97',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E144' => {
                                      'docomo' => {
                                                    'unicode' => 'E6D9',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFF5',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E12E' => {
                                      'docomo' => {
                                                    'unicode' => '[VS]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC45',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E436' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECB7',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E217' => {
                                      'docomo' => {
                                                    'unicode' => '[月]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '[月]',
                                                  'type' => 'name'
                                                }
                                    },
                          'E202' => {
                                      'docomo' => {
                                                    'unicode' => 'E661',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC55',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E51C' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECDB',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E424' => {
                                      'docomo' => {
                                                    'unicode' => 'E70B',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECAC',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E111' => {
                                      'docomo' => {
                                                    'unicode' => 'E6F9',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0FA',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E344' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC8C',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E103' => {
                                      'docomo' => {
                                                    'unicode' => 'E6CF',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ED66',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E038' => {
                                      'docomo' => {
                                                    'unicode' => 'E664',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF86',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E52D' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECE3',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E40F' => {
                                      'docomo' => {
                                                    'unicode' => 'E723',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC9A',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E32C' => {
                                      'docomo' => {
                                                    'unicode' => 'E6EC',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC7C',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E12F' => {
                                      'docomo' => {
                                                    'unicode' => 'E715',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFA0',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E00A' => {
                                      'docomo' => {
                                                    'unicode' => 'E688',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0A5',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E412' => {
                                      'docomo' => {
                                                    'unicode' => 'E6F0E72D',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ED68',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E53B' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '〓',
                                                  'type' => 'name'
                                                }
                                    },
                          'E318' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC71',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E13B' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFE9',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E128' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0E9',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E42B' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF94',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E234' => {
                                      'docomo' => {
                                                    'unicode' => '[→]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F06E',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E535' => {
                                      'docomo' => {
                                                    'unicode' => '[O]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECE9',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E257' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '〓',
                                                  'type' => 'name'
                                                }
                                    },
                          'E23A' => {
                                      'docomo' => {
                                                    'unicode' => '[>]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F04A',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E21B' => {
                                      'docomo' => {
                                                    'unicode' => 'E69C',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F067',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E046' => {
                                      'docomo' => {
                                                    'unicode' => 'E74A',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFA9',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E002' => {
                                      'docomo' => {
                                                    'unicode' => 'E6F0',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFD3',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E313' => {
                                      'docomo' => {
                                                    'unicode' => 'E675',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFEF',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E152' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC50',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E433' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECB6',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E415' => {
                                      'docomo' => {
                                                    'unicode' => 'E6F0',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF49',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E223' => {
                                      'docomo' => {
                                                    'unicode' => 'E6E9',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F045',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E205' => {
                                      'docomo' => {
                                                    'unicode' => 'E6F8',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF51',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E125' => {
                                      'docomo' => {
                                                    'unicode' => 'E67E',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF76',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E33B' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC85',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E148' => {
                                      'docomo' => {
                                                    'unicode' => 'E683',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF77',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E512' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC49',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E252' => {
                                      'docomo' => {
                                                    'unicode' => 'E737',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF59',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E426' => {
                                      'docomo' => {
                                                    'unicode' => '[m(_ _)m]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECAD',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E41A' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECA4',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E31A' => {
                                      'docomo' => {
                                                    'unicode' => 'E674',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFF3',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E017' => {
                                      'docomo' => {
                                                    'unicode' => 'E712',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ED45',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E011' => {
                                      'docomo' => {
                                                    'unicode' => 'E694',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0C3',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E04B' => {
                                      'docomo' => {
                                                    'unicode' => 'E640',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF64',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E05A' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFCE',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E209' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF58',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E03E' => {
                                      'docomo' => {
                                                    'unicode' => 'E6F6',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0EE',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E42A' => {
                                      'docomo' => {
                                                    'unicode' => 'E658',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0B7',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E53A' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '〓',
                                                  'type' => 'name'
                                                }
                                    },
                          'E346' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC8E',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E30E' => {
                                      'docomo' => {
                                                    'unicode' => 'E67F',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF55',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E10A' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0F7',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E219' => {
                                      'docomo' => {
                                                    'unicode' => 'E69C',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F066',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E003' => {
                                      'docomo' => {
                                                    'unicode' => 'E6F9',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFC4',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E21C' => {
                                      'docomo' => {
                                                    'unicode' => 'E6E2',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFFB',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E237' => {
                                      'docomo' => {
                                                    'unicode' => 'E697',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F068',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E40E' => {
                                      'docomo' => {
                                                    'unicode' => 'E725',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC9D',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E03B' => {
                                      'docomo' => {
                                                    'unicode' => 'E740',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0ED',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E101' => {
                                      'docomo' => {
                                                    'unicode' => 'E665',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFF4',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E530' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECE6',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E305' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFBC',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E031' => {
                                      'docomo' => {
                                                    'unicode' => 'E71A',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0F9',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E232' => {
                                      'docomo' => {
                                                    'unicode' => '[↑]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F05B',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E523' => {
                                      'docomo' => {
                                                    'unicode' => 'E74F',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFB9',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E244' => {
                                      'docomo' => {
                                                    'unicode' => 'E64B',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF6C',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E023' => {
                                      'docomo' => {
                                                    'unicode' => 'E6EE',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF4F',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E15A' => {
                                      'docomo' => {
                                                    'unicode' => 'E65E',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF8A',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E516' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECD5',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E039' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ED71',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E40D' => {
                                      'docomo' => {
                                                    'unicode' => 'E72A',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC9C',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E24C' => {
                                      'docomo' => {
                                                    'unicode' => '[TOP]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '[TOP]',
                                                  'type' => 'name'
                                                }
                                    },
                          'E20C' => {
                                      'docomo' => {
                                                    'unicode' => 'E68D',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC78',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E538' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '〓',
                                                  'type' => 'name'
                                                }
                                    },
                          'E028' => {
                                      'docomo' => {
                                                    'unicode' => 'E6BA',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0B1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E12D' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC44',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E141' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFEA',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E213' => {
                                      'docomo' => {
                                                    'unicode' => '[UP]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFE8',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E322' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC77',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E136' => {
                                      'docomo' => {
                                                    'unicode' => 'E71D',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF87',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E42F' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF8B',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E050' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0F0',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E059' => {
                                      'docomo' => {
                                                    'unicode' => 'E6F1',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF4A',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E01D' => {
                                      'docomo' => {
                                                    'unicode' => 'E662',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF8C',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E121' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC42',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E048' => {
                                      'docomo' => {
                                                    'unicode' => 'E641',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF5D',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E409' => {
                                      'docomo' => {
                                                    'unicode' => 'E728',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFC0',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E23E' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC62',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E308' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC69',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E02F' => {
                                      'docomo' => {
                                                    'unicode' => 'E6BA',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0B1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E20E' => {
                                      'docomo' => {
                                                    'unicode' => 'E68E',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0BE',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E247' => {
                                      'docomo' => {
                                                    'unicode' => 'E64E',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF6F',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E157' => {
                                      'docomo' => {
                                                    'unicode' => 'E73E',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC53',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E10F' => {
                                      'docomo' => {
                                                    'unicode' => 'E6FB',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF4E',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E44A' => {
                                      'docomo' => {
                                                    'unicode' => 'E63E',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC4D',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E34B' => {
                                      'docomo' => {
                                                    'unicode' => 'E686',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0BD',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E22B' => {
                                      'docomo' => {
                                                    'unicode' => 'E739',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC5D',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E133' => {
                                      'docomo' => {
                                                    'unicode' => '[777]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF46',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E529' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF67',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E441' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECC0',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E201' => {
                                      'docomo' => {
                                                    'unicode' => 'E733',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ED76',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E012' => {
                                      'docomo' => {
                                                    'unicode' => 'E695',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0C4',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E03A' => {
                                      'docomo' => {
                                                    'unicode' => 'E66B',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F08E',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E449' => {
                                      'docomo' => {
                                                    'unicode' => 'E63E',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECC8',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E02B' => {
                                      'docomo' => {
                                                    'unicode' => 'E6BA',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0B1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E03F' => {
                                      'docomo' => {
                                                    'unicode' => 'E6D9',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFF2',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E105' => {
                                      'docomo' => {
                                                    'unicode' => 'E728',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFC0',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E445' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECC2',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E405' => {
                                      'docomo' => {
                                                    'unicode' => 'E729',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0F3',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E154' => {
                                      'docomo' => {
                                                    'unicode' => 'E668',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF7B',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E030' => {
                                      'docomo' => {
                                                    'unicode' => 'E748',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFA3',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E053' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0F2',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E102' => {
                                      'docomo' => {
                                                    'unicode' => 'E665',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFF4',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E137' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC4A',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E515' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECD4',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E43F' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECBE',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E11D' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF53',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E258' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '〓',
                                                  'type' => 'name'
                                                }
                                    },
                          'E226' => {
                                      'docomo' => {
                                                    'unicode' => '[得]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFD0',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E016' => {
                                      'docomo' => {
                                                    'unicode' => 'E653',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF93',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E41C' => {
                                      'docomo' => {
                                                    'unicode' => 'E6F9',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECA5',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E23C' => {
                                      'docomo' => {
                                                    'unicode' => '[>>]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F04C',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E30D' => {
                                      'docomo' => {
                                                    'unicode' => '[祝]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC6C',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E04E' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0EF',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E115' => {
                                      'docomo' => {
                                                    'unicode' => 'E733',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF43',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E14F' => {
                                      'docomo' => {
                                                    'unicode' => 'E66C',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF7E',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E52E' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECE4',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E536' => {
                                      'docomo' => {
                                                    'unicode' => 'E698',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECEB',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E139' => {
                                      'docomo' => {
                                                    'unicode' => '[♀]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '[♀]',
                                                  'type' => 'name'
                                                }
                                    },
                          'E43E' => {
                                      'docomo' => {
                                                    'unicode' => 'E73F',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ED81',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E022' => {
                                      'docomo' => {
                                                    'unicode' => 'E6EC',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0B2',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E007' => {
                                      'docomo' => {
                                                    'unicode' => 'E699',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0E7',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E32E' => {
                                      'docomo' => {
                                                    'unicode' => 'E6FA',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC7E',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E11A' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFC8',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E33A' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC84',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E336' => {
                                      'docomo' => {
                                                    'unicode' => '[?]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF5B',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E431' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECB4',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E422' => {
                                      'docomo' => {
                                                    'unicode' => 'E695',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECAA',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E129' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F09D',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E159' => {
                                      'docomo' => {
                                                    'unicode' => 'E660',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF88',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E329' => {
                                      'docomo' => {
                                                    'unicode' => 'E6EC',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFC3',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E110' => {
                                      'docomo' => {
                                                    'unicode' => 'E741',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFEC',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E14A' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC4F',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E034' => {
                                      'docomo' => {
                                                    'unicode' => 'E71B',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFED',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E216' => {
                                      'docomo' => {
                                                    'unicode' => '[無]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '[無]',
                                                  'type' => 'name'
                                                }
                                    },
                          'E147' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFAA',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E42E' => {
                                      'docomo' => {
                                                    'unicode' => 'E65F',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF8A',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E50F' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECD0',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E33C' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC86',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E319' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ED6F',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E13E' => {
                                      'docomo' => {
                                                    'unicode' => 'E674',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFF3',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E02E' => {
                                      'docomo' => {
                                                    'unicode' => 'E6BA',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0B1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E042' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECB0',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E241' => {
                                      'docomo' => {
                                                    'unicode' => 'E648',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF69',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E524' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '〓',
                                                  'type' => 'name'
                                                }
                                    },
                          'E215' => {
                                      'docomo' => {
                                                    'unicode' => '[有]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '[有]',
                                                  'type' => 'name'
                                                }
                                    },
                          'E520' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECDC',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E248' => {
                                      'docomo' => {
                                                    'unicode' => 'E64F',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF70',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E32D' => {
                                      'docomo' => {
                                                    'unicode' => 'E6EC',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC7D',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E20B' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC57',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E414' => {
                                      'docomo' => {
                                                    'unicode' => 'E6F0',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECA1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E328' => {
                                      'docomo' => {
                                                    'unicode' => 'E6ED',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ED79',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E251' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC64',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E008' => {
                                      'docomo' => {
                                                    'unicode' => 'E681',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFEE',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E009' => {
                                      'docomo' => {
                                                    'unicode' => 'E687',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0B3',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E135' => {
                                      'docomo' => {
                                                    'unicode' => 'E6A3',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF8D',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E019' => {
                                      'docomo' => {
                                                    'unicode' => 'E751',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF72',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E149' => {
                                      'docomo' => {
                                                    'unicode' => '[$\\]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '[$\\]',
                                                  'type' => 'name'
                                                }
                                    },
                          'E40A' => {
                                      'docomo' => {
                                                    'unicode' => 'E721',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC99',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E323' => {
                                      'docomo' => {
                                                    'unicode' => 'E682',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF74',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E531' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFB3',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E448' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECC4',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E345' => {
                                      'docomo' => {
                                                    'unicode' => 'E745',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC8D',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E13C' => {
                                      'docomo' => {
                                                    'unicode' => 'E701',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF4D',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E004' => {
                                      'docomo' => {
                                                    'unicode' => 'E6F0',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFD5',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E43B' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECBB',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E408' => {
                                      'docomo' => {
                                                    'unicode' => 'E701',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC98',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E14B' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF81',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E114' => {
                                      'docomo' => {
                                                    'unicode' => 'E6DC',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFF1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E32A' => {
                                      'docomo' => {
                                                    'unicode' => 'E6EC',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC7A',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E30C' => {
                                      'docomo' => {
                                                    'unicode' => 'E672',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC6B',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E52F' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECE5',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E337' => {
                                      'docomo' => {
                                                    'unicode' => 'E702',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF5A',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E31E' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFE4',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E439' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECB9',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E04F' => {
                                      'docomo' => {
                                                    'unicode' => 'E6A2',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFB4',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E001' => {
                                      'docomo' => {
                                                    'unicode' => 'E6F0',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFD5',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E315' => {
                                      'docomo' => {
                                                    'unicode' => 'E734',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFCA',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E30F' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC6D',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E513' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECD2',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E31F' => {
                                      'docomo' => {
                                                    'unicode' => 'E675',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC74',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E50D' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECCE',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E208' => {
                                      'docomo' => {
                                                    'unicode' => 'E680',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF56',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E51B' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECDA',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E52A' => {
                                      'docomo' => {
                                                    'unicode' => 'E6A1',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFBA',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E02A' => {
                                      'docomo' => {
                                                    'unicode' => 'E6BA',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0B1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E238' => {
                                      'docomo' => {
                                                    'unicode' => 'E696',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F069',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E429' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECAF',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E309' => {
                                      'docomo' => {
                                                    'unicode' => '[WC]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '[WC]',
                                                  'type' => 'name'
                                                }
                                    },
                          'E035' => {
                                      'docomo' => {
                                                    'unicode' => 'E71B',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFED',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E10B' => {
                                      'docomo' => {
                                                    'unicode' => 'E755',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFB7',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E231' => {
                                      'docomo' => {
                                                    'unicode' => '[→]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFD9',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E126' => {
                                      'docomo' => {
                                                    'unicode' => 'E68C',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFE5',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E214' => {
                                      'docomo' => {
                                                    'unicode' => '[COOL]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC58',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E131' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC46',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E142' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFEA',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E41B' => {
                                      'docomo' => {
                                                    'unicode' => 'E692',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0C2',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E23F' => {
                                      'docomo' => {
                                                    'unicode' => 'E646',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF67',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E056' => {
                                      'docomo' => {
                                                    'unicode' => 'E6F0',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECA1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E029' => {
                                      'docomo' => {
                                                    'unicode' => 'E6BA',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0B1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E53E' => {
                                      'docomo' => {
                                                    'unicode' => 'fone]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'fone]',
                                                  'type' => 'name'
                                                }
                                    },
                          'E418' => {
                                      'docomo' => {
                                                    'unicode' => 'E726',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECA3',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E14E' => {
                                      'docomo' => {
                                                    'unicode' => 'E66D',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF42',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E255' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '〓',
                                                  'type' => 'name'
                                                }
                                    },
                          'E033' => {
                                      'docomo' => {
                                                    'unicode' => 'E6A4',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFA2',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E22A' => {
                                      'docomo' => {
                                                    'unicode' => 'E73B',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC5C',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E51A' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECD9',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E026' => {
                                      'docomo' => {
                                                    'unicode' => 'E6BA',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0B1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E146' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC4D',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E50A' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '〓',
                                                  'type' => 'name'
                                                }
                                    },
                          'E020' => {
                                      'docomo' => {
                                                    'unicode' => '[?]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF5B',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E42D' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECB2',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E24B' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF73',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E434' => {
                                      'docomo' => {
                                                    'unicode' => 'E65C',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0EC',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E40B' => {
                                      'docomo' => {
                                                    'unicode' => 'E757',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC9A',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E132' => {
                                      'docomo' => {
                                                    'unicode' => 'E659',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF92',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E403' => {
                                      'docomo' => {
                                                    'unicode' => 'E720',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC94',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E537' => {
                                      'docomo' => {
                                                    'unicode' => 'E732',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F06A',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E043' => {
                                      'docomo' => {
                                                    'unicode' => 'E66F',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF85',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E509' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF99',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E506' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECCC',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E519' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECD8',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E34C' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC91',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E204' => {
                                      'docomo' => {
                                                    'unicode' => 'E6F8',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0B2',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E04C' => {
                                      'docomo' => {
                                                    'unicode' => 'E69F',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF5E',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E21D' => {
                                      'docomo' => {
                                                    'unicode' => 'E6E3',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFFC',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E34A' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC90',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E30B' => {
                                      'docomo' => {
                                                    'unicode' => 'E74B',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC6A',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E444' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '〓',
                                                  'type' => 'name'
                                                }
                                    },
                          'E118' => {
                                      'docomo' => {
                                                    'unicode' => 'E747',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFA7',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E11B' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFA4',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E00C' => {
                                      'docomo' => {
                                                    'unicode' => 'E716',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0E8',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E225' => {
                                      'docomo' => {
                                                    'unicode' => 'E6EB',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0C9',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E423' => {
                                      'docomo' => {
                                                    'unicode' => 'E72F',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECAB',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E254' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '〓',
                                                  'type' => 'name'
                                                }
                                    },
                          'E015' => {
                                      'docomo' => {
                                                    'unicode' => 'E655',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF90',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E005' => {
                                      'docomo' => {
                                                    'unicode' => 'E6F0',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFD3',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E210' => {
                                      'docomo' => {
                                                    'unicode' => 'E6E0',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ED89',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E23D' => {
                                      'docomo' => {
                                                    'unicode' => '[<<]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F04B',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E02D' => {
                                      'docomo' => {
                                                    'unicode' => 'E6BA',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0B1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E334' => {
                                      'docomo' => {
                                                    'unicode' => 'E6FC',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFBE',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E32F' => {
                                      'docomo' => {
                                                    'unicode' => '[☆]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF63',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E153' => {
                                      'docomo' => {
                                                    'unicode' => 'E665',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC51',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E447' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC40',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E41F' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECA7',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E22C' => {
                                      'docomo' => {
                                                    'unicode' => '[指]',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC5E',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E222' => {
                                      'docomo' => {
                                                    'unicode' => 'E6E8',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F044',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E51E' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => '〓',
                                                  'type' => 'name'
                                                }
                                    },
                          'E150' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF80',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E158' => {
                                      'docomo' => {
                                                    'unicode' => 'E669',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC54',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E249' => {
                                      'docomo' => {
                                                    'unicode' => 'E650',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF71',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E52B' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECE2',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E302' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC66',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E442' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECC1',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E521' => {
                                      'docomo' => {
                                                    'unicode' => 'E74F',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFB9',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E113' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFE3',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E036' => {
                                      'docomo' => {
                                                    'unicode' => 'E663',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EF84',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E104' => {
                                      'docomo' => {
                                                    'unicode' => 'E6CE',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'F0DF',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E44B' => {
                                      'docomo' => {
                                                    'unicode' => 'E6B3',
                                                    'type' => 'pictogram'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECC5',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E347' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EFAD',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E430' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'ECB3',
                                                  'type' => 'pictogram'
                                                }
                                    },
                          'E306' => {
                                      'docomo' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                      'kddi' => {
                                                  'unicode' => 'EC68',
                                                  'type' => 'pictogram'
                                                }
                                    }
                        },
          'docomo' => {
                        'E729' => {
                                    'softbank' => {
                                                    'unicode' => 'E405',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0F3',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6F9' => {
                                    'softbank' => {
                                                    'unicode' => 'E003',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFC4',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E753' => {
                                    'softbank' => {
                                                    'unicode' => 'E404',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ED85',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6D2' => {
                                    'softbank' => {
                                                    'unicode' => '［ｉモード］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => '［ｉモード］',
                                                'type' => 'name'
                                              }
                                  },
                        'E6A5' => {
                                    'softbank' => {
                                                    'unicode' => 'E239',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F072',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E68D' => {
                                    'softbank' => {
                                                    'unicode' => 'E20C',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC78',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6D4' => {
                                    'softbank' => {
                                                    'unicode' => '［ドコモ］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => '［ドコモ］',
                                                'type' => 'name'
                                              }
                                  },
                        'E6AD' => {
                                    'softbank' => {
                                                    'unicode' => '［ふくろ］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => '［ふくろ］',
                                                'type' => 'name'
                                              }
                                  },
                        'E6D7' => {
                                    'softbank' => {
                                                    'unicode' => '［ＦＲＥＥ］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F095',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6E8' => {
                                    'softbank' => {
                                                    'unicode' => 'E222',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F044',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E74E' => {
                                    'softbank' => {
                                                    'unicode' => '［カタツムリ］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ED83',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E74A' => {
                                    'softbank' => {
                                                    'unicode' => 'E046',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFA9',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6E3' => {
                                    'softbank' => {
                                                    'unicode' => 'E21D',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFFC',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E65A' => {
                                    'softbank' => {
                                                    'unicode' => '［ポケベル］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0B8',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E658' => {
                                    'softbank' => {
                                                    'unicode' => 'E42A',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0B7',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6D0' => {
                                    'softbank' => {
                                                    'unicode' => 'E00B',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFF9',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E661' => {
                                    'softbank' => {
                                                    'unicode' => 'E202',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC55',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6D6' => {
                                    'softbank' => {
                                                    'unicode' => '￥',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F09A',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E67E' => {
                                    'softbank' => {
                                                    'unicode' => 'E125',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF76',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E64B' => {
                                    'softbank' => {
                                                    'unicode' => 'E244',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF6C',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6E0' => {
                                    'softbank' => {
                                                    'unicode' => 'E210',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ED89',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6FE' => {
                                    'softbank' => {
                                                    'unicode' => 'E311',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF52',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E70A' => {
                                    'softbank' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ECF2',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6E1' => {
                                    'softbank' => {
                                                    'unicode' => '［Ｑ］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F048',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E667' => {
                                    'softbank' => {
                                                    'unicode' => 'E14D',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF83',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E731' => {
                                    'softbank' => {
                                                    'unicode' => 'E24E',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F074',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E694' => {
                                    'softbank' => {
                                                    'unicode' => 'E011',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0C3',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E678' => {
                                    'softbank' => {
                                                    'unicode' => 'E236',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F071',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E682' => {
                                    'softbank' => {
                                                    'unicode' => 'E323',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF74',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6D9' => {
                                    'softbank' => {
                                                    'unicode' => 'E03F',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFF2',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E64D' => {
                                    'softbank' => {
                                                    'unicode' => 'E246',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF6E',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E74F' => {
                                    'softbank' => {
                                                    'unicode' => 'E523',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFB9',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E734' => {
                                    'softbank' => {
                                                    'unicode' => 'E315',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFCA',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E691' => {
                                    'softbank' => {
                                                    'unicode' => 'E419',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0C1',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E714' => {
                                    'softbank' => {
                                                    'unicode' => '［ドア］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => '［ドア］',
                                                'type' => 'name'
                                              }
                                  },
                        'E70B' => {
                                    'softbank' => {
                                                    'unicode' => 'E24D',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0CA',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E674' => {
                                    'softbank' => {
                                                    'unicode' => 'E13E',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFF3',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E64F' => {
                                    'softbank' => {
                                                    'unicode' => 'E248',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF70',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E726' => {
                                    'softbank' => {
                                                    'unicode' => 'E106',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0F4',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E747' => {
                                    'softbank' => {
                                                    'unicode' => 'E118',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFA7',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E69B' => {
                                    'softbank' => {
                                                    'unicode' => 'E20A',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF57',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E68F' => {
                                    'softbank' => {
                                                    'unicode' => 'E20D',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0BF',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E64C' => {
                                    'softbank' => {
                                                    'unicode' => 'E245',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF6D',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6FC' => {
                                    'softbank' => {
                                                    'unicode' => 'E334',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFBE',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E645' => {
                                    'softbank' => {
                                                    'unicode' => 'E43C',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ECBC',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E647' => {
                                    'softbank' => {
                                                    'unicode' => 'E240',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF68',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6E6' => {
                                    'softbank' => {
                                                    'unicode' => 'E220',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F042',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E676' => {
                                    'softbank' => {
                                                    'unicode' => 'E03C',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFDC',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E72A' => {
                                    'softbank' => {
                                                    'unicode' => 'E40A',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC99',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E709' => {
                                    'softbank' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => '〓',
                                                'type' => 'name'
                                              }
                                  },
                        'E69D' => {
                                    'softbank' => {
                                                    'unicode' => 'E04C',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0C6',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E669' => {
                                    'softbank' => {
                                                    'unicode' => 'E158',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC54',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E71B' => {
                                    'softbank' => {
                                                    'unicode' => 'E034',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFED',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E73B' => {
                                    'softbank' => {
                                                    'unicode' => 'E22A',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC5C',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E644' => {
                                    'softbank' => {
                                                    'unicode' => '［霧］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0B5',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E683' => {
                                    'softbank' => {
                                                    'unicode' => 'E148',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF77',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E707' => {
                                    'softbank' => {
                                                    'unicode' => 'E331',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFBF',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E716' => {
                                    'softbank' => {
                                                    'unicode' => 'E00C',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0E8',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E671' => {
                                    'softbank' => {
                                                    'unicode' => 'E044',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF9B',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E72B' => {
                                    'softbank' => {
                                                    'unicode' => 'E406',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC96',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E745' => {
                                    'softbank' => {
                                                    'unicode' => 'E345',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC8D',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E725' => {
                                    'softbank' => {
                                                    'unicode' => 'E40E',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC9D',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E65C' => {
                                    'softbank' => {
                                                    'unicode' => 'E434',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0EC',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E65F' => {
                                    'softbank' => {
                                                    'unicode' => 'E42E',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF8A',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E664' => {
                                    'softbank' => {
                                                    'unicode' => 'E038',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF86',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E737' => {
                                    'softbank' => {
                                                    'unicode' => 'E252',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF59',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E702' => {
                                    'softbank' => {
                                                    'unicode' => 'E021',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF5A',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6EC' => {
                                    'softbank' => {
                                                    'unicode' => 'E022',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0B2',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E72D' => {
                                    'softbank' => {
                                                    'unicode' => 'E411',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF4B',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E660' => {
                                    'softbank' => {
                                                    'unicode' => 'E159',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF88',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E73C' => {
                                    'softbank' => {
                                                    'unicode' => '⇔',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ED7E',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6B8' => {
                                    'softbank' => {
                                                    'unicode' => '［ＯＮ］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => '［ＯＮ］',
                                                'type' => 'name'
                                              }
                                  },
                        'E652' => {
                                    'softbank' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => '〓',
                                                'type' => 'name'
                                              }
                                  },
                        'E6BA' => {
                                    'softbank' => {
                                                    'unicode' => 'E02D',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0B1',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6F0' => {
                                    'softbank' => {
                                                    'unicode' => 'E057',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF49',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E701' => {
                                    'softbank' => {
                                                    'unicode' => 'E13C',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF4D',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E63E' => {
                                    'softbank' => {
                                                    'unicode' => 'E04A',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF60',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E67D' => {
                                    'softbank' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0BB',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E718' => {
                                    'softbank' => {
                                                    'unicode' => '［レンチ］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0A4',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E68B' => {
                                    'softbank' => {
                                                    'unicode' => '［ゲーム］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF9F',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E689' => {
                                    'softbank' => {
                                                    'unicode' => 'E301',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC65',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E741' => {
                                    'softbank' => {
                                                    'unicode' => 'E110',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFEC',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E693' => {
                                    'softbank' => {
                                                    'unicode' => 'E010',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ED88',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6F6' => {
                                    'softbank' => {
                                                    'unicode' => 'E03E',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0EE',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E743' => {
                                    'softbank' => {
                                                    'unicode' => 'E304',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFBD',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E67A' => {
                                    'softbank' => {
                                                    'unicode' => 'E30A',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFE1',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E656' => {
                                    'softbank' => {
                                                    'unicode' => 'E018',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF8F',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E73E' => {
                                    'softbank' => {
                                                    'unicode' => 'E157',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC53',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E69C' => {
                                    'softbank' => {
                                                    'unicode' => '●',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0C5',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E750' => {
                                    'softbank' => {
                                                    'unicode' => 'E055',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFB5',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E696' => {
                                    'softbank' => {
                                                    'unicode' => 'E238',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F069',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E728' => {
                                    'softbank' => {
                                                    'unicode' => 'E105',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFC0',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6CE' => {
                                    'softbank' => {
                                                    'unicode' => 'E104',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0DF',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E662' => {
                                    'softbank' => {
                                                    'unicode' => 'E01D',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF8C',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E74C' => {
                                    'softbank' => {
                                                    'unicode' => 'E340',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0D1',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E704' => {
                                    'softbank' => {
                                                    'unicode' => '！！',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ECF1',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E712' => {
                                    'softbank' => {
                                                    'unicode' => '［スノボ］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF91',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E698' => {
                                    'softbank' => {
                                                    'unicode' => 'E536',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ECEB',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E68E' => {
                                    'softbank' => {
                                                    'unicode' => 'E20E',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0BE',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E684' => {
                                    'softbank' => {
                                                    'unicode' => 'E314',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0BC',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6DA' => {
                                    'softbank' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F079',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E722' => {
                                    'softbank' => {
                                                    'unicode' => 'E415E331',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF49F0CE',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6EA' => {
                                    'softbank' => {
                                                    'unicode' => 'E224',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F046',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6F7' => {
                                    'softbank' => {
                                                    'unicode' => 'E123',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF95',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E73F' => {
                                    'softbank' => {
                                                    'unicode' => 'E43E',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ED81',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E710' => {
                                    'softbank' => {
                                                    'unicode' => 'E31C',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFE2',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E721' => {
                                    'softbank' => {
                                                    'unicode' => 'E40A',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC99',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E686' => {
                                    'softbank' => {
                                                    'unicode' => 'E34B',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0BD',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E724' => {
                                    'softbank' => {
                                                    'unicode' => 'E416',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ED61',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6FF' => {
                                    'softbank' => {
                                                    'unicode' => 'E326',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFDE',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E71D' => {
                                    'softbank' => {
                                                    'unicode' => 'E136',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF87',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6FB' => {
                                    'softbank' => {
                                                    'unicode' => 'E10F',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF4E',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6A4' => {
                                    'softbank' => {
                                                    'unicode' => 'E033',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFA2',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E757' => {
                                    'softbank' => {
                                                    'unicode' => 'E107',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0F5',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6DC' => {
                                    'softbank' => {
                                                    'unicode' => 'E114',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFF1',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E680' => {
                                    'softbank' => {
                                                    'unicode' => 'E208',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF56',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6F4' => {
                                    'softbank' => {
                                                    'unicode' => 'E406',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0CB',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E66A' => {
                                    'softbank' => {
                                                    'unicode' => 'E156',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF7C',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E66D' => {
                                    'softbank' => {
                                                    'unicode' => 'E14E',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF42',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E641' => {
                                    'softbank' => {
                                                    'unicode' => 'E048',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF5D',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6AE' => {
                                    'softbank' => {
                                                    'unicode' => '［ペン］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0DA',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E755' => {
                                    'softbank' => {
                                                    'unicode' => 'E10B',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFB7',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E732' => {
                                    'softbank' => {
                                                    'unicode' => 'E537',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F06A',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E70D' => {
                                    'softbank' => {
                                                    'unicode' => '［ｉアプリ］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => '［ｉアプリ］',
                                                'type' => 'name'
                                              }
                                  },
                        'E6DE' => {
                                    'softbank' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ECED',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E648' => {
                                    'softbank' => {
                                                    'unicode' => 'E241',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF69',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6A1' => {
                                    'softbank' => {
                                                    'unicode' => 'E052',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFBA',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6EF' => {
                                    'softbank' => {
                                                    'unicode' => 'E327',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF50',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E746' => {
                                    'softbank' => {
                                                    'unicode' => 'E110',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ED82',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E65B' => {
                                    'softbank' => {
                                                    'unicode' => 'E01E',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF8E',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E643' => {
                                    'softbank' => {
                                                    'unicode' => 'E443',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF41',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E653' => {
                                    'softbank' => {
                                                    'unicode' => 'E016',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF93',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6B2' => {
                                    'softbank' => {
                                                    'unicode' => 'E11F',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => '［いす］',
                                                'type' => 'name'
                                              }
                                  },
                        'E64A' => {
                                    'softbank' => {
                                                    'unicode' => 'E243',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF6B',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6E7' => {
                                    'softbank' => {
                                                    'unicode' => 'E221',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F043',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6E4' => {
                                    'softbank' => {
                                                    'unicode' => 'E21E',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F040',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6DF' => {
                                    'softbank' => {
                                                    'unicode' => 'E211',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => '［フリーダイヤル］',
                                                'type' => 'name'
                                              }
                                  },
                        'E744' => {
                                    'softbank' => {
                                                    'unicode' => '［バナナ］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ECF6',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6DB' => {
                                    'softbank' => {
                                                    'unicode' => '［ＣＬ］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0C8',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E663' => {
                                    'softbank' => {
                                                    'unicode' => 'E036',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF84',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E666' => {
                                    'softbank' => {
                                                    'unicode' => 'E155',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC52',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6AC' => {
                                    'softbank' => {
                                                    'unicode' => 'E324',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF97',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E695' => {
                                    'softbank' => {
                                                    'unicode' => 'E012',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0C4',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E65D' => {
                                    'softbank' => {
                                                    'unicode' => 'E435',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF89',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E67F' => {
                                    'softbank' => {
                                                    'unicode' => 'E30E',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF55',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6B1' => {
                                    'softbank' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => '〓',
                                                'type' => 'name'
                                              }
                                  },
                        'E654' => {
                                    'softbank' => {
                                                    'unicode' => 'E014',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0B6',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E670' => {
                                    'softbank' => {
                                                    'unicode' => 'E045',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0B4',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E708' => {
                                    'softbank' => {
                                                    'unicode' => 'E330',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFCD',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E748' => {
                                    'softbank' => {
                                                    'unicode' => 'E030',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFA3',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E736' => {
                                    'softbank' => {
                                                    'unicode' => 'E24F',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F075',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6F1' => {
                                    'softbank' => {
                                                    'unicode' => 'E059',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF4A',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6A2' => {
                                    'softbank' => {
                                                    'unicode' => 'E04F',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFB4',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E687' => {
                                    'softbank' => {
                                                    'unicode' => 'E009',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0B3',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6D1' => {
                                    'softbank' => {
                                                    'unicode' => '［ｉモード］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => '［ｉモード］',
                                                'type' => 'name'
                                              }
                                  },
                        'E68C' => {
                                    'softbank' => {
                                                    'unicode' => 'E126',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFE5',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E70E' => {
                                    'softbank' => {
                                                    'unicode' => 'E006',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0E6',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E733' => {
                                    'softbank' => {
                                                    'unicode' => 'E115',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF43',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E679' => {
                                    'softbank' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => '〓',
                                                'type' => 'name'
                                              }
                                  },
                        'E646' => {
                                    'softbank' => {
                                                    'unicode' => 'E23F',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF67',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E690' => {
                                    'softbank' => {
                                                    'unicode' => 'E20F',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0C0',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E720' => {
                                    'softbank' => {
                                                    'unicode' => 'E403',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC94',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6F5' => {
                                    'softbank' => {
                                                    'unicode' => 'E236',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ECEE',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E64E' => {
                                    'softbank' => {
                                                    'unicode' => 'E247',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF6F',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6E2' => {
                                    'softbank' => {
                                                    'unicode' => 'E21C',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFFB',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E675' => {
                                    'softbank' => {
                                                    'unicode' => 'E313',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFEF',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6D8' => {
                                    'softbank' => {
                                                    'unicode' => 'E229',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC5B',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E717' => {
                                    'softbank' => {
                                                    'unicode' => 'E103E328',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ED7C',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6B7' => {
                                    'softbank' => {
                                                    'unicode' => '［ＳＯＯＮ］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => '［ＳＯＯＮ］',
                                                'type' => 'name'
                                              }
                                  },
                        'E719' => {
                                    'softbank' => {
                                                    'unicode' => 'E301',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF79',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E673' => {
                                    'softbank' => {
                                                    'unicode' => 'E120',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFAF',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E697' => {
                                    'softbank' => {
                                                    'unicode' => 'E237',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F068',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E730' => {
                                    'softbank' => {
                                                    'unicode' => '［クリップ］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF78',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6ED' => {
                                    'softbank' => {
                                                    'unicode' => 'E327',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ED79',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E742' => {
                                    'softbank' => {
                                                    'unicode' => '［チェリー］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFAB',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E65E' => {
                                    'softbank' => {
                                                    'unicode' => 'E01B',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF8A',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E69A' => {
                                    'softbank' => {
                                                    'unicode' => '［メガネ］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFD7',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E71C' => {
                                    'softbank' => {
                                                    'unicode' => '［砂時計］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF54',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E752' => {
                                    'softbank' => {
                                                    'unicode' => 'E056',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ECA1',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E735' => {
                                    'softbank' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ED7D',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E69E' => {
                                    'softbank' => {
                                                    'unicode' => 'E04C',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0C7',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E706' => {
                                    'softbank' => {
                                                    'unicode' => 'E331',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0CE',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E68A' => {
                                    'softbank' => {
                                                    'unicode' => 'E12A',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFDB',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E738' => {
                                    'softbank' => {
                                                    'unicode' => '［禁］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => '［禁］',
                                                'type' => 'name'
                                              }
                                  },
                        'E640' => {
                                    'softbank' => {
                                                    'unicode' => 'E04B',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF64',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E672' => {
                                    'softbank' => {
                                                    'unicode' => 'E047',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF9C',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E70C' => {
                                    'softbank' => {
                                                    'unicode' => '［ｉアプリ］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => '［ｉアプリ］',
                                                'type' => 'name'
                                              }
                                  },
                        'E657' => {
                                    'softbank' => {
                                                    'unicode' => 'E013',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC80',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E69F' => {
                                    'softbank' => {
                                                    'unicode' => 'E04C',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF5E',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6E5' => {
                                    'softbank' => {
                                                    'unicode' => 'E21F',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F041',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E72F' => {
                                    'softbank' => {
                                                    'unicode' => '［ＮＧ］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => '［ＮＧ］',
                                                'type' => 'name'
                                              }
                                  },
                        'E63F' => {
                                    'softbank' => {
                                                    'unicode' => 'E049',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF65',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E699' => {
                                    'softbank' => {
                                                    'unicode' => 'E007',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ECEC',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E73A' => {
                                    'softbank' => {
                                                    'unicode' => '［合］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => '［合］',
                                                'type' => 'name'
                                              }
                                  },
                        'E6A3' => {
                                    'softbank' => {
                                                    'unicode' => 'E01C',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF8D',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E67C' => {
                                    'softbank' => {
                                                    'unicode' => 'E503',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ECC9',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E727' => {
                                    'softbank' => {
                                                    'unicode' => 'E00E',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFD2',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6EB' => {
                                    'softbank' => {
                                                    'unicode' => 'E225',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0C9',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E72C' => {
                                    'softbank' => {
                                                    'unicode' => 'E402',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC93',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6D5' => {
                                    'softbank' => {
                                                    'unicode' => '［ドコモポイント］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => '［ドコモポイント］',
                                                'type' => 'name'
                                              }
                                  },
                        'E6F2' => {
                                    'softbank' => {
                                                    'unicode' => 'E058',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC94',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E700' => {
                                    'softbank' => {
                                                    'unicode' => 'E238',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ECEF',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E703' => {
                                    'softbank' => {
                                                    'unicode' => '！？',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ECF0',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E655' => {
                                    'softbank' => {
                                                    'unicode' => 'E015',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF90',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E711' => {
                                    'softbank' => {
                                                    'unicode' => '［ジーンズ］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ED7B',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E705' => {
                                    'softbank' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0CD',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E642' => {
                                    'softbank' => {
                                                    'unicode' => 'E13D',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF5F',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E71E' => {
                                    'softbank' => {
                                                    'unicode' => 'E338',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC82',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6F3' => {
                                    'softbank' => {
                                                    'unicode' => 'E407',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC97',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E66C' => {
                                    'softbank' => {
                                                    'unicode' => 'E14F',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF7E',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E73D' => {
                                    'softbank' => {
                                                    'unicode' => '↑↓',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ED80',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6FD' => {
                                    'softbank' => {
                                                    'unicode' => 'E00D',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFCC',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E66F' => {
                                    'softbank' => {
                                                    'unicode' => 'E043',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF85',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E739' => {
                                    'softbank' => {
                                                    'unicode' => 'E22B',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC5D',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E66E' => {
                                    'softbank' => {
                                                    'unicode' => 'E151',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF7D',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E723' => {
                                    'softbank' => {
                                                    'unicode' => 'E108',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0F6',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E72E' => {
                                    'softbank' => {
                                                    'unicode' => 'E413',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ED6D',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E67B' => {
                                    'softbank' => {
                                                    'unicode' => 'E502',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0B9',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6B9' => {
                                    'softbank' => {
                                                    'unicode' => '［ｅｎｄ］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => '［ｅｎｄ］',
                                                'type' => 'name'
                                              }
                                  },
                        'E715' => {
                                    'softbank' => {
                                                    'unicode' => 'E12F',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFA0',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6F8' => {
                                    'softbank' => {
                                                    'unicode' => '〓',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => '〓',
                                                'type' => 'name'
                                              }
                                  },
                        'E6CF' => {
                                    'softbank' => {
                                                    'unicode' => 'E103',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ED66',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6DD' => {
                                    'softbank' => {
                                                    'unicode' => 'E212',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0E5',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E756' => {
                                    'softbank' => {
                                                    'unicode' => 'E044',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF9A',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E651' => {
                                    'softbank' => {
                                                    'unicode' => 'E24A',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF72',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E649' => {
                                    'softbank' => {
                                                    'unicode' => 'E242',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF6A',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E740' => {
                                    'softbank' => {
                                                    'unicode' => 'E03B',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0ED',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E650' => {
                                    'softbank' => {
                                                    'unicode' => 'E249',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF71',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E71F' => {
                                    'softbank' => {
                                                    'unicode' => '［腕時計］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F097',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E681' => {
                                    'softbank' => {
                                                    'unicode' => 'E008',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFEE',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6EE' => {
                                    'softbank' => {
                                                    'unicode' => 'E023',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF4F',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E71A' => {
                                    'softbank' => {
                                                    'unicode' => 'E10E',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0F9',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6B3' => {
                                    'softbank' => {
                                                    'unicode' => 'E44B',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'ECC5',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E66B' => {
                                    'softbank' => {
                                                    'unicode' => 'E03A',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F08E',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6E9' => {
                                    'softbank' => {
                                                    'unicode' => 'E223',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F045',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E685' => {
                                    'softbank' => {
                                                    'unicode' => 'E112',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFA8',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E692' => {
                                    'softbank' => {
                                                    'unicode' => 'E41B',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0C2',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E70F' => {
                                    'softbank' => {
                                                    'unicode' => '［財布］',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFDD',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E749' => {
                                    'softbank' => {
                                                    'unicode' => 'E342',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFAE',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E74D' => {
                                    'softbank' => {
                                                    'unicode' => 'E339',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC83',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6A0' => {
                                    'softbank' => {
                                                    'unicode' => '○',
                                                    'type' => 'name'
                                                  },
                                    'kddi' => {
                                                'unicode' => '○',
                                                'type' => 'name'
                                              }
                                  },
                        'E665' => {
                                    'softbank' => {
                                                    'unicode' => 'E153',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC51',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E677' => {
                                    'softbank' => {
                                                    'unicode' => 'E03D',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFF0',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E668' => {
                                    'softbank' => {
                                                    'unicode' => 'E154',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF7B',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6FA' => {
                                    'softbank' => {
                                                    'unicode' => 'E32E',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC7E',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E688' => {
                                    'softbank' => {
                                                    'unicode' => 'E00A',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'F0A5',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E713' => {
                                    'softbank' => {
                                                    'unicode' => 'E325',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFEB',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E74B' => {
                                    'softbank' => {
                                                    'unicode' => 'E30B',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EC6A',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E754' => {
                                    'softbank' => {
                                                    'unicode' => 'E01A',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFB1',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E751' => {
                                    'softbank' => {
                                                    'unicode' => 'E019',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF72',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E659' => {
                                    'softbank' => {
                                                    'unicode' => 'E132',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EF92',
                                                'type' => 'pictogram'
                                              }
                                  },
                        'E6D3' => {
                                    'softbank' => {
                                                    'unicode' => 'E103',
                                                    'type' => 'pictogram'
                                                  },
                                    'kddi' => {
                                                'unicode' => 'EFFA',
                                                'type' => 'pictogram'
                                              }
                                  }
                      },
          'kddi' => {
                      'EC8A' => {
                                  'softbank' => {
                                                  'unicode' => 'E341',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[カレー]',
                                                'type' => 'name'
                                              }
                                },
                      'EF62' => {
                                  'softbank' => {
                                                  'unicode' => '[雪結晶]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[雪結晶]',
                                                'type' => 'name'
                                              }
                                },
                      'F07A' => {
                                  'softbank' => {
                                                  'unicode' => '[チェックマーク]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[チェックマーク]',
                                                'type' => 'name'
                                              }
                                },
                      'F0F2' => {
                                  'softbank' => {
                                                  'unicode' => 'E053',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ネズミ]',
                                                'type' => 'name'
                                              }
                                },
                      'EFFB' => {
                                  'softbank' => {
                                                  'unicode' => 'E21C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6E2',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC6E' => {
                                  'softbank' => {
                                                  'unicode' => 'E310',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[風船]',
                                                'type' => 'name'
                                              }
                                },
                      'ED60' => {
                                  'softbank' => {
                                                  'unicode' => 'E407',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[クラクラ]',
                                                'type' => 'name'
                                              }
                                },
                      'ECDC' => {
                                  'softbank' => {
                                                  'unicode' => 'E520',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[イルカ]',
                                                'type' => 'name'
                                              }
                                },
                      'EF83' => {
                                  'softbank' => {
                                                  'unicode' => 'E14D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E667',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECA0' => {
                                  'softbank' => {
                                                  'unicode' => 'E326',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6FF',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC5B' => {
                                  'softbank' => {
                                                  'unicode' => 'E229',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6D8',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0CA' => {
                                  'softbank' => {
                                                  'unicode' => 'E24D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E70B',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECE0' => {
                                  'softbank' => {
                                                  'unicode' => 'E526',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ゾウ]',
                                                'type' => 'name'
                                              }
                                },
                      'F084' => {
                                  'softbank' => {
                                                  'unicode' => 'E148',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E683',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFBD' => {
                                  'softbank' => {
                                                  'unicode' => 'E304',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E743',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFE4' => {
                                  'softbank' => {
                                                  'unicode' => 'E31E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[エステ]',
                                                'type' => 'name'
                                              }
                                },
                      'F0E0' => {
                                  'softbank' => {
                                                  'unicode' => 'E036',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E663',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF89' => {
                                  'softbank' => {
                                                  'unicode' => 'E01F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E65D',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC45' => {
                                  'softbank' => {
                                                  'unicode' => 'E12E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[VS]',
                                                'type' => 'name'
                                              }
                                },
                      'ECE7' => {
                                  'softbank' => {
                                                  'unicode' => 'E532',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[A]',
                                                'type' => 'name'
                                              }
                                },
                      'EC94' => {
                                  'softbank' => {
                                                  'unicode' => 'E403',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E720',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF9A' => {
                                  'softbank' => {
                                                  'unicode' => 'E044',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E756',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFBC' => {
                                  'softbank' => {
                                                  'unicode' => 'E305',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ひまわり]',
                                                'type' => 'name'
                                              }
                                },
                      'EF45' => {
                                  'softbank' => {
                                                  'unicode' => 'E124',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[観覧車]',
                                                'type' => 'name'
                                              }
                                },
                      'ED50' => {
                                  'softbank' => {
                                                  'unicode' => '[クッキー]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[クッキー]',
                                                'type' => 'name'
                                              }
                                },
                      'EC69' => {
                                  'softbank' => {
                                                  'unicode' => 'E308',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[サボテン]',
                                                'type' => 'name'
                                              }
                                },
                      'EFCB' => {
                                  'softbank' => {
                                                  'unicode' => '[100点]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[100点]',
                                                'type' => 'name'
                                              }
                                },
                      'ED6C' => {
                                  'softbank' => {
                                                  'unicode' => 'E413',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E72E',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFC4' => {
                                  'softbank' => {
                                                  'unicode' => 'E003',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6F9',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF79' => {
                                  'softbank' => {
                                                  'unicode' => 'E301',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E719',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC59' => {
                                  'softbank' => {
                                                  'unicode' => 'E227',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[割]',
                                                'type' => 'name'
                                              }
                                },
                      'ED49' => {
                                  'softbank' => {
                                                  'unicode' => '[天狗]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[天狗]',
                                                'type' => 'name'
                                              }
                                },
                      'F071' => {
                                  'softbank' => {
                                                  'unicode' => 'E236',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E678',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0E6' => {
                                  'softbank' => {
                                                  'unicode' => 'E006',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E70E',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0A5' => {
                                  'softbank' => {
                                                  'unicode' => 'E00A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E688',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF8E' => {
                                  'softbank' => {
                                                  'unicode' => 'E01E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E65B',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED89' => {
                                  'softbank' => {
                                                  'unicode' => 'E210',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6E0',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC85' => {
                                  'softbank' => {
                                                  'unicode' => 'E33B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ポテト]',
                                                'type' => 'name'
                                              }
                                },
                      'F06B' => {
                                  'softbank' => {
                                                  'unicode' => 'E333',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '×',
                                                'type' => 'name'
                                              }
                                },
                      'EC8F' => {
                                  'softbank' => {
                                                  'unicode' => 'E349',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[トマト]',
                                                'type' => 'name'
                                              }
                                },
                      'EF64' => {
                                  'softbank' => {
                                                  'unicode' => 'E04B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E640',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC71' => {
                                  'softbank' => {
                                                  'unicode' => 'E318',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[帽子]',
                                                'type' => 'name'
                                              }
                                },
                      'ECBE' => {
                                  'softbank' => {
                                                  'unicode' => 'E43F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[カキ氷]',
                                                'type' => 'name'
                                              }
                                },
                      'ED77' => {
                                  'softbank' => {
                                                  'unicode' => 'E432',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[パトカー]',
                                                'type' => 'name'
                                              }
                                },
                      'EC9E' => {
                                  'softbank' => {
                                                  'unicode' => 'E410',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6F4',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECAA' => {
                                  'softbank' => {
                                                  'unicode' => 'E41E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E695',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F098' => {
                                  'softbank' => {
                                                  'unicode' => '[砂時計]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E71C',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F079' => {
                                  'softbank' => {
                                                  'unicode' => '←┘',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6DA',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F056' => {
                                  'softbank' => {
                                                  'unicode' => 'E219',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E69C',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFD2' => {
                                  'softbank' => {
                                                  'unicode' => 'E00E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E727',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF84' => {
                                  'softbank' => {
                                                  'unicode' => 'E036',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E663',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF49' => {
                                  'softbank' => {
                                                  'unicode' => 'E057',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6F0',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECCA' => {
                                  'softbank' => {
                                                  'unicode' => 'E504',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[デパート]',
                                                'type' => 'name'
                                              }
                                },
                      'F08E' => {
                                  'softbank' => {
                                                  'unicode' => 'E03A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E66B',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F086' => {
                                  'softbank' => {
                                                  'unicode' => 'E301',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E689',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF48' => {
                                  'softbank' => {
                                                  'unicode' => 'E054',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[クジラ]',
                                                'type' => 'name'
                                              }
                                },
                      'ECC4' => {
                                  'softbank' => {
                                                  'unicode' => 'E448',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[サンタ]',
                                                'type' => 'name'
                                              }
                                },
                      'EFCC' => {
                                  'softbank' => {
                                                  'unicode' => 'E00D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6FD',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0B5' => {
                                  'softbank' => {
                                                  'unicode' => '[霧]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E644',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC51' => {
                                  'softbank' => {
                                                  'unicode' => 'E153',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E665',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF5C' => {
                                  'softbank' => {
                                                  'unicode' => 'E137',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E72F',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED79' => {
                                  'softbank' => {
                                                  'unicode' => 'E327',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6ED',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF9F' => {
                                  'softbank' => {
                                                  'unicode' => '[ゲーム]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E68B',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0EF' => {
                                  'softbank' => {
                                                  'unicode' => 'E04E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[天使]',
                                                'type' => 'name'
                                              }
                                },
                      'ED7E' => {
                                  'softbank' => {
                                                  'unicode' => '⇔',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E73C',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F093' => {
                                  'softbank' => {
                                                  'unicode' => '[グラフ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[グラフ]',
                                                'type' => 'name'
                                              }
                                },
                      'ED48' => {
                                  'softbank' => {
                                                  'unicode' => '[なまはげ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[なまはげ]',
                                                'type' => 'name'
                                              }
                                },
                      'F0C2' => {
                                  'softbank' => {
                                                  'unicode' => 'E41B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E692',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0AF' => {
                                  'softbank' => {
                                                  'unicode' => '[送信BOX]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[送信BOX]',
                                                'type' => 'name'
                                              }
                                },
                      'EF4A' => {
                                  'softbank' => {
                                                  'unicode' => 'E059',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6F1',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECF7' => {
                                  'softbank' => {
                                                  'unicode' => '[とうもろこし]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[とうもろこし]',
                                                'type' => 'name'
                                              }
                                },
                      'ECB1' => {
                                  'softbank' => {
                                                  'unicode' => 'E42C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ビリヤード]',
                                                'type' => 'name'
                                              }
                                },
                      'EFF4' => {
                                  'softbank' => {
                                                  'unicode' => 'E101',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E665',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF9E' => {
                                  'softbank' => {
                                                  'unicode' => 'E130',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[的中]',
                                                'type' => 'name'
                                              }
                                },
                      'F0BD' => {
                                  'softbank' => {
                                                  'unicode' => 'E34B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E686',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F085' => {
                                  'softbank' => {
                                                  'unicode' => 'E148',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E683',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF57' => {
                                  'softbank' => {
                                                  'unicode' => 'E20A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E69B',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC86' => {
                                  'softbank' => {
                                                  'unicode' => 'E33C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[だんご]',
                                                'type' => 'name'
                                              }
                                },
                      'EC4C' => {
                                  'softbank' => {
                                                  'unicode' => 'E143',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[祝日]',
                                                'type' => 'name'
                                              }
                                },
                      'F047' => {
                                  'softbank' => {
                                                  'unicode' => '[10]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[10]',
                                                'type' => 'name'
                                              }
                                },
                      'EFEA' => {
                                  'softbank' => {
                                                  'unicode' => 'E141',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[スピーカ]',
                                                'type' => 'name'
                                              }
                                },
                      'EFD9' => {
                                  'softbank' => {
                                                  'unicode' => 'E231',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '→',
                                                'type' => 'name'
                                              }
                                },
                      'F0EA' => {
                                  'softbank' => {
                                                  'unicode' => 'E032',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[バラ]',
                                                'type' => 'name'
                                              }
                                },
                      'ECA7' => {
                                  'softbank' => {
                                                  'unicode' => 'E41F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[拍手]',
                                                'type' => 'name'
                                              }
                                },
                      'ECDD' => {
                                  'softbank' => {
                                                  'unicode' => 'E51F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ダンス]',
                                                'type' => 'name'
                                              }
                                },
                      'ECC5' => {
                                  'softbank' => {
                                                  'unicode' => 'E44B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6B3',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF98' => {
                                  'softbank' => {
                                                  'unicode' => 'E44B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6B3',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECB3' => {
                                  'softbank' => {
                                                  'unicode' => 'E430',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[消防車]',
                                                'type' => 'name'
                                              }
                                },
                      'F0C0' => {
                                  'softbank' => {
                                                  'unicode' => 'E20F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E690',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F064' => {
                                  'softbank' => {
                                                  'unicode' => 'E21B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '■',
                                                'type' => 'name'
                                              }
                                },
                      'F061' => {
                                  'softbank' => {
                                                  'unicode' => '▲',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '▲',
                                                'type' => 'name'
                                              }
                                },
                      'F0CB' => {
                                  'softbank' => {
                                                  'unicode' => 'E406',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6F4',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF9D' => {
                                  'softbank' => {
                                                  'unicode' => '[肉]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[肉]',
                                                'type' => 'name'
                                              }
                                },
                      'EC68' => {
                                  'softbank' => {
                                                  'unicode' => 'E306',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[花束]',
                                                'type' => 'name'
                                              }
                                },
                      'F0C8' => {
                                  'softbank' => {
                                                  'unicode' => '[CL]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6DB',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED41' => {
                                  'softbank' => {
                                                  'unicode' => '[七夕]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[七夕]',
                                                'type' => 'name'
                                              }
                                },
                      'EC47' => {
                                  'softbank' => {
                                                  'unicode' => '[カメ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[カメ]',
                                                'type' => 'name'
                                              }
                                },
                      'F06C' => {
                                  'softbank' => {
                                                  'unicode' => 'E333',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '×',
                                                'type' => 'name'
                                              }
                                },
                      'ECB6' => {
                                  'softbank' => {
                                                  'unicode' => 'E433',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ジェットコースター]',
                                                'type' => 'name'
                                              }
                                },
                      'ECEC' => {
                                  'softbank' => {
                                                  'unicode' => 'E007',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E699',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC93' => {
                                  'softbank' => {
                                                  'unicode' => 'E402',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E72C',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED78' => {
                                  'softbank' => {
                                                  'unicode' => '[EZムービー]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[EZムービー]',
                                                'type' => 'name'
                                              }
                                },
                      'F0DC' => {
                                  'softbank' => {
                                                  'unicode' => 'E114',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6DC',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED6D' => {
                                  'softbank' => {
                                                  'unicode' => 'E413',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E72E',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECFA' => {
                                  'softbank' => {
                                                  'unicode' => '[モモ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[モモ]',
                                                'type' => 'name'
                                              }
                                },
                      'EFCF' => {
                                  'softbank' => {
                                                  'unicode' => 'E00F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[人差し指]',
                                                'type' => 'name'
                                              }
                                },
                      'EF88' => {
                                  'softbank' => {
                                                  'unicode' => 'E159',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E660',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0BC' => {
                                  'softbank' => {
                                                  'unicode' => 'E314',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E684',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F09A' => {
                                  'softbank' => {
                                                  'unicode' => '￥',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6D6',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED61' => {
                                  'softbank' => {
                                                  'unicode' => 'E416',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E724',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F057' => {
                                  'softbank' => {
                                                  'unicode' => 'E219',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E69C',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF63' => {
                                  'softbank' => {
                                                  'unicode' => 'E32F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '☆',
                                                'type' => 'name'
                                              }
                                },
                      'EFE5' => {
                                  'softbank' => {
                                                  'unicode' => 'E126',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E68C',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC84' => {
                                  'softbank' => {
                                                  'unicode' => 'E33A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ソフトクリーム]',
                                                'type' => 'name'
                                              }
                                },
                      'EFB2' => {
                                  'softbank' => {
                                                  'unicode' => 'E109',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[サル]',
                                                'type' => 'name'
                                              }
                                },
                      'EF71' => {
                                  'softbank' => {
                                                  'unicode' => 'E249',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E650',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFA4' => {
                                  'softbank' => {
                                                  'unicode' => 'E11B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[お化け]',
                                                'type' => 'name'
                                              }
                                },
                      'EFB8' => {
                                  'softbank' => {
                                                  'unicode' => 'E052',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6A1',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF7C' => {
                                  'softbank' => {
                                                  'unicode' => 'E156',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E66A',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC6D' => {
                                  'softbank' => {
                                                  'unicode' => 'E30F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[薬]',
                                                'type' => 'name'
                                              }
                                },
                      'EFC8' => {
                                  'softbank' => {
                                                  'unicode' => 'E11A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[アクマ]',
                                                'type' => 'name'
                                              }
                                },
                      'EFBE' => {
                                  'softbank' => {
                                                  'unicode' => 'E334',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6FC',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF46' => {
                                  'softbank' => {
                                                  'unicode' => 'E133',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[777]',
                                                'type' => 'name'
                                              }
                                },
                      'EF72' => {
                                  'softbank' => {
                                                  'unicode' => 'E24A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E651',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0AA' => {
                                  'softbank' => {
                                                  'unicode' => '',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '',
                                                'type' => 'name'
                                              }
                                },
                      'EC42' => {
                                  'softbank' => {
                                                  'unicode' => 'E121',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[噴水]',
                                                'type' => 'name'
                                              }
                                },
                      'F0E5' => {
                                  'softbank' => {
                                                  'unicode' => 'E212',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6DD',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF4F' => {
                                  'softbank' => {
                                                  'unicode' => 'E023',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6EE',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFA5' => {
                                  'softbank' => {
                                                  'unicode' => 'E50B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[日の丸]',
                                                'type' => 'name'
                                              }
                                },
                      'EC52' => {
                                  'softbank' => {
                                                  'unicode' => 'E155',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E666',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F05F' => {
                                  'softbank' => {
                                                  'unicode' => '▲',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '▲',
                                                'type' => 'name'
                                              }
                                },
                      'F0D5' => {
                                  'softbank' => {
                                                  'unicode' => '[abcd]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[abcd]',
                                                'type' => 'name'
                                              }
                                },
                      'ED7A' => {
                                  'softbank' => {
                                                  'unicode' => 'E523',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E74F',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC76' => {
                                  'softbank' => {
                                                  'unicode' => 'E321',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[着物]',
                                                'type' => 'name'
                                              }
                                },
                      'EC9B' => {
                                  'softbank' => {
                                                  'unicode' => 'E40C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[風邪ひき]',
                                                'type' => 'name'
                                              }
                                },
                      'EFCE' => {
                                  'softbank' => {
                                                  'unicode' => 'E05A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ウンチ]',
                                                'type' => 'name'
                                              }
                                },
                      'EFA6' => {
                                  'softbank' => {
                                                  'unicode' => 'E348',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[スイカ]',
                                                'type' => 'name'
                                              }
                                },
                      'EF54' => {
                                  'softbank' => {
                                                  'unicode' => '[砂時計]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E71C',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECD2' => {
                                  'softbank' => {
                                                  'unicode' => 'E513',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[中国]',
                                                'type' => 'name'
                                              }
                                },
                      'ECC3' => {
                                  'softbank' => {
                                                  'unicode' => 'E446',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[お月見]',
                                                'type' => 'name'
                                              }
                                },
                      'ED56' => {
                                  'softbank' => {
                                                  'unicode' => '|(・×・)|',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '|(・×・)|',
                                                'type' => 'name'
                                              }
                                },
                      'EFF3' => {
                                  'softbank' => {
                                                  'unicode' => 'E13E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E674',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0B4' => {
                                  'softbank' => {
                                                  'unicode' => 'E045',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E670',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECBD' => {
                                  'softbank' => {
                                                  'unicode' => '[花嫁]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[花嫁]',
                                                'type' => 'name'
                                              }
                                },
                      'F05B' => {
                                  'softbank' => {
                                                  'unicode' => 'E232',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '↑',
                                                'type' => 'name'
                                              }
                                },
                      'F094' => {
                                  'softbank' => {
                                                  'unicode' => '[EZ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[EZ]',
                                                'type' => 'name'
                                              }
                                },
                      'EF67' => {
                                  'softbank' => {
                                                  'unicode' => 'E23F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E646',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFDB' => {
                                  'softbank' => {
                                                  'unicode' => 'E12A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E68A',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0E1' => {
                                  'softbank' => {
                                                  'unicode' => 'E101',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E665',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED59' => {
                                  'softbank' => {
                                                  'unicode' => '[ABC]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ABC]',
                                                'type' => 'name'
                                              }
                                },
                      'ECD3' => {
                                  'softbank' => {
                                                  'unicode' => 'E514',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[韓国]',
                                                'type' => 'name'
                                              }
                                },
                      'F0C1' => {
                                  'softbank' => {
                                                  'unicode' => 'E419',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E691',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F07B' => {
                                  'softbank' => {
                                                  'unicode' => '[スクロール]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E70A',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFE9' => {
                                  'softbank' => {
                                                  'unicode' => 'E13B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[注射]',
                                                'type' => 'name'
                                              }
                                },
                      'EFD3' => {
                                  'softbank' => {
                                                  'unicode' => 'E002',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6F0',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECA3' => {
                                  'softbank' => {
                                                  'unicode' => 'E418',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '(´３｀)',
                                                'type' => 'name'
                                              }
                                },
                      'EC87' => {
                                  'softbank' => {
                                                  'unicode' => 'E33D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[せんべい]',
                                                'type' => 'name'
                                              }
                                },
                      'EF85' => {
                                  'softbank' => {
                                                  'unicode' => 'E043',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E66F',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF5D' => {
                                  'softbank' => {
                                                  'unicode' => 'E048',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E641',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED8C' => {
                                  'softbank' => {
                                                  'unicode' => 'E403',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6F3',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFC3' => {
                                  'softbank' => {
                                                  'unicode' => 'E329',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6EC',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECF0' => {
                                  'softbank' => {
                                                  'unicode' => '！？',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E703',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF6F' => {
                                  'softbank' => {
                                                  'unicode' => 'E247',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E64E',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED4A' => {
                                  'softbank' => {
                                                  'unicode' => '[パンダ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[パンダ]',
                                                'type' => 'name'
                                              }
                                },
                      'ED72' => {
                                  'softbank' => {
                                                  'unicode' => '[花札]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[花札]',
                                                'type' => 'name'
                                              }
                                },
                      'F068' => {
                                  'softbank' => {
                                                  'unicode' => 'E237',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E697',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0A7' => {
                                  'softbank' => {
                                                  'unicode' => '[リンク]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[リンク]',
                                                'type' => 'name'
                                              }
                                },
                      'EFBF' => {
                                  'softbank' => {
                                                  'unicode' => 'E331',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E707',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECED' => {
                                  'softbank' => {
                                                  'unicode' => '[旗]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6DE',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F09B' => {
                                  'softbank' => {
                                                  'unicode' => 'E03D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E677',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F065' => {
                                  'softbank' => {
                                                  'unicode' => 'E21A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '■',
                                                'type' => 'name'
                                              }
                                },
                      'F06D' => {
                                  'softbank' => {
                                                  'unicode' => 'E333',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '×',
                                                'type' => 'name'
                                              }
                                },
                      'EC91' => {
                                  'softbank' => {
                                                  'unicode' => 'E34C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[弁当]',
                                                'type' => 'name'
                                              }
                                },
                      'F0AE' => {
                                  'softbank' => {
                                                  'unicode' => 'E103',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6CF',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFA8' => {
                                  'softbank' => {
                                                  'unicode' => 'E112',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E685',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF56' => {
                                  'softbank' => {
                                                  'unicode' => 'E208',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E680',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED8D' => {
                                  'softbank' => {
                                                  'unicode' => 'E416',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E724',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED70' => {
                                  'softbank' => {
                                                  'unicode' => '[モアイ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[モアイ]',
                                                'type' => 'name'
                                              }
                                },
                      'EFD7' => {
                                  'softbank' => {
                                                  'unicode' => '[メガネ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E69A',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF6A' => {
                                  'softbank' => {
                                                  'unicode' => 'E242',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E649',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF96' => {
                                  'softbank' => {
                                                  'unicode' => 'E30B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E74B',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECD1' => {
                                  'softbank' => {
                                                  'unicode' => 'E510',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[イギリス]',
                                                'type' => 'name'
                                              }
                                },
                      'ECF8' => {
                                  'softbank' => {
                                                  'unicode' => '[キノコ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[キノコ]',
                                                'type' => 'name'
                                              }
                                },
                      'F054' => {
                                  'softbank' => {
                                                  'unicode' => 'E21B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '■',
                                                'type' => 'name'
                                              }
                                },
                      'EF5E' => {
                                  'softbank' => {
                                                  'unicode' => 'E04C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E69F',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECF5' => {
                                  'softbank' => {
                                                  'unicode' => '[ブドウ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ブドウ]',
                                                'type' => 'name'
                                              }
                                },
                      'F0A0' => {
                                  'softbank' => {
                                                  'unicode' => '[懐中電灯]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6FB',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFC2' => {
                                  'softbank' => {
                                                  'unicode' => 'E14C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[力こぶ]',
                                                'type' => 'name'
                                              }
                                },
                      'F046' => {
                                  'softbank' => {
                                                  'unicode' => 'E224',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6EA',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFD0' => {
                                  'softbank' => {
                                                  'unicode' => 'E226',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[得]',
                                                'type' => 'name'
                                              }
                                },
                      'F053' => {
                                  'softbank' => {
                                                  'unicode' => 'E21B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '◆',
                                                'type' => 'name'
                                              }
                                },
                      'EFAC' => {
                                  'softbank' => {
                                                  'unicode' => 'E019',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E751',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF43' => {
                                  'softbank' => {
                                                  'unicode' => 'E115',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E733',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED68' => {
                                  'softbank' => {
                                                  'unicode' => 'E412',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E72A',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F092' => {
                                  'softbank' => {
                                                  'unicode' => 'E14A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[グラフ]',
                                                'type' => 'name'
                                              }
                                },
                      'F073' => {
                                  'softbank' => {
                                                  'unicode' => '[チェックマーク]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[チェックマーク]',
                                                'type' => 'name'
                                              }
                                },
                      'F0B3' => {
                                  'softbank' => {
                                                  'unicode' => 'E009',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E687',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECAE' => {
                                  'softbank' => {
                                                  'unicode' => 'E425',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6ED',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECBB' => {
                                  'softbank' => {
                                                  'unicode' => 'E43B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[こいのぼり]',
                                                'type' => 'name'
                                              }
                                },
                      'ECD9' => {
                                  'softbank' => {
                                                  'unicode' => 'E51A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[赤ちゃん]',
                                                'type' => 'name'
                                              }
                                },
                      'F0F5' => {
                                  'softbank' => {
                                                  'unicode' => 'E410',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E757',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0F4' => {
                                  'softbank' => {
                                                  'unicode' => 'E106',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E726',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC77' => {
                                  'softbank' => {
                                                  'unicode' => 'E322',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ビキニ]',
                                                'type' => 'name'
                                              }
                                },
                      'EC61' => {
                                  'softbank' => {
                                                  'unicode' => 'E22F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '↓',
                                                'type' => 'name'
                                              }
                                },
                      'EFEF' => {
                                  'softbank' => {
                                                  'unicode' => 'E313',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E675',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0C5' => {
                                  'softbank' => {
                                                  'unicode' => '●',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E69C',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0E8' => {
                                  'softbank' => {
                                                  'unicode' => 'E00C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E716',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF77' => {
                                  'softbank' => {
                                                  'unicode' => 'E148',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E683',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFF2' => {
                                  'softbank' => {
                                                  'unicode' => 'E03F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6D9',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFE6' => {
                                  'softbank' => {
                                                  'unicode' => 'E006',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E70E',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECAB' => {
                                  'softbank' => {
                                                  'unicode' => 'E423',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E72F',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFC9' => {
                                  'softbank' => {
                                                  'unicode' => '[花丸]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[花丸]',
                                                'type' => 'name'
                                              }
                                },
                      'ED43' => {
                                  'softbank' => {
                                                  'unicode' => '[辰]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[辰]',
                                                'type' => 'name'
                                              }
                                },
                      'EC7E' => {
                                  'softbank' => {
                                                  'unicode' => 'E32E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6FA',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0D2' => {
                                  'softbank' => {
                                                  'unicode' => '[オープンウェブ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[オープンウェブ]',
                                                'type' => 'name'
                                              }
                                },
                      'ECDA' => {
                                  'softbank' => {
                                                  'unicode' => 'E51B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[工事現場の人]',
                                                'type' => 'name'
                                              }
                                },
                      'EFB3' => {
                                  'softbank' => {
                                                  'unicode' => 'E531',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[カエル]',
                                                'type' => 'name'
                                              }
                                },
                      'F0F6' => {
                                  'softbank' => {
                                                  'unicode' => 'E108',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E723',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED7B' => {
                                  'softbank' => {
                                                  'unicode' => '[ジーンズ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E711',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F08C' => {
                                  'softbank' => {
                                                  'unicode' => 'E148',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E683',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F09F' => {
                                  'softbank' => {
                                                  'unicode' => 'E316',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[フロッピー]',
                                                'type' => 'name'
                                              }
                                },
                      'F0BF' => {
                                  'softbank' => {
                                                  'unicode' => 'E20D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E68F',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F075' => {
                                  'softbank' => {
                                                  'unicode' => 'E24F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E736',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC46' => {
                                  'softbank' => {
                                                  'unicode' => 'E131',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[トロフィー]',
                                                'type' => 'name'
                                              }
                                },
                      'F045' => {
                                  'softbank' => {
                                                  'unicode' => 'E223',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6E9',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF90' => {
                                  'softbank' => {
                                                  'unicode' => 'E015',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E655',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F058' => {
                                  'softbank' => {
                                                  'unicode' => '＋',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '＋',
                                                'type' => 'name'
                                              }
                                },
                      'ECC0' => {
                                  'softbank' => {
                                                  'unicode' => 'E441',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[巻貝]',
                                                'type' => 'name'
                                              }
                                },
                      'ED80' => {
                                  'softbank' => {
                                                  'unicode' => '↑↓',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E73D',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF86' => {
                                  'softbank' => {
                                                  'unicode' => 'E038',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E664',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECA4' => {
                                  'softbank' => {
                                                  'unicode' => 'E41A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[鼻]',
                                                'type' => 'name'
                                              }
                                },
                      'F07C' => {
                                  'softbank' => {
                                                  'unicode' => 'φ',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'φ',
                                                'type' => 'name'
                                              }
                                },
                      'EC9F' => {
                                  'softbank' => {
                                                  'unicode' => 'E40F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E723',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F05C' => {
                                  'softbank' => {
                                                  'unicode' => 'E233',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '↓',
                                                'type' => 'name'
                                              }
                                },
                      'EFE8' => {
                                  'softbank' => {
                                                  'unicode' => 'E213',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[UP!]',
                                                'type' => 'name'
                                              }
                                },
                      'EFCD' => {
                                  'softbank' => {
                                                  'unicode' => 'E330',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E708',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0EC' => {
                                  'softbank' => {
                                                  'unicode' => 'E434',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E65C',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC88' => {
                                  'softbank' => {
                                                  'unicode' => 'E33E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E74C',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECE2' => {
                                  'softbank' => {
                                                  'unicode' => 'E52B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[牛]',
                                                'type' => 'name'
                                              }
                                },
                      'F09C' => {
                                  'softbank' => {
                                                  'unicode' => '[包丁]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[包丁]',
                                                'type' => 'name'
                                              }
                                },
                      'ECA2' => {
                                  'softbank' => {
                                                  'unicode' => 'E417',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '(>３<)',
                                                'type' => 'name'
                                              }
                                },
                      'EF44' => {
                                  'softbank' => {
                                                  'unicode' => 'E32E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6FA',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFDA' => {
                                  'softbank' => {
                                                  'unicode' => '[家族]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[家族]',
                                                'type' => 'name'
                                              }
                                },
                      'ECD0' => {
                                  'softbank' => {
                                                  'unicode' => 'E50F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[イタリア]',
                                                'type' => 'name'
                                              }
                                },
                      'ED4B' => {
                                  'softbank' => {
                                                  'unicode' => 'E409',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E728',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F055' => {
                                  'softbank' => {
                                                  'unicode' => 'E21A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '■',
                                                'type' => 'name'
                                              }
                                },
                      'ECEA' => {
                                  'softbank' => {
                                                  'unicode' => 'E534',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[AB]',
                                                'type' => 'name'
                                              }
                                },
                      'ED67' => {
                                  'softbank' => {
                                                  'unicode' => 'E412',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E72A',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0DE' => {
                                  'softbank' => {
                                                  'unicode' => '[ブックマーク]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ブックマーク]',
                                                'type' => 'name'
                                              }
                                },
                      'ED8A' => {
                                  'softbank' => {
                                                  'unicode' => 'E012',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '(^-^)/',
                                                'type' => 'name'
                                              }
                                },
                      'F0B2' => {
                                  'softbank' => {
                                                  'unicode' => 'E022',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6EC',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFB0' => {
                                  'softbank' => {
                                                  'unicode' => 'E52C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ウサギ]',
                                                'type' => 'name'
                                              }
                                },
                      'EF99' => {
                                  'softbank' => {
                                                  'unicode' => 'E509',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[東京タワー]',
                                                'type' => 'name'
                                              }
                                },
                      'EC9D' => {
                                  'softbank' => {
                                                  'unicode' => 'E40E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E725',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC6C' => {
                                  'softbank' => {
                                                  'unicode' => 'E30D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[祝]',
                                                'type' => 'name'
                                              }
                                },
                      'ECE9' => {
                                  'softbank' => {
                                                  'unicode' => 'E535',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[O]',
                                                'type' => 'name'
                                              }
                                },
                      'F0A6' => {
                                  'softbank' => {
                                                  'unicode' => '[コンセント]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[コンセント]',
                                                'type' => 'name'
                                              }
                                },
                      'EF8D' => {
                                  'softbank' => {
                                                  'unicode' => 'E01C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6A3',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC7D' => {
                                  'softbank' => {
                                                  'unicode' => 'E32D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6EC',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF7A' => {
                                  'softbank' => {
                                                  'unicode' => '[三角定規]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[三角定規]',
                                                'type' => 'name'
                                              }
                                },
                      'EF73' => {
                                  'softbank' => {
                                                  'unicode' => 'E24B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[蛇使座]',
                                                'type' => 'name'
                                              }
                                },
                      'EC5C' => {
                                  'softbank' => {
                                                  'unicode' => 'E22A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E73B',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFAB' => {
                                  'softbank' => {
                                                  'unicode' => '[さくらんぼ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E742',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECC2' => {
                                  'softbank' => {
                                                  'unicode' => 'E445',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ハロウィン]',
                                                'type' => 'name'
                                              }
                                },
                      'ECFC' => {
                                  'softbank' => {
                                                  'unicode' => '[ピザ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ピザ]',
                                                'type' => 'name'
                                              }
                                },
                      'ECD8' => {
                                  'softbank' => {
                                                  'unicode' => 'E519',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[おばあさん]',
                                                'type' => 'name'
                                              }
                                },
                      'ECA9' => {
                                  'softbank' => {
                                                  'unicode' => 'E421',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E700',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC58' => {
                                  'softbank' => {
                                                  'unicode' => 'E214',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[COOL]',
                                                'type' => 'name'
                                              }
                                },
                      'EF60' => {
                                  'softbank' => {
                                                  'unicode' => 'E04A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E63E',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECAC' => {
                                  'softbank' => {
                                                  'unicode' => 'E424',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E70B',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED82' => {
                                  'softbank' => {
                                                  'unicode' => 'E110',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E746',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECB9' => {
                                  'softbank' => {
                                                  'unicode' => 'E439',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[卒業式]',
                                                'type' => 'name'
                                              }
                                },
                      'F099' => {
                                  'softbank' => {
                                                  'unicode' => '[カード]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[カード]',
                                                'type' => 'name'
                                              }
                                },
                      'F062' => {
                                  'softbank' => {
                                                  'unicode' => 'E21B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '◆',
                                                'type' => 'name'
                                              }
                                },
                      'ED58' => {
                                  'softbank' => {
                                                  'unicode' => 'E328',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6EC',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0BE' => {
                                  'softbank' => {
                                                  'unicode' => 'E20E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E68E',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFBB' => {
                                  'softbank' => {
                                                  'unicode' => 'E307',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ビーチ]',
                                                'type' => 'name'
                                              }
                                },
                      'ED44' => {
                                  'softbank' => {
                                                  'unicode' => '[ピアノ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ピアノ]',
                                                'type' => 'name'
                                              }
                                },
                      'F08D' => {
                                  'softbank' => {
                                                  'unicode' => '[定規]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[定規]',
                                                'type' => 'name'
                                              }
                                },
                      'EFD1' => {
                                  'softbank' => {
                                                  'unicode' => 'E11C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ドクロ]',
                                                'type' => 'name'
                                              }
                                },
                      'EC50' => {
                                  'softbank' => {
                                                  'unicode' => 'E152',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[警官]',
                                                'type' => 'name'
                                              }
                                },
                      'F074' => {
                                  'softbank' => {
                                                  'unicode' => 'E24E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E731',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F070' => {
                                  'softbank' => {
                                                  'unicode' => '÷',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '÷',
                                                'type' => 'name'
                                              }
                                },
                      'EF8C' => {
                                  'softbank' => {
                                                  'unicode' => 'E01D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E662',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECBF' => {
                                  'softbank' => {
                                                  'unicode' => 'E440',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[線香花火]',
                                                'type' => 'name'
                                              }
                                },
                      'EFD8' => {
                                  'softbank' => {
                                                  'unicode' => 'E230',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '←',
                                                'type' => 'name'
                                              }
                                },
                      'EC81' => {
                                  'softbank' => {
                                                  'unicode' => 'E332',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6A0',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECDF' => {
                                  'softbank' => {
                                                  'unicode' => 'E525',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ゲジゲジ]',
                                                'type' => 'name'
                                              }
                                },
                      'F040' => {
                                  'softbank' => {
                                                  'unicode' => 'E21E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6E4',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF65' => {
                                  'softbank' => {
                                                  'unicode' => 'E049',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E63F',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC4A' => {
                                  'softbank' => {
                                                  'unicode' => 'E137',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[工事中]',
                                                'type' => 'name'
                                              }
                                },
                      'F0E9' => {
                                  'softbank' => {
                                                  'unicode' => 'E128',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ラジオ]',
                                                'type' => 'name'
                                              }
                                },
                      'F0E7' => {
                                  'softbank' => {
                                                  'unicode' => 'E007',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E699',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF78' => {
                                  'softbank' => {
                                                  'unicode' => '[クリップ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E730',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF4D' => {
                                  'softbank' => {
                                                  'unicode' => 'E13C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E701',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECB4' => {
                                  'softbank' => {
                                                  'unicode' => 'E431',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[救急車]',
                                                'type' => 'name'
                                              }
                                },
                      'F0C4' => {
                                  'softbank' => {
                                                  'unicode' => 'E012',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E695',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFEE' => {
                                  'softbank' => {
                                                  'unicode' => 'E008',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E681',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC60' => {
                                  'softbank' => {
                                                  'unicode' => 'E22E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '↑',
                                                'type' => 'name'
                                              }
                                },
                      'ECCF' => {
                                  'softbank' => {
                                                  'unicode' => 'E50E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ドイツ]',
                                                'type' => 'name'
                                              }
                                },
                      'F0D3' => {
                                  'softbank' => {
                                                  'unicode' => 'E144',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[カギ]',
                                                'type' => 'name'
                                              }
                                },
                      'EFA7' => {
                                  'softbank' => {
                                                  'unicode' => 'E118',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E747',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0EB' => {
                                  'softbank' => {
                                                  'unicode' => 'E037',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[教会]',
                                                'type' => 'name'
                                              }
                                },
                      'EFF8' => {
                                  'softbank' => {
                                                  'unicode' => 'E112',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E685',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED5A' => {
                                  'softbank' => {
                                                  'unicode' => '[プリン]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[プリン]',
                                                'type' => 'name'
                                              }
                                },
                      'EC44' => {
                                  'softbank' => {
                                                  'unicode' => 'E12D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[麻雀]',
                                                'type' => 'name'
                                              }
                                },
                      'F0F7' => {
                                  'softbank' => {
                                                  'unicode' => 'E10A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[タコ]',
                                                'type' => 'name'
                                              }
                                },
                      'EC92' => {
                                  'softbank' => {
                                                  'unicode' => 'E34D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[鍋]',
                                                'type' => 'name'
                                              }
                                },
                      'F0CC' => {
                                  'softbank' => {
                                                  'unicode' => 'E327',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6ED',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F044' => {
                                  'softbank' => {
                                                  'unicode' => 'E222',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6E8',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0B9' => {
                                  'softbank' => {
                                                  'unicode' => 'E502',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E67B',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED7C' => {
                                  'softbank' => {
                                                  'unicode' => 'E103E328',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E717',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF87' => {
                                  'softbank' => {
                                                  'unicode' => 'E136',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E71D',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFE7' => {
                                  'softbank' => {
                                                  'unicode' => 'E10C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[UFO]',
                                                'type' => 'name'
                                              }
                                },
                      'ECA1' => {
                                  'softbank' => {
                                                  'unicode' => 'E056',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6F0',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC49' => {
                                  'softbank' => {
                                                  'unicode' => 'E512',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ロシア]',
                                                'type' => 'name'
                                              }
                                },
                      'EC89' => {
                                  'softbank' => {
                                                  'unicode' => 'E33F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[パスタ]',
                                                'type' => 'name'
                                              }
                                },
                      'ECB2' => {
                                  'softbank' => {
                                                  'unicode' => 'E42D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[水泳]',
                                                'type' => 'name'
                                              }
                                },
                      'F0B8' => {
                                  'softbank' => {
                                                  'unicode' => '[ポケベル]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E65A',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F089' => {
                                  'softbank' => {
                                                  'unicode' => 'E148',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E683',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F097' => {
                                  'softbank' => {
                                                  'unicode' => '[腕時計]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E71F',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECE1' => {
                                  'softbank' => {
                                                  'unicode' => 'E527',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[コアラ]',
                                                'type' => 'name'
                                              }
                                },
                      'ED4C' => {
                                  'softbank' => {
                                                  'unicode' => 'E10B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E755',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED66' => {
                                  'softbank' => {
                                                  'unicode' => 'E103',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6CF',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFC6' => {
                                  'softbank' => {
                                                  'unicode' => '[なると]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E643',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECB0' => {
                                  'softbank' => {
                                                  'unicode' => 'E042',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[トランペット]',
                                                'type' => 'name'
                                              }
                                },
                      'ECC9' => {
                                  'softbank' => {
                                                  'unicode' => 'E503',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E67C',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFED' => {
                                  'softbank' => {
                                                  'unicode' => 'E034',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E71B',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F04D' => {
                                  'softbank' => {
                                                  'unicode' => 'E21B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '■',
                                                'type' => 'name'
                                              }
                                },
                      'F0DB' => {
                                  'softbank' => {
                                                  'unicode' => '[ラジオボタン]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ラジオボタン]',
                                                'type' => 'name'
                                              }
                                },
                      'F059' => {
                                  'softbank' => {
                                                  'unicode' => '－',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '－',
                                                'type' => 'name'
                                              }
                                },
                      'ED7D' => {
                                  'softbank' => {
                                                  'unicode' => '↑↓',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E735',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0D0' => {
                                  'softbank' => {
                                                  'unicode' => '[地球]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[地球]',
                                                'type' => 'name'
                                              }
                                },
                      'ECB8' => {
                                  'softbank' => {
                                                  'unicode' => 'E438',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ひな祭り]',
                                                'type' => 'name'
                                              }
                                },
                      'EF53' => {
                                  'softbank' => {
                                                  'unicode' => 'E11D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[炎]',
                                                'type' => 'name'
                                              }
                                },
                      'F0FC' => {
                                  'softbank' => {
                                                  'unicode' => 'E117',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[花火]',
                                                'type' => 'name'
                                              }
                                },
                      'F0A2' => {
                                  'softbank' => {
                                                  'unicode' => 'E12F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E715',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F090' => {
                                  'softbank' => {
                                                  'unicode' => 'E50C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[USA]',
                                                'type' => 'name'
                                              }
                                },
                      'EF8A' => {
                                  'softbank' => {
                                                  'unicode' => 'E01B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E65E',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC64' => {
                                  'softbank' => {
                                                  'unicode' => 'E251',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ケータイOFF]',
                                                'type' => 'name'
                                              }
                                },
                      'EF41' => {
                                  'softbank' => {
                                                  'unicode' => 'E443',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E643',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECAD' => {
                                  'softbank' => {
                                                  'unicode' => 'E426',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'm(_ _)m',
                                                'type' => 'name'
                                              }
                                },
                      'ED73' => {
                                  'softbank' => {
                                                  'unicode' => '[ジョーカー]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ジョーカー]',
                                                'type' => 'name'
                                              }
                                },
                      'EC8D' => {
                                  'softbank' => {
                                                  'unicode' => 'E345',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E745',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFB4' => {
                                  'softbank' => {
                                                  'unicode' => 'E04F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6A2',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF6C' => {
                                  'softbank' => {
                                                  'unicode' => 'E244',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E64B',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECC1' => {
                                  'softbank' => {
                                                  'unicode' => 'E442',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[風鈴]',
                                                'type' => 'name'
                                              }
                                },
                      'ED51' => {
                                  'softbank' => {
                                                  'unicode' => '[チョコ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[チョコ]',
                                                'type' => 'name'
                                              }
                                },
                      'EFB1' => {
                                  'softbank' => {
                                                  'unicode' => 'E01A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E754',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC97' => {
                                  'softbank' => {
                                                  'unicode' => 'E407',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6F3',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0C7' => {
                                  'softbank' => {
                                                  'unicode' => 'E04C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E69E',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC63' => {
                                  'softbank' => {
                                                  'unicode' => 'E250',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[マナーモード]',
                                                'type' => 'name'
                                              }
                                },
                      'ECB7' => {
                                  'softbank' => {
                                                  'unicode' => 'E436',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[門松]',
                                                'type' => 'name'
                                              }
                                },
                      'EF61' => {
                                  'softbank' => {
                                                  'unicode' => 'E04C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E69E',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF95' => {
                                  'softbank' => {
                                                  'unicode' => 'E123',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6F7',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF6E' => {
                                  'softbank' => {
                                                  'unicode' => 'E246',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E64D',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F067' => {
                                  'softbank' => {
                                                  'unicode' => 'E219',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E69C',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC6B' => {
                                  'softbank' => {
                                                  'unicode' => 'E30C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E672',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFC1' => {
                                  'softbank' => {
                                                  'unicode' => '[SOS]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[SOS]',
                                                'type' => 'name'
                                              }
                                },
                      'F051' => {
                                  'softbank' => {
                                                  'unicode' => 'E21A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '■',
                                                'type' => 'name'
                                              }
                                },
                      'EFF1' => {
                                  'softbank' => {
                                                  'unicode' => 'E114',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6DC',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF5F' => {
                                  'softbank' => {
                                                  'unicode' => 'E13D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E642',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECEB' => {
                                  'softbank' => {
                                                  'unicode' => 'E536',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E698',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFDE' => {
                                  'softbank' => {
                                                  'unicode' => 'E326',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6FF',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED8B' => {
                                  'softbank' => {
                                                  'unicode' => 'E427',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '＼(^o^)／',
                                                'type' => 'name'
                                              }
                                },
                      'ED57' => {
                                  'softbank' => {
                                                  'unicode' => '[火山]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[火山]',
                                                'type' => 'name'
                                              }
                                },
                      'EF74' => {
                                  'softbank' => {
                                                  'unicode' => 'E323',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E682',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC9A' => {
                                  'softbank' => {
                                                  'unicode' => 'E40B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E757',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECF1' => {
                                  'softbank' => {
                                                  'unicode' => '！！',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E704',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFFA' => {
                                  'softbank' => {
                                                  'unicode' => 'E103',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6D3',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF7E' => {
                                  'softbank' => {
                                                  'unicode' => 'E14F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E66C',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F09D' => {
                                  'softbank' => {
                                                  'unicode' => 'E129',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ビデオ]',
                                                'type' => 'name'
                                              }
                                },
                      'EC48' => {
                                  'softbank' => {
                                                  'unicode' => 'E511',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[スペイン]',
                                                'type' => 'name'
                                              }
                                },
                      'F043' => {
                                  'softbank' => {
                                                  'unicode' => 'E221',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6E7',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0D8' => {
                                  'softbank' => {
                                                  'unicode' => '[可]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[可]',
                                                'type' => 'name'
                                              }
                                },
                      'EF4E' => {
                                  'softbank' => {
                                                  'unicode' => 'E10F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6FB',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFB7' => {
                                  'softbank' => {
                                                  'unicode' => 'E10B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E755',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFC0' => {
                                  'softbank' => {
                                                  'unicode' => 'E105',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E728',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFA1' => {
                                  'softbank' => {
                                                  'unicode' => '[サイコロ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[サイコロ]',
                                                'type' => 'name'
                                              }
                                },
                      'EC80' => {
                                  'softbank' => {
                                                  'unicode' => 'E013',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E657',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECCE' => {
                                  'softbank' => {
                                                  'unicode' => 'E50D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[フランス]',
                                                'type' => 'name'
                                              }
                                },
                      'EC5F' => {
                                  'softbank' => {
                                                  'unicode' => 'E22D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[営]',
                                                'type' => 'name'
                                              }
                                },
                      'EFF9' => {
                                  'softbank' => {
                                                  'unicode' => 'E00B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6D0',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0F1' => {
                                  'softbank' => {
                                                  'unicode' => 'E051',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[クマ]',
                                                'type' => 'name'
                                              }
                                },
                      'ECC8' => {
                                  'softbank' => {
                                                  'unicode' => 'E449',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E63E',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFCA' => {
                                  'softbank' => {
                                                  'unicode' => 'E315',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E734',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0AD' => {
                                  'softbank' => {
                                                  'unicode' => '[フォルダ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[フォルダ]',
                                                'type' => 'name'
                                              }
                                },
                      'F0F8' => {
                                  'softbank' => {
                                                  'unicode' => 'E10D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ロケット]',
                                                'type' => 'name'
                                              }
                                },
                      'ED81' => {
                                  'softbank' => {
                                                  'unicode' => 'E43E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E73F',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFA2' => {
                                  'softbank' => {
                                                  'unicode' => 'E033',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6A4',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFD6' => {
                                  'softbank' => {
                                                  'unicode' => '[フキダシ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[フキダシ]',
                                                'type' => 'name'
                                              }
                                },
                      'F081' => {
                                  'softbank' => {
                                                  'unicode' => 'E301',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E689',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED6B' => {
                                  'softbank' => {
                                                  'unicode' => 'E403',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6F3',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFC7' => {
                                  'softbank' => {
                                                  'unicode' => 'E536',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E698',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F05A' => {
                                  'softbank' => {
                                                  'unicode' => '＊',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '＊',
                                                'type' => 'name'
                                              }
                                },
                      'EC74' => {
                                  'softbank' => {
                                                  'unicode' => 'E31F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[美容院]',
                                                'type' => 'name'
                                              }
                                },
                      'ECD7' => {
                                  'softbank' => {
                                                  'unicode' => 'E518',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[おじいさん]',
                                                'type' => 'name'
                                              }
                                },
                      'ED5D' => {
                                  'softbank' => {
                                                  'unicode' => '[ハチミツ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ハチミツ]',
                                                'type' => 'name'
                                              }
                                },
                      'EFE1' => {
                                  'softbank' => {
                                                  'unicode' => 'E30A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E67A',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF42' => {
                                  'softbank' => {
                                                  'unicode' => 'E14E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E66D',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECBA' => {
                                  'softbank' => {
                                                  'unicode' => 'E43A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ランドセル]',
                                                'type' => 'name'
                                              }
                                },
                      'EFF0' => {
                                  'softbank' => {
                                                  'unicode' => 'E03D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E677',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC75' => {
                                  'softbank' => {
                                                  'unicode' => 'E320',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[床屋]',
                                                'type' => 'name'
                                              }
                                },
                      'F08B' => {
                                  'softbank' => {
                                                  'unicode' => 'E148',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E683',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC96' => {
                                  'softbank' => {
                                                  'unicode' => 'E406',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E72B',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF75' => {
                                  'softbank' => {
                                                  'unicode' => 'E148',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E683',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0CF' => {
                                  'softbank' => {
                                                  'unicode' => '[ezplus]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ezplus]',
                                                'type' => 'name'
                                              }
                                },
                      'F06E' => {
                                  'softbank' => {
                                                  'unicode' => 'E234',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '→',
                                                'type' => 'name'
                                              }
                                },
                      'F06F' => {
                                  'softbank' => {
                                                  'unicode' => 'E235',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '←',
                                                'type' => 'name'
                                              }
                                },
                      'EFEC' => {
                                  'softbank' => {
                                                  'unicode' => 'E110',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E741',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F076' => {
                                  'softbank' => {
                                                  'unicode' => '▲',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '▲',
                                                'type' => 'name'
                                              }
                                },
                      'ECAF' => {
                                  'softbank' => {
                                                  'unicode' => 'E429',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[バニー]',
                                                'type' => 'name'
                                              }
                                },
                      'EFAD' => {
                                  'softbank' => {
                                                  'unicode' => 'E347',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[イチゴ]',
                                                'type' => 'name'
                                              }
                                },
                      'ECE4' => {
                                  'softbank' => {
                                                  'unicode' => 'E52E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ニワトリ]',
                                                'type' => 'name'
                                              }
                                },
                      'F0D1' => {
                                  'softbank' => {
                                                  'unicode' => 'E340',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E74C',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED52' => {
                                  'softbank' => {
                                                  'unicode' => '[キャンディ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[キャンディ]',
                                                'type' => 'name'
                                              }
                                },
                      'ED5B' => {
                                  'softbank' => {
                                                  'unicode' => '[ミツバチ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ミツバチ]',
                                                'type' => 'name'
                                              }
                                },
                      'F0C6' => {
                                  'softbank' => {
                                                  'unicode' => 'E04C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E69D',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECE6' => {
                                  'softbank' => {
                                                  'unicode' => 'E530',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ラクダ]',
                                                'type' => 'name'
                                              }
                                },
                      'F052' => {
                                  'softbank' => {
                                                  'unicode' => 'E21B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '◆',
                                                'type' => 'name'
                                              }
                                },
                      'EC72' => {
                                  'softbank' => {
                                                  'unicode' => 'E31B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ブーツ]',
                                                'type' => 'name'
                                              }
                                },
                      'EF5A' => {
                                  'softbank' => {
                                                  'unicode' => 'E021',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E702',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED4D' => {
                                  'softbank' => {
                                                  'unicode' => 'E305',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[花]',
                                                'type' => 'name'
                                              }
                                },
                      'F0F9' => {
                                  'softbank' => {
                                                  'unicode' => 'E10E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E71A',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC6A' => {
                                  'softbank' => {
                                                  'unicode' => 'E30B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E74B',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F041' => {
                                  'softbank' => {
                                                  'unicode' => 'E21F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6E5',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0B7' => {
                                  'softbank' => {
                                                  'unicode' => 'E42A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E658',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECCD' => {
                                  'softbank' => {
                                                  'unicode' => 'E508',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[工場]',
                                                'type' => 'name'
                                              }
                                },
                      'EF59' => {
                                  'softbank' => {
                                                  'unicode' => 'E252',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E737',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF97' => {
                                  'softbank' => {
                                                  'unicode' => 'E324',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6AC',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED46' => {
                                  'softbank' => {
                                                  'unicode' => 'E019',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E751',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED65' => {
                                  'softbank' => {
                                                  'unicode' => 'E057',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6F0',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF8B' => {
                                  'softbank' => {
                                                  'unicode' => 'E42F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[トラック]',
                                                'type' => 'name'
                                              }
                                },
                      'EFA9' => {
                                  'softbank' => {
                                                  'unicode' => 'E046',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E74A',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED4F' => {
                                  'softbank' => {
                                                  'unicode' => '[ドーナツ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ドーナツ]',
                                                'type' => 'name'
                                              }
                                },
                      'EFDF' => {
                                  'softbank' => {
                                                  'unicode' => 'E041',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ギター]',
                                                'type' => 'name'
                                              }
                                },
                      'EC56' => {
                                  'softbank' => {
                                                  'unicode' => 'E207',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[18禁]',
                                                'type' => 'name'
                                              }
                                },
                      'F091' => {
                                  'softbank' => {
                                                  'unicode' => 'E14A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[グラフ]',
                                                'type' => 'name'
                                              }
                                },
                      'ECEF' => {
                                  'softbank' => {
                                                  'unicode' => 'E238',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E700',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0D9' => {
                                  'softbank' => {
                                                  'unicode' => '[チェックマーク]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[チェックマーク]',
                                                'type' => 'name'
                                              }
                                },
                      'EF80' => {
                                  'softbank' => {
                                                  'unicode' => 'E150',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[バス停]',
                                                'type' => 'name'
                                              }
                                },
                      'F042' => {
                                  'softbank' => {
                                                  'unicode' => 'E220',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6E6',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0A1' => {
                                  'softbank' => {
                                                  'unicode' => '[電池]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[電池]',
                                                'type' => 'name'
                                              }
                                },
                      'F080' => {
                                  'softbank' => {
                                                  'unicode' => '[カレンダー]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[カレンダー]',
                                                'type' => 'name'
                                              }
                                },
                      'EF7D' => {
                                  'softbank' => {
                                                  'unicode' => 'E151',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E66E',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC57' => {
                                  'softbank' => {
                                                  'unicode' => 'E20B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[バリ3]',
                                                'type' => 'name'
                                              }
                                },
                      'EF91' => {
                                  'softbank' => {
                                                  'unicode' => '[スノボ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E712',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF94' => {
                                  'softbank' => {
                                                  'unicode' => 'E42B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[フットボール]',
                                                'type' => 'name'
                                              }
                                },
                      'ED84' => {
                                  'softbank' => {
                                                  'unicode' => 'E404',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E753',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC62' => {
                                  'softbank' => {
                                                  'unicode' => 'E23E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[占い]',
                                                'type' => 'name'
                                              }
                                },
                      'ECF6' => {
                                  'softbank' => {
                                                  'unicode' => '[バナナ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E744',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFA3' => {
                                  'softbank' => {
                                                  'unicode' => 'E030',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E748',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFAA' => {
                                  'softbank' => {
                                                  'unicode' => 'E147',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[フライパン]',
                                                'type' => 'name'
                                              }
                                },
                      'ECDB' => {
                                  'softbank' => {
                                                  'unicode' => 'E51C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[お姫様]',
                                                'type' => 'name'
                                              }
                                },
                      'EFE2' => {
                                  'softbank' => {
                                                  'unicode' => 'E31C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E710',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF76' => {
                                  'softbank' => {
                                                  'unicode' => 'E125',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E67E',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC7C' => {
                                  'softbank' => {
                                                  'unicode' => 'E32C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6EC',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED86' => {
                                  'softbank' => {
                                                  'unicode' => '[Cメール]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[Cメール]',
                                                'type' => 'name'
                                              }
                                },
                      'EF58' => {
                                  'softbank' => {
                                                  'unicode' => 'E209',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[若葉マーク]',
                                                'type' => 'name'
                                              }
                                },
                      'EF51' => {
                                  'softbank' => {
                                                  'unicode' => 'E32E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6FA',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F063' => {
                                  'softbank' => {
                                                  'unicode' => 'E21B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '◆',
                                                'type' => 'name'
                                              }
                                },
                      'EC90' => {
                                  'softbank' => {
                                                  'unicode' => 'E34A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ナス]',
                                                'type' => 'name'
                                              }
                                },
                      'F04E' => {
                                  'softbank' => {
                                                  'unicode' => 'E21A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '■',
                                                'type' => 'name'
                                              }
                                },
                      'F072' => {
                                  'softbank' => {
                                                  'unicode' => 'E239',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6A5',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC7A' => {
                                  'softbank' => {
                                                  'unicode' => 'E32A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6EC',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC8E' => {
                                  'softbank' => {
                                                  'unicode' => 'E346',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[みかん]',
                                                'type' => 'name'
                                              }
                                },
                      'F0DD' => {
                                  'softbank' => {
                                                  'unicode' => 'E235',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[←BACK]',
                                                'type' => 'name'
                                              }
                                },
                      'EC7B' => {
                                  'softbank' => {
                                                  'unicode' => 'E32B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6EC',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECC7' => {
                                  'softbank' => {
                                                  'unicode' => 'E501',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E669E6EF',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC55' => {
                                  'softbank' => {
                                                  'unicode' => 'E202',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E661',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF4B' => {
                                  'softbank' => {
                                                  'unicode' => 'E411',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E72D',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC4F' => {
                                  'softbank' => {
                                                  'unicode' => 'E14A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[株価]',
                                                'type' => 'name'
                                              }
                                },
                      'ECA6' => {
                                  'softbank' => {
                                                  'unicode' => 'E41D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '(>人<)',
                                                'type' => 'name'
                                              }
                                },
                      'F0EE' => {
                                  'softbank' => {
                                                  'unicode' => 'E03E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6F6',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC5A' => {
                                  'softbank' => {
                                                  'unicode' => 'E228',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[サービス]',
                                                'type' => 'name'
                                              }
                                },
                      'EC4D' => {
                                  'softbank' => {
                                                  'unicode' => 'E146',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[夕焼け]',
                                                'type' => 'name'
                                              }
                                },
                      'ED5C' => {
                                  'softbank' => {
                                                  'unicode' => '[てんとう虫]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[てんとう虫]',
                                                'type' => 'name'
                                              }
                                },
                      'F0F0' => {
                                  'softbank' => {
                                                  'unicode' => 'E050',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[トラ]',
                                                'type' => 'name'
                                              }
                                },
                      'ED6A' => {
                                  'softbank' => {
                                                  'unicode' => 'E403',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6F3',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0C9' => {
                                  'softbank' => {
                                                  'unicode' => 'E225',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6EB',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFF6' => {
                                  'softbank' => {
                                                  'unicode' => '[名札]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[名札]',
                                                'type' => 'name'
                                              }
                                },
                      'ED42' => {
                                  'softbank' => {
                                                  'unicode' => 'E044',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E671',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F095' => {
                                  'softbank' => {
                                                  'unicode' => '[FREE]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6D7',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F087' => {
                                  'softbank' => {
                                                  'unicode' => '[カレンダー]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[カレンダー]',
                                                'type' => 'name'
                                              }
                                },
                      'ED75' => {
                                  'softbank' => {
                                                  'unicode' => 'E103',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6D3',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECD5' => {
                                  'softbank' => {
                                                  'unicode' => 'E516',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[中国人]',
                                                'type' => 'name'
                                              }
                                },
                      'ECE3' => {
                                  'softbank' => {
                                                  'unicode' => 'E52D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ヘビ]',
                                                'type' => 'name'
                                              }
                                },
                      'F05E' => {
                                  'softbank' => {
                                                  'unicode' => '▼',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '▼',
                                                'type' => 'name'
                                              }
                                },
                      'ECE5' => {
                                  'softbank' => {
                                                  'unicode' => 'E52F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[イノシシ]',
                                                'type' => 'name'
                                              }
                                },
                      'EF93' => {
                                  'softbank' => {
                                                  'unicode' => 'E016',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E653',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F07E' => {
                                  'softbank' => {
                                                  'unicode' => 'E316',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[フロッピー]',
                                                'type' => 'name'
                                              }
                                },
                      'ED45' => {
                                  'softbank' => {
                                                  'unicode' => 'E017',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E712',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF9C' => {
                                  'softbank' => {
                                                  'unicode' => 'E047',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E672',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F060' => {
                                  'softbank' => {
                                                  'unicode' => '▼',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '▼',
                                                'type' => 'name'
                                              }
                                },
                      'ED69' => {
                                  'softbank' => {
                                                  'unicode' => 'E106',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E726',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F077' => {
                                  'softbank' => {
                                                  'unicode' => '▼',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '▼',
                                                'type' => 'name'
                                              }
                                },
                      'EC43' => {
                                  'softbank' => {
                                                  'unicode' => 'E122',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[キャンプ]',
                                                'type' => 'name'
                                              }
                                },
                      'ED5F' => {
                                  'softbank' => {
                                                  'unicode' => '[飛んでいくお金]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[飛んでいくお金]',
                                                'type' => 'name'
                                              }
                                },
                      'EC5D' => {
                                  'softbank' => {
                                                  'unicode' => 'E22B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E739',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF69' => {
                                  'softbank' => {
                                                  'unicode' => 'E241',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E648',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF81' => {
                                  'softbank' => {
                                                  'unicode' => 'E14B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[アンテナ]',
                                                'type' => 'name'
                                              }
                                },
                      'ED63' => {
                                  'softbank' => {
                                                  'unicode' => 'E44B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6B3',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC78' => {
                                  'softbank' => {
                                                  'unicode' => 'E20C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E68D',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED53' => {
                                  'softbank' => {
                                                  'unicode' => '[キャンディ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[キャンディ]',
                                                'type' => 'name'
                                              }
                                },
                      'F0BB' => {
                                  'softbank' => {
                                                  'unicode' => '[イベント]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E67D',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED47' => {
                                  'softbank' => {
                                                  'unicode' => '[ボーリング]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ボーリング]',
                                                'type' => 'name'
                                              }
                                },
                      'ECDE' => {
                                  'softbank' => {
                                                  'unicode' => 'E522',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E751',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF66' => {
                                  'softbank' => {
                                                  'unicode' => 'E04AE049',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E63EE63F',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECD6' => {
                                  'softbank' => {
                                                  'unicode' => 'E517',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[インド人]',
                                                'type' => 'name'
                                              }
                                },
                      'EFBA' => {
                                  'softbank' => {
                                                  'unicode' => 'E052',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6A1',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0D6' => {
                                  'softbank' => {
                                                  'unicode' => '[1234]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[1234]',
                                                'type' => 'name'
                                              }
                                },
                      'EC40' => {
                                  'softbank' => {
                                                  'unicode' => 'E119',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E747',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFB9' => {
                                  'softbank' => {
                                                  'unicode' => 'E523',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E74F',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECCC' => {
                                  'softbank' => {
                                                  'unicode' => 'E506',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[城]',
                                                'type' => 'name'
                                              }
                                },
                      'EC5E' => {
                                  'softbank' => {
                                                  'unicode' => 'E22C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[指]',
                                                'type' => 'name'
                                              }
                                },
                      'F049' => {
                                  'softbank' => {
                                                  'unicode' => 'E23B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '<',
                                                'type' => 'name'
                                              }
                                },
                      'F0E2' => {
                                  'softbank' => {
                                                  'unicode' => 'E301',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E689',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED83' => {
                                  'softbank' => {
                                                  'unicode' => '[カタツムリ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E74E',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC4E' => {
                                  'softbank' => {
                                                  'unicode' => 'E523',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E74F',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F083' => {
                                  'softbank' => {
                                                  'unicode' => 'E148',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E683',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0B0' => {
                                  'softbank' => {
                                                  'unicode' => '[受信BOX]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[受信BOX]',
                                                'type' => 'name'
                                              }
                                },
                      'F0AB' => {
                                  'softbank' => {
                                                  'unicode' => '',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '',
                                                'type' => 'name'
                                              }
                                },
                      'ECBC' => {
                                  'softbank' => {
                                                  'unicode' => 'E43C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E645',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED64' => {
                                  'softbank' => {
                                                  'unicode' => 'E418',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '(´３｀)',
                                                'type' => 'name'
                                              }
                                },
                      'F0E4' => {
                                  'softbank' => {
                                                  'unicode' => '↑↓',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E735',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF55' => {
                                  'softbank' => {
                                                  'unicode' => 'E30E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E67F',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECF9' => {
                                  'softbank' => {
                                                  'unicode' => '[栗]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[栗]',
                                                'type' => 'name'
                                              }
                                },
                      'F0A8' => {
                                  'softbank' => {
                                                  'unicode' => '[新聞]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[新聞]',
                                                'type' => 'name'
                                              }
                                },
                      'EFE0' => {
                                  'softbank' => {
                                                  'unicode' => '[バイオリン]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[バイオリン]',
                                                'type' => 'name'
                                              }
                                },
                      'F06A' => {
                                  'softbank' => {
                                                  'unicode' => 'E537',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E732',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF47' => {
                                  'softbank' => {
                                                  'unicode' => '[オメデトウ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[オメデトウ]',
                                                'type' => 'name'
                                              }
                                },
                      'ECEE' => {
                                  'softbank' => {
                                                  'unicode' => 'E236',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6F5',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0A4' => {
                                  'softbank' => {
                                                  'unicode' => '[レンチ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E718',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED4E' => {
                                  'softbank' => {
                                                  'unicode' => '[アイスクリーム]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[アイスクリーム]',
                                                'type' => 'name'
                                              }
                                },
                      'F0D4' => {
                                  'softbank' => {
                                                  'unicode' => '[ABCD]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ABCD]',
                                                'type' => 'name'
                                              }
                                },
                      'ED87' => {
                                  'softbank' => {
                                                  'unicode' => 'E110',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E741',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED71' => {
                                  'softbank' => {
                                                  'unicode' => 'E039',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[駅]',
                                                'type' => 'name'
                                              }
                                },
                      'EC6F' => {
                                  'softbank' => {
                                                  'unicode' => 'E312',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[クラッカー]',
                                                'type' => 'name'
                                              }
                                },
                      'ECB5' => {
                                  'softbank' => {
                                                  'unicode' => 'E432',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[パトカー]',
                                                'type' => 'name'
                                              }
                                },
                      'EC8B' => {
                                  'softbank' => {
                                                  'unicode' => 'E343',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[おでん]',
                                                'type' => 'name'
                                              }
                                },
                      'F0ED' => {
                                  'softbank' => {
                                                  'unicode' => 'E03B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E740',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED6E' => {
                                  'softbank' => {
                                                  'unicode' => 'E404',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E753',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0CE' => {
                                  'softbank' => {
                                                  'unicode' => 'E331',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E706',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC67' => {
                                  'softbank' => {
                                                  'unicode' => 'E303',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ハイビスカス]',
                                                'type' => 'name'
                                              }
                                },
                      'EF4C' => {
                                  'softbank' => {
                                                  'unicode' => 'E406',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E72B',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC53' => {
                                  'softbank' => {
                                                  'unicode' => 'E157',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E73E',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF7B' => {
                                  'softbank' => {
                                                  'unicode' => 'E154',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E668',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECFB' => {
                                  'softbank' => {
                                                  'unicode' => '[やきいも]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[やきいも]',
                                                'type' => 'name'
                                              }
                                },
                      'EC65' => {
                                  'softbank' => {
                                                  'unicode' => 'E301',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E689',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF40' => {
                                  'softbank' => {
                                                  'unicode' => '☆彡',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '☆彡',
                                                'type' => 'name'
                                              }
                                },
                      'EF8F' => {
                                  'softbank' => {
                                                  'unicode' => 'E018',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E656',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFD4' => {
                                  'softbank' => {
                                                  'unicode' => 'E056',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6F0',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECA5' => {
                                  'softbank' => {
                                                  'unicode' => 'E41C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6F9',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF6D' => {
                                  'softbank' => {
                                                  'unicode' => 'E245',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E64C',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFDC' => {
                                  'softbank' => {
                                                  'unicode' => 'E03C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E676',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0FA' => {
                                  'softbank' => {
                                                  'unicode' => 'E111',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6F9',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECF4' => {
                                  'softbank' => {
                                                  'unicode' => '[パイナップル]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[パイナップル]',
                                                'type' => 'name'
                                              }
                                },
                      'F0F3' => {
                                  'softbank' => {
                                                  'unicode' => 'E405',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E729',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF68' => {
                                  'softbank' => {
                                                  'unicode' => 'E240',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E647',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F088' => {
                                  'softbank' => {
                                                  'unicode' => 'E148',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E683',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC41' => {
                                  'softbank' => {
                                                  'unicode' => 'E11E',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E682',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F08F' => {
                                  'softbank' => {
                                                  'unicode' => '[地図]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[地図]',
                                                'type' => 'name'
                                              }
                                },
                      'ED5E' => {
                                  'softbank' => {
                                                  'unicode' => 'E345',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E745',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F07D' => {
                                  'softbank' => {
                                                  'unicode' => 'E301',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E689',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0DF' => {
                                  'softbank' => {
                                                  'unicode' => 'E104',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6CE',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED76' => {
                                  'softbank' => {
                                                  'unicode' => 'E201',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E733',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECE8' => {
                                  'softbank' => {
                                                  'unicode' => 'E533',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[B]',
                                                'type' => 'name'
                                              }
                                },
                      'ECD4' => {
                                  'softbank' => {
                                                  'unicode' => 'E515',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[白人]',
                                                'type' => 'name'
                                              }
                                },
                      'EC99' => {
                                  'softbank' => {
                                                  'unicode' => 'E40A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E721',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFAF' => {
                                  'softbank' => {
                                                  'unicode' => 'E120',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E673',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF9B' => {
                                  'softbank' => {
                                                  'unicode' => 'E044',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E671',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFAE' => {
                                  'softbank' => {
                                                  'unicode' => 'E342',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E749',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC79' => {
                                  'softbank' => {
                                                  'unicode' => 'E327',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6EC',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC95' => {
                                  'softbank' => {
                                                  'unicode' => 'E404',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E753',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED85' => {
                                  'softbank' => {
                                                  'unicode' => 'E404',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E753',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFFC' => {
                                  'softbank' => {
                                                  'unicode' => 'E21D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6E3',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC98' => {
                                  'softbank' => {
                                                  'unicode' => 'E408',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E701',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F078' => {
                                  'softbank' => {
                                                  'unicode' => '└→',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '└→',
                                                'type' => 'name'
                                              }
                                },
                      'EFE3' => {
                                  'softbank' => {
                                                  'unicode' => 'E113',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ピストル]',
                                                'type' => 'name'
                                              }
                                },
                      'EF52' => {
                                  'softbank' => {
                                                  'unicode' => 'E311',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6FE',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F096' => {
                                  'softbank' => {
                                                  'unicode' => 'E12F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E715',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF6B' => {
                                  'softbank' => {
                                                  'unicode' => 'E243',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E64A',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFB5' => {
                                  'softbank' => {
                                                  'unicode' => 'E055',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E750',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFF5' => {
                                  'softbank' => {
                                                  'unicode' => 'E144',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6D9',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC82' => {
                                  'softbank' => {
                                                  'unicode' => 'E338',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E71E',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF82' => {
                                  'softbank' => {
                                                  'unicode' => 'E202',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E661',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED54' => {
                                  'softbank' => {
                                                  'unicode' => '(/_＼)',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '(/_＼)',
                                                'type' => 'name'
                                              }
                                },
                      'F0D7' => {
                                  'softbank' => {
                                                  'unicode' => '[記号]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[記号]',
                                                'type' => 'name'
                                              }
                                },
                      'ED40' => {
                                  'softbank' => {
                                                  'unicode' => '[チキン]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[チキン]',
                                                'type' => 'name'
                                              }
                                },
                      'EFA0' => {
                                  'softbank' => {
                                                  'unicode' => 'E12F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E715',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED55' => {
                                  'softbank' => {
                                                  'unicode' => '(・×・)',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '(・×・)',
                                                'type' => 'name'
                                              }
                                },
                      'ECF2' => {
                                  'softbank' => {
                                                  'unicode' => '～',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E70A',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC9C' => {
                                  'softbank' => {
                                                  'unicode' => 'E40D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[熱]',
                                                'type' => 'name'
                                              }
                                },
                      'F0BA' => {
                                  'softbank' => {
                                                  'unicode' => 'E503',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[演劇]',
                                                'type' => 'name'
                                              }
                                },
                      'F050' => {
                                  'softbank' => {
                                                  'unicode' => 'E21B',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '■',
                                                'type' => 'name'
                                              }
                                },
                      'F066' => {
                                  'softbank' => {
                                                  'unicode' => 'E219',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E69C',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F069' => {
                                  'softbank' => {
                                                  'unicode' => 'E238',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E696',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFF7' => {
                                  'softbank' => {
                                                  'unicode' => 'E009',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E687',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F04B' => {
                                  'softbank' => {
                                                  'unicode' => 'E23D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '<<',
                                                'type' => 'name'
                                              }
                                },
                      'EC70' => {
                                  'softbank' => {
                                                  'unicode' => '[EZナビ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[EZナビ]',
                                                'type' => 'name'
                                              }
                                },
                      'EF70' => {
                                  'softbank' => {
                                                  'unicode' => 'E248',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E64F',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ECCB' => {
                                  'softbank' => {
                                                  'unicode' => 'E505',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[城]',
                                                'type' => 'name'
                                              }
                                },
                      'EC8C' => {
                                  'softbank' => {
                                                  'unicode' => 'E344',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[すし]',
                                                'type' => 'name'
                                              }
                                },
                      'F0DA' => {
                                  'softbank' => {
                                                  'unicode' => '[ペン]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6AE',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC83' => {
                                  'softbank' => {
                                                  'unicode' => 'E339',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E74D',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF50' => {
                                  'softbank' => {
                                                  'unicode' => 'E327',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6EF',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F09E' => {
                                  'softbank' => {
                                                  'unicode' => '[ネジ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ネジ]',
                                                'type' => 'name'
                                              }
                                },
                      'F04C' => {
                                  'softbank' => {
                                                  'unicode' => 'E23C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '>>',
                                                'type' => 'name'
                                              }
                                },
                      'F0CD' => {
                                  'softbank' => {
                                                  'unicode' => '[ドンッ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E705',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFDD' => {
                                  'softbank' => {
                                                  'unicode' => '[財布]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E70F',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED62' => {
                                  'softbank' => {
                                                  'unicode' => 'E416',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E724',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFD5' => {
                                  'softbank' => {
                                                  'unicode' => 'E001',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6F0',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0AC' => {
                                  'softbank' => {
                                                  'unicode' => '[フォルダ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[フォルダ]',
                                                'type' => 'name'
                                              }
                                },
                      'ECF3' => {
                                  'softbank' => {
                                                  'unicode' => '[メロン]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[メロン]',
                                                'type' => 'name'
                                              }
                                },
                      'EC73' => {
                                  'softbank' => {
                                                  'unicode' => 'E31D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[マニキュア]',
                                                'type' => 'name'
                                              }
                                },
                      'F0B1' => {
                                  'softbank' => {
                                                  'unicode' => 'E02D',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6BA',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EC66' => {
                                  'softbank' => {
                                                  'unicode' => 'E302',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ネクタイ]',
                                                'type' => 'name'
                                              }
                                },
                      'F0E3' => {
                                  'softbank' => {
                                                  'unicode' => 'E144',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6D9',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F04A' => {
                                  'softbank' => {
                                                  'unicode' => 'E23A',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '>',
                                                'type' => 'name'
                                              }
                                },
                      'ECA8' => {
                                  'softbank' => {
                                                  'unicode' => 'E420',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E70B',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0A9' => {
                                  'softbank' => {
                                                  'unicode' => '　',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '　',
                                                'type' => 'name'
                                              }
                                },
                      'EFC5' => {
                                  'softbank' => {
                                                  'unicode' => 'E10C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[宇宙人]',
                                                'type' => 'name'
                                              }
                                },
                      'F05D' => {
                                  'softbank' => {
                                                  'unicode' => '[禁止]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E738',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0FB' => {
                                  'softbank' => {
                                                  'unicode' => 'E116',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ハンマー]',
                                                'type' => 'name'
                                              }
                                },
                      'ED74' => {
                                  'softbank' => {
                                                  'unicode' => '[エビフライ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[エビフライ]',
                                                'type' => 'name'
                                              }
                                },
                      'F0B6' => {
                                  'softbank' => {
                                                  'unicode' => 'E014',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E654',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F082' => {
                                  'softbank' => {
                                                  'unicode' => 'E148',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E683',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF5B' => {
                                  'softbank' => {
                                                  'unicode' => 'E020',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '？',
                                                'type' => 'name'
                                              }
                                },
                      'ED6F' => {
                                  'softbank' => {
                                                  'unicode' => 'E319',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[ドレス]',
                                                'type' => 'name'
                                              }
                                },
                      'F0C3' => {
                                  'softbank' => {
                                                  'unicode' => 'E011',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E694',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EF92' => {
                                  'softbank' => {
                                                  'unicode' => 'E132',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E659',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F04F' => {
                                  'softbank' => {
                                                  'unicode' => '[i]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[i]',
                                                'type' => 'name'
                                              }
                                },
                      'F08A' => {
                                  'softbank' => {
                                                  'unicode' => '[画びょう]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[画びょう]',
                                                'type' => 'name'
                                              }
                                },
                      'EC4B' => {
                                  'softbank' => {
                                                  'unicode' => 'E13F',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6F7',
                                                'type' => 'pictogram'
                                              }
                                },
                      'ED88' => {
                                  'softbank' => {
                                                  'unicode' => 'E010',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E693',
                                                'type' => 'pictogram'
                                              }
                                },
                      'F0A3' => {
                                  'softbank' => {
                                                  'unicode' => '[PDC]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[PDC]',
                                                'type' => 'name'
                                              }
                                },
                      'F048' => {
                                  'softbank' => {
                                                  'unicode' => '[Q]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E6E1',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFB6' => {
                                  'softbank' => {
                                                  'unicode' => '[アリ]',
                                                  'type' => 'name'
                                                },
                                  'docomo' => {
                                                'unicode' => '[アリ]',
                                                'type' => 'name'
                                              }
                                },
                      'ECC6' => {
                                  'softbank' => {
                                                  'unicode' => 'E44C',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => '[虹]',
                                                'type' => 'name'
                                              }
                                },
                      'EC54' => {
                                  'softbank' => {
                                                  'unicode' => 'E158',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E669',
                                                'type' => 'pictogram'
                                              }
                                },
                      'EFEB' => {
                                  'softbank' => {
                                                  'unicode' => 'E325',
                                                  'type' => 'pictogram'
                                                },
                                  'docomo' => {
                                                'unicode' => 'E713',
                                                'type' => 'pictogram'
                                              }
                                }
                    }
        }
